#!/usr/bin/env bash
# رفع التطبيق إلى مستودعك ثم النشر على Vercel
# الاستخدام: bash push-to-github.sh
# المستودع الافتراضي: https://github.com/regm2025-coder/gypsum-accounts.git
set -e
REPO_URL="${1:-https://github.com/regm2025-coder/gypsum-accounts.git}"
echo "▶ المستودع: $REPO_URL"
[ -d .git ] || git init -q
git add -A
git commit -m "حسابات الجبس والديكور - PWA" --quiet || echo "لا توجد تغييرات جديدة"
git branch -M main
if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO_URL"
else
  git remote add origin "$REPO_URL"
fi
git push -u origin main --force
echo "✅ تم الرفع. افتح https://vercel.com/new ← Import ← Deploy"
