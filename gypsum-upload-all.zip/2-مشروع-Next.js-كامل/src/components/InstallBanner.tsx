"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";

interface BIPEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function useInstallPrompt() {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setEvt(null);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    if (
      typeof window !== "undefined" &&
      (window.matchMedia("(display-mode: standalone)").matches ||
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (window.navigator as any).standalone === true)
    ) {
      setInstalled(true);
    }
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const install = async (): Promise<"accepted" | "dismissed" | "unsupported"> => {
    if (!evt) return "unsupported";
    await evt.prompt();
    const choice = await evt.userChoice;
    if (choice.outcome === "accepted") {
      setInstalled(true);
      setEvt(null);
    }
    return choice.outcome;
  };

  return { canInstall: !!evt, installed, install };
}

export function InstallBanner({ onOpenGuide }: { onOpenGuide: () => void }) {
  const { canInstall, installed, install } = useInstallPrompt();
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    try {
      setHidden(localStorage.getItem("gypsum_install_dismissed") === "1");
    } catch {
      setHidden(false);
    }
  }, []);

  if (installed || hidden) return null;

  const dismiss = () => {
    setHidden(true);
    try {
      localStorage.setItem("gypsum_install_dismissed", "1");
    } catch {
      /* ignore */
    }
  };

  return (
    <section className="anim-rise relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#D97706] to-amber-500 p-4 text-white card-soft">
      <button
        onClick={dismiss}
        className="absolute left-2 top-2 grid h-7 w-7 place-items-center rounded-full bg-white/20 text-[12px] font-bold"
        aria-label="إغلاق"
      >
        ✕
      </button>
      <div className="flex items-start gap-3 pl-6">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/20 text-xl">
          📲
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[14px] font-black leading-tight">
            نزّل التطبيق على شاشتك الرئيسية
          </p>
          <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-amber-50">
            يفتح كتطبيق مستقل ويعمل بدون إنترنت — جاهز لإرساله لصديقك.
          </p>
          <div className="mt-2.5 flex gap-2">
            {canInstall ? (
              <button
                onClick={() => void install()}
                className="flex-1 rounded-xl bg-white py-2.5 text-[13px] font-black text-[#92400E] transition active:scale-95"
              >
                تثبيت الآن ⬇
              </button>
            ) : (
              <button
                onClick={onOpenGuide}
                className="flex-1 rounded-xl bg-white py-2.5 text-[13px] font-black text-[#92400E] transition active:scale-95"
              >
                طريقة التثبيت 📖
              </button>
            )}
            <Link
              href="/download"
              className="rounded-xl bg-white/20 px-3 py-2.5 text-[12px] font-extrabold"
            >
              مركز التنزيل
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
