"use client";

import React, { useEffect, useState } from "react";
import {
  absoluteUrl,
  appUrl,
  copyText,
  isEmbedded,
  isUnshareableHost,
  openExternal,
} from "@/lib/share";
import { Sheet } from "./ui";

/**
 * ورقة مشاركة شاملة: تفتح واتساب، أو تنسخ الرقم/النص/الرابط،
 * مع بدائل تعمل داخل إطارات المعاينة المقيّدة.
 */
export function ShareSheet({
  open,
  onClose,
  title = "📤 مشاركة",
  subtitle,
  waPhone,
  waText,
  fileUrl,
  fileLabel,
  linkLabel = "رابط التطبيق",
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  /** نص واتساب (إن وُجد يظهر زر الإرسال) */
  waText?: string;
  waPhone?: string;
  /** ملف للتنزيل */
  fileUrl?: string;
  fileLabel?: string;
  linkLabel?: string;
}) {
  const [embedded, setEmbedded] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    if (open) setEmbedded(isEmbedded());
  }, [open]);

  const flash = (key: string) => {
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const phoneDigits = (waPhone ?? "").replace(/\D/g, "");
  const waLink = waText
    ? phoneDigits.length >= 8
      ? `https://wa.me/${normalize(phoneDigits)}?text=${encodeURIComponent(waText)}`
      : `https://wa.me/?text=${encodeURIComponent(waText)}`
    : "";
  const fileAbs = fileUrl ? absoluteUrl(fileUrl) : "";
  const pageUrl = appUrl();

  const [sharedFile, setSharedFile] = useState(false);

  useEffect(() => {
    if (!fileUrl) return;
    setSharedFile(
      typeof navigator !== "undefined" &&
        typeof navigator.canShare === "function" &&
        typeof navigator.share === "function"
    );
  }, [fileUrl]);

  const shareFile = async () => {
    if (!fileUrl) return;
    try {
      const res = await fetch(fileUrl);
      const blob = await res.blob();
      const name = fileLabel?.endsWith(".html")
        ? fileLabel
        : "حسابات-معلم-الجبس.html";
      const file = new File([blob], name, { type: "text/html" });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: "حسابات معلم الجبس",
          text: "تطبيق حسابات معلم الجبس — ملف واحد يعمل بدون إنترنت",
        });
        return;
      }
      await handleCopy(absoluteUrl(fileUrl), "file");
    } catch {
      await handleCopy(absoluteUrl(fileUrl), "file");
    }
  };

  const handleCopy = async (value: string, key: string) => {
    const ok = await copyText(value);
    flash(ok ? key : `${key}-fail`);
  };

  return (
    <Sheet open={open} onClose={onClose} title={title} subtitle={subtitle}>
      <div className="space-y-3">
        {embedded && (
          <div className="rounded-xl bg-amber-50 px-3 py-2.5 ring-1 ring-amber-200">
            <p className="text-[12px] font-extrabold leading-relaxed text-amber-800">
              ⚠️ أنت تشاهد التطبيق داخل معاينة محمية، وقد يمنع المتصفح فتح واتساب أو تنزيل
              الملفات مباشرة. استخدم الأزرار البديلة بالأسفل، أو افتح التطبيق في نافذة مستقلة.
            </p>
          </div>
        )}

        {/* رابط التطبيق — أفضل ما يُرسل للصديق */}
        <div className="rounded-2xl bg-white p-3.5 card-soft">
          <p className="text-[12px] font-extrabold text-slate-500">🔗 رابط التطبيق (أرسله لصديقك)</p>
          <div
            className="num mt-1.5 max-h-16 select-all overflow-auto break-all rounded-xl bg-slate-50 px-3 py-2 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200"
            dir="ltr"
          >
            {pageUrl}
          </div>
          {isUnshareableHost(pageUrl) && (
            <p className="mt-1.5 rounded-lg bg-red-50 px-2 py-1.5 text-[11px] font-extrabold text-red-700 ring-1 ring-red-200">
              ⚠️ هذا رابط منصة معاينة خاص لا يفتح لغيرك — افتح التطبيق في نافذة مستقلة أولاً
              ثم انسخ الرابط من هناك.
            </p>
          )}
          <button
            onClick={() => void handleCopy(pageUrl, "page")}
            className="mt-2 w-full rounded-xl bg-[#D97706] py-3 text-[13px] font-black text-white transition active:scale-[0.98]"
          >
            {copied === "page" ? "✅ تم نسخ رابط التطبيق" : "📋 نسخ رابط التطبيق"}
          </button>
          {sharedFile && (
            <button
              onClick={() => void shareFile()}
              className="mt-2 w-full rounded-xl bg-emerald-600 py-3 text-[13px] font-black text-white transition active:scale-[0.98]"
            >
              📎 مشاركة ملف التطبيق عبر واتساب
            </button>
          )}
        </div>

        {/* رابط مباشر لواتساب — الرابط الأصلي هو الأكثر موثوقية */}
        {waLink && (
          <a
            href={waLink}
            target="_top"
            rel="noopener noreferrer"
            className="block w-full rounded-2xl bg-[#25D366] py-3.5 text-center text-[15px] font-black text-white shadow-[0_8px_24px_rgba(37,211,102,0.3)] transition active:scale-[0.98]"
          >
            ✈ فتح واتساب وإرسال الكشف
          </a>
        )}

        {fileAbs && (
          <a
            href={fileAbs}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full rounded-2xl bg-[#1E293B] py-3.5 text-center text-[14px] font-black text-white transition active:scale-[0.98]"
          >
            ⬇ {fileLabel ?? "فتح الملف في نافذة جديدة"}
          </a>
        )}

        {/* نسخ المحتوى */}
        <div className="rounded-2xl bg-white p-3.5 card-soft">
          <p className="mb-2 text-[12px] font-extrabold text-slate-500">
            أو انسخ المحتوى وألصقه في واتساب:
          </p>
          <div className="space-y-2">
            {waText && (
              <button
                onClick={() => void handleCopy(waText, "text")}
                className="w-full rounded-xl bg-slate-100 py-3 text-[13px] font-extrabold text-slate-700 transition active:scale-[0.98]"
              >
                {copied === "text"
                  ? "✅ تم نسخ نص الكشف — ألصقه في واتساب"
                  : copied === "text-fail"
                    ? "⚠️ النسخ محجوب — حدّد النص بالأسفل يدوياً"
                    : "📋 نسخ نص كشف الحساب"}
              </button>
            )}
            {phoneDigits.length >= 8 && (
              <button
                onClick={() => void handleCopy(waPhone ?? phoneDigits, "phone")}
                className="w-full rounded-xl bg-slate-100 py-3 text-[13px] font-extrabold text-slate-700 transition active:scale-[0.98]"
              >
                {copied === "phone" ? "✅ تم نسخ رقم صاحب البيت" : "📞 نسخ رقم صاحب البيت"}
              </button>
            )}
            {fileAbs && (
              <button
                onClick={() => void handleCopy(fileAbs, "file")}
                className="w-full rounded-xl bg-slate-100 py-3 text-[13px] font-extrabold text-slate-700 transition active:scale-[0.98]"
              >
                {copied === "file" ? "✅ تم نسخ رابط الملف" : "🔗 نسخ رابط الملف"}
              </button>
            )}
          </div>
        </div>

        {/* نصوص قابلة للتحديد يدوياً */}
        <div className="rounded-2xl bg-white p-3.5 card-soft">
          <p className="mb-1.5 text-[12px] font-extrabold text-slate-500">
            أو اضغط مطولاً على الرابط لتحديده ونسخه:
          </p>
          <div
            className="num max-h-28 select-all overflow-y-auto break-all rounded-xl bg-slate-50 px-3 py-2 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200"
            dir="ltr"
          >
            {fileAbs || waLink || pageUrl}
          </div>
        </div>

        <button
          onClick={() => openExternal(pageUrl)}
          className="w-full rounded-2xl bg-white py-3 text-[13px] font-extrabold text-[#92400E] ring-1 ring-amber-300 transition active:scale-[0.98]"
        >
          ↗ فتح التطبيق في نافذة مستقلة (للمشاركة والتنزيل)
        </button>
        {fileAbs && (
          <button
            onClick={() => openExternal(fileAbs)}
            className="w-full rounded-2xl bg-white py-3 text-[13px] font-extrabold text-slate-700 ring-1 ring-slate-200 transition active:scale-[0.98]"
          >
            ↗ فتح ملف التطبيق المستقل
          </button>
        )}
      </div>
    </Sheet>
  );
}

function normalize(digits: string): string {
  let d = digits;
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("966")) {
    const rest = d.slice(3);
    return rest.startsWith("0") ? "966" + rest.slice(1) : d;
  }
  if (d.startsWith("0")) return "966" + d.slice(1);
  if (d.length === 9 && d.startsWith("5")) return "966" + d;
  return d;
}
