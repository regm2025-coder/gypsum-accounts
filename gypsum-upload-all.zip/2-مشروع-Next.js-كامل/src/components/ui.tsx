"use client";

import React, { useState } from "react";
import { useStore } from "@/lib/store";

// ─── الشريط العلوي الكحلي ───
export function TopBar({
  title,
  subtitle,
  right,
  onBack,
}: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  onBack?: () => void;
}) {
  const { online, syncing, pendingCount, syncNow } = useStore();
  return (
    <header className="sticky top-0 z-30 bg-[#1E293B] text-white shadow-[0_4px_20px_rgba(15,23,42,0.35)]">
      <div className="mx-auto flex max-w-md items-center gap-3 px-4 pb-4 pt-4">
        {onBack && (
          <button
            onClick={onBack}
            aria-label="رجوع"
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/10 text-lg transition active:scale-95"
          >
            ←
          </button>
        )}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-[17px] font-extrabold leading-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="truncate text-[12px] font-medium text-slate-300">
              {subtitle}
            </p>
          )}
        </div>
        {right}
        <button
          onClick={() => void syncNow()}
          title={online ? "مزامنة الآن" : "لا يوجد اتصال"}
          className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/10 transition active:scale-95"
        >
          <span
            className={`text-base ${syncing ? "animate-spin" : ""}`}
            style={{ display: "inline-block" }}
          >
            {syncing ? "⟳" : online ? "☁" : "⚡"}
          </span>
          {!online && (
            <span className="absolute -left-1 -top-1 h-3.5 w-3.5 rounded-full border-2 border-[#1E293B] bg-amber-400" />
          )}
          {online && pendingCount > 0 && (
            <span className="absolute -left-1.5 -top-1.5 grid min-h-5 min-w-5 place-items-center rounded-full bg-amber-500 px-1 text-[10px] font-extrabold text-white">
              {pendingCount > 9 ? "9+" : pendingCount}
            </span>
          )}
        </button>
      </div>
      {/* مؤشر الأوفلاين */}
      {!online && (
        <div className="bg-amber-500/15 px-4 pb-2.5 text-center text-[12px] font-bold text-amber-300">
          ⚡ وضع عدم الاتصال — تُحفظ البيانات على الهاتف وستُزامَن تلقائياً
        </div>
      )}
      {online && pendingCount > 0 && !syncing && (
        <div className="bg-white/5 px-4 pb-2.5 text-center text-[12px] font-bold text-slate-300">
          ⏳ {pendingCount} عناصر بانتظار المزامنة…
        </div>
      )}
    </header>
  );
}

// ─── ورقة سفلية (Bottom Sheet) ───
export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div
        className="anim-fade absolute inset-0 bg-slate-950/60 backdrop-blur-[2px]"
        onClick={onClose}
      />
      <div className="anim-sheet relative max-h-[92dvh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-[#F8FAFC] p-5 pb-8 sm:rounded-3xl">
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-slate-200" />
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">{title}</h2>
            {subtitle && (
              <p className="mt-0.5 text-[13px] font-medium text-slate-500">
                {subtitle}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-slate-100 text-lg font-bold text-slate-500 transition active:scale-95"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── زر ذهبي رئيسي ───
export function GoldButton({
  children,
  onClick,
  disabled,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-full rounded-2xl bg-[#D97706] px-5 py-3.5 text-[15px] font-extrabold text-white shadow-[0_8px_24px_rgba(217,119,6,0.35)] transition active:scale-[0.98] disabled:opacity-50 ${className}`}
    >
      {children}
    </button>
  );
}

export function NavyButton({
  children,
  onClick,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full rounded-2xl bg-[#1E293B] px-5 py-3.5 text-[15px] font-extrabold text-white shadow-[0_8px_24px_rgba(30,41,59,0.3)] transition active:scale-[0.98] ${className}`}
    >
      {children}
    </button>
  );
}

// ─── حالة فارغة ───
export function EmptyState({
  icon,
  title,
  hint,
}: {
  icon: string;
  title: string;
  hint: string;
}) {
  return (
    <div className="anim-rise rounded-2xl border-2 border-dashed border-slate-200 bg-white px-6 py-10 text-center">
      <div className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-[#FEF3C7] text-3xl">
        {icon}
      </div>
      <p className="text-[15px] font-extrabold text-slate-800">{title}</p>
      <p className="mt-1 text-[13px] font-medium text-slate-500">{hint}</p>
    </div>
  );
}

// ─── عارض الصور ───
export function ImageViewer({
  src,
  onClose,
}: {
  src: string | null;
  onClose: () => void;
}) {
  if (!src) return null;
  return (
    <div
      className="anim-fade fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/85 p-4"
      onClick={onClose}
    >
      <div className="anim-pop max-h-[85dvh] w-full max-w-md overflow-hidden rounded-2xl bg-white">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src} alt="صورة الفاتورة" className="max-h-[75dvh] w-full object-contain bg-slate-950" />
        <button
          onClick={onClose}
          className="w-full bg-[#1E293B] py-3 text-sm font-extrabold text-white"
        >
          إغلاق ✕
        </button>
      </div>
    </div>
  );
}

// ─── تأكيد الحذف ───
export function ConfirmDelete({
  open,
  title,
  message,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  title: string;
  message: string;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[55] flex items-center justify-center p-5">
      <div className="anim-fade absolute inset-0 bg-slate-950/60" onClick={onCancel} />
      <div className="anim-pop relative w-full max-w-xs rounded-3xl bg-white p-6 text-center">
        <div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-red-50 text-2xl">
          🗑
        </div>
        <h3 className="text-[16px] font-extrabold text-slate-900">{title}</h3>
        <p className="mt-1 text-[13px] font-medium text-slate-500">{message}</p>
        <div className="mt-5 grid grid-cols-2 gap-2.5">
          <button
            onClick={onCancel}
            className="rounded-xl bg-slate-100 py-3 text-sm font-extrabold text-slate-700"
          >
            إلغاء
          </button>
          <button
            onClick={onConfirm}
            className="rounded-xl bg-red-600 py-3 text-sm font-extrabold text-white"
          >
            حذف
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── شارة الحالة ───
export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    active: { label: "● نشط", cls: "bg-emerald-50 text-emerald-700" },
    paused: { label: "● متوقف", cls: "bg-amber-50 text-amber-700" },
    completed: { label: "● مكتمل", cls: "bg-slate-100 text-slate-600" },
  };
  const s = map[status] ?? map.active;
  return (
    <span className={`rounded-full px-2.5 py-1 text-[11px] font-extrabold ${s.cls}`}>
      {s.label}
    </span>
  );
}

// ─── حقل مع عنوان ───
export function FieldWrap({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-extrabold text-slate-700">
        {label}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[11px] font-medium text-slate-400">{hint}</span>}
    </label>
  );
}

// ─── عداد رقمي متحرك بسيط ───
export function useCountUp(target: number, duration = 600): number {
  const [val, setVal] = useState(0);
  React.useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const from = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return val;
}
