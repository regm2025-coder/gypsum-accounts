"use client";

import React, { useEffect, useState } from "react";

type Check = {
  key: string;
  label: string;
  status: "ok" | "warn" | "fail" | "loading";
  detail: string;
};

/** لوحة تشخيص تُثبت جاهزية التطبيق كـ PWA (manifest + SW + HTTPS + standalone) */
export function PwaDiagnostics() {
  const [checks, setChecks] = useState<Check[]>([
    { key: "https", label: "اتصال آمن HTTPS", status: "loading", detail: "…" },
    { key: "manifest", label: "ملف المظهر manifest.json", status: "loading", detail: "…" },
    { key: "icons", label: "أيقونات 192 و 512", status: "loading", detail: "…" },
    { key: "sw", label: "المشغل المحلي Service Worker", status: "loading", detail: "…" },
    { key: "display", label: "وضع العرض standalone", status: "loading", detail: "…" },
    { key: "storage", label: "التخزين المحلي", status: "loading", detail: "…" },
  ]);

  useEffect(() => {
    const set = (key: string, patch: Partial<Check>) =>
      setChecks((prev) => prev.map((c) => (c.key === key ? { ...c, ...patch } : c)));

    const run = async () => {
      // HTTPS
      const secure =
        window.isSecureContext ||
        ["localhost", "127.0.0.1"].includes(window.location.hostname);
      set("https", {
        status: secure ? "ok" : "warn",
        detail: secure ? "المتصفح يسمح بالتثبيت" : "التثبيت يحتاج HTTPS (أو localhost)",
      });

      // manifest
      try {
        const res = await fetch("/manifest.json", { cache: "no-store" });
        const m = await res.json();
        set("manifest", {
          status: res.ok && m.name ? "ok" : "fail",
          detail: m.name ? `${m.short_name ?? m.name}` : "غير صالح",
        });
        const sizes: string[] = (m.icons ?? []).map((i: { sizes?: string }) => i.sizes ?? "");
        const has192 = sizes.some((s) => s.includes("192"));
        const has512 = sizes.some((s) => s.includes("512"));
        set("icons", {
          status: has192 && has512 ? "ok" : "fail",
          detail: has192 && has512 ? "192×192 و 512×512 متوفرة" : "أيقونات ناقصة",
        });
        set("display", {
          status: m.display === "standalone" ? "ok" : "warn",
          detail: `display: ${m.display ?? "غير محدد"} • theme: ${m.theme_color ?? "—"}`,
        });
      } catch {
        set("manifest", { status: "fail", detail: "تعذر قراءة الملف" });
        set("icons", { status: "fail", detail: "—" });
        set("display", { status: "fail", detail: "—" });
      }

      // service worker
      if ("serviceWorker" in navigator) {
        try {
          const reg =
            (await navigator.serviceWorker.getRegistration()) ??
            (await navigator.serviceWorker.ready);
          const active = !!reg?.active;
          set("sw", {
            status: active ? "ok" : "warn",
            detail: active
              ? "نشط — يحفظ الملفات ليعمل التطبيق أوفلاين"
              : "مسجّل لكن غير مفعّل بعد — أعد تحميل الصفحة",
          });
        } catch {
          set("sw", { status: "fail", detail: "التسجيل فشل" });
        }
      } else {
        set("sw", { status: "fail", detail: "المتصفح لا يدعم Service Worker" });
      }

      // storage
      try {
        const k = "__gypsum_test__";
        localStorage.setItem(k, "1");
        const ok = localStorage.getItem(k) === "1";
        localStorage.removeItem(k);
        set("storage", {
          status: ok ? "ok" : "warn",
          detail: ok ? "البيانات تُحفظ على الجهاز" : "غير متاح (وضع خاص؟)",
        });
      } catch {
        set("storage", { status: "warn", detail: "التخزين محجوب في هذا الوضع" });
      }
    };

    void run();
  }, []);

  const color = (s: Check["status"]) =>
    s === "ok"
      ? "text-emerald-600 bg-emerald-50 ring-emerald-200"
      : s === "warn"
        ? "text-amber-700 bg-amber-50 ring-amber-200"
        : s === "fail"
          ? "text-red-700 bg-red-50 ring-red-200"
          : "text-slate-500 bg-slate-50 ring-slate-200";

  const icon = (s: Check["status"]) =>
    s === "ok" ? "✓" : s === "warn" ? "!" : s === "fail" ? "✕" : "…";

  const score = checks.filter((c) => c.status === "ok").length;
  const installed =
    typeof window !== "undefined" &&
    (window.matchMedia("(display-mode: standalone)").matches ||
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window.navigator as any).standalone === true);

  return (
    <section className="anim-rise rounded-2xl bg-white p-4 card-soft">
      <div className="flex items-center justify-between">
        <h2 className="text-[14px] font-black text-slate-900">🧪 فحص جاهزية PWA</h2>
        <span
          className={`rounded-full px-2.5 py-1 text-[11px] font-black ${
            score >= 5
              ? "bg-emerald-100 text-emerald-700"
              : score >= 3
                ? "bg-amber-100 text-amber-700"
                : "bg-red-100 text-red-700"
          }`}
        >
          {score}/6 جاهز
        </span>
      </div>
      <p className="mt-1 text-[11px] font-bold text-slate-500">
        {installed
          ? "التطبيق يعمل الآن بوضع standalone ✓"
          : "افتح التطبيق في متصفح ثم «إضافة إلى الشاشة الرئيسية» ليعمل standalone."}
      </p>
      <ul className="mt-2.5 space-y-1.5">
        {checks.map((c) => (
          <li
            key={c.key}
            className={`flex items-start gap-2 rounded-xl px-2.5 py-2 ring-1 ${color(c.status)}`}
          >
            <span className="mt-0.5 grid h-4.5 w-4.5 shrink-0 place-items-center rounded-full bg-white/70 text-[10px] font-black">
              {icon(c.status)}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[12px] font-extrabold">{c.label}</span>
              <span className="block text-[10.5px] font-bold opacity-80">{c.detail}</span>
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
