"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import { calcSummary, type LocalExpense, type LocalPayment, type LocalProject } from "@/lib/types";
import { buildRequestPaymentText } from "@/lib/types";
import { buildStatementText, formatDate, formatMoney } from "@/lib/format";
import { TopBar, ImageViewer } from "./ui";
import { WhatsAppShare } from "./WhatsAppShare";

export function StatementView({ id }: { id: string }) {
  const router = useRouter();
  const { ready, projectById, paymentsOf, expensesOf } = useStore();
  const [serverFallback, setServerFallback] = useState<{
    project: LocalProject;
    payments: LocalPayment[];
    expenses: LocalExpense[];
  } | null>(null);
  const [viewImg, setViewImg] = useState<string | null>(null);

  const localProject = projectById(id);

  // إذا فُتح الرابط مباشرة بدون بيانات محلية، نجلب من السيرفر
  useEffect(() => {
    if (ready && !localProject) {
      fetch(`/api/projects/${id}`, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((j) => {
          if (!j) return;
          setServerFallback({
            project: {
              id: j.project.id,
              title: j.project.title,
              clientName: j.project.clientName,
              phone: j.project.phone ?? "",
              address: j.project.address ?? "",
              agreementTotal: Number(j.project.agreementTotal ?? 0),
              notes: j.project.notes ?? "",
              status: j.project.status ?? "active",
              createdAt: j.project.createdAt,
              updatedAt: j.project.updatedAt,
              _synced: true,
            },
            payments: (j.payments ?? []).map((r: Record<string, unknown>) => ({
              id: String(r.id),
              projectId: String(r.projectId),
              amount: Number(r.amount ?? 0),
              paidAt: String(r.paidAt),
              method: String(r.method ?? "cash"),
              note: String(r.note ?? ""),
              receiptImage: (r.receiptImage as string) ?? null,
              createdAt: String(r.createdAt),
              _synced: true,
            })),
            expenses: (j.expenses ?? []).map((r: Record<string, unknown>) => ({
              id: String(r.id),
              projectId: String(r.projectId),
              amount: Number(r.amount ?? 0),
              spentAt: String(r.spentAt),
              category: String(r.category ?? ""),
              vendor: String(r.vendor ?? ""),
              description: String(r.description ?? ""),
              invoiceImage: (r.invoiceImage as string) ?? null,
              createdAt: String(r.createdAt),
              _synced: true,
            })),
          });
        })
        .catch(() => {});
    }
  }, [ready, localProject, id]);

  const project = localProject ?? serverFallback?.project;
  const pays: LocalPayment[] = useMemo(
    () => (localProject ? paymentsOf(id) : serverFallback?.payments ?? []),
    [localProject, paymentsOf, id, serverFallback]
  );
  const exps: LocalExpense[] = useMemo(
    () => (localProject ? expensesOf(id) : serverFallback?.expenses ?? []),
    [localProject, expensesOf, id, serverFallback]
  );
  const s = useMemo(
    () => calcSummary(project?.agreementTotal ?? 0, pays, exps),
    [project?.agreementTotal, pays, exps]
  );

  const waText = project
    ? buildStatementText({
        title: project.title,
        clientName: project.clientName,
        agreementTotal: s.agreementTotal,
        totalReceived: s.totalReceived,
        totalExpenses: s.totalExpenses,
        cashInHand: s.cashInHand,
        remainingOnClient: s.remainingOnClient,
        paymentsCount: pays.length,
        expensesCount: exps.length,
      })
    : "";

  const requestText = project
    ? buildRequestPaymentText({
        title: project.title,
        clientName: project.clientName,
        totalReceived: s.totalReceived,
        remainingOnClient: s.remainingOnClient,
        deficit: s.deficit,
      })
    : "";

  if (!project) {
    return (
      <div className="min-h-dvh bg-[#F8FAFC]">
        <TopBar title="كشف الحساب" onBack={() => router.back()} />
        <main className="mx-auto max-w-md px-4 pt-10 text-center">
          <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-slate-200 border-t-[#D97706]" />
          <p className="mt-4 text-sm font-bold text-slate-500">جارٍ تجهيز كشف الحساب…</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[#F8FAFC]">
      <div className="no-print">
        <TopBar title="كشف الحساب النهائي" subtitle={project.title} onBack={() => router.back()} />
      </div>

      <main className="print-page mx-auto max-w-md px-4 pb-40 pt-4">
        {/* ─── ورقة الكشف ─── */}
        <article className="print-block overflow-hidden rounded-2xl bg-white card-soft">
          {/* الترويسة */}
          <div className="bg-[#1E293B] p-5 text-center text-white">
            <p className="text-2xl">🧱</p>
            <h1 className="mt-1 text-xl font-black">كشف حساب مشروع ديكور وجبس</h1>
            <p className="mt-1 text-[12px] font-bold text-slate-300">
              {formatDate(new Date().toISOString())} • كشف تفصيلي للمقبوضات والمصروفات
            </p>
          </div>

          {/* بيانات المشروع */}
          <div className="grid grid-cols-2 gap-2.5 p-4 text-[13px]">
            <div className="rounded-xl bg-slate-50 p-3">
              <p className="font-bold text-slate-400">🏠 المشروع</p>
              <p className="mt-0.5 font-extrabold text-slate-900">{project.title}</p>
            </div>
            <div className="rounded-xl bg-slate-50 p-3">
              <p className="font-bold text-slate-400">👤 صاحب البيت</p>
              <p className="mt-0.5 font-extrabold text-slate-900">{project.clientName}</p>
            </div>
            {project.phone && (
              <div className="rounded-xl bg-slate-50 p-3">
                <p className="font-bold text-slate-400">📞 الجوال</p>
                <p className="num mt-0.5 font-extrabold text-slate-900">{project.phone}</p>
              </div>
            )}
            {project.address && (
              <div className="rounded-xl bg-slate-50 p-3">
                <p className="font-bold text-slate-400">📍 العنوان</p>
                <p className="mt-0.5 font-extrabold text-slate-900">{project.address}</p>
              </div>
            )}
          </div>

          {/* الملخص */}
          <div className="mx-4 grid grid-cols-2 gap-2 rounded-2xl bg-[#1E293B] p-3 text-center">
            <div className="rounded-xl bg-white/[0.07] p-3">
              <p className="text-[11px] font-bold text-slate-300">قيمة الاتفاقية</p>
              <p className="num mt-0.5 text-[18px] font-black text-white">{formatMoney(s.agreementTotal)}</p>
            </div>
            <div className="rounded-xl bg-white/[0.07] p-3">
              <p className="text-[11px] font-bold text-emerald-300">إجمالي المقبوض</p>
              <p className="num mt-0.5 text-[18px] font-black text-emerald-300">{formatMoney(s.totalReceived)}</p>
            </div>
            <div className="rounded-xl bg-white/[0.07] p-3">
              <p className="text-[11px] font-bold text-rose-300">إجمالي المصروف</p>
              <p className="num mt-0.5 text-[18px] font-black text-rose-300">{formatMoney(s.totalExpenses)}</p>
            </div>
            <div className="rounded-xl bg-[#D97706]/30 p-3 ring-1 ring-[#D97706]/50">
              <p className="text-[11px] font-bold text-amber-300">المتبقي على الزبون</p>
              <p className="num mt-0.5 text-[18px] font-black text-amber-300">{formatMoney(s.remainingOnClient)}</p>
            </div>
          </div>

          {/* تنبيه العجز */}
          {s.isDeficit && (
            <div className="mx-4 mt-3 rounded-2xl bg-red-50 p-3.5 ring-2 ring-red-200">
              <p className="text-[13px] font-black text-red-800">🚨 عجز مؤقت في الكاش</p>
              <p className="num mt-0.5 text-[20px] font-black leading-none text-red-700">
                {formatMoney(s.deficit)} <span className="text-[11px] font-bold">ر.س</span>
              </p>
              <p className="num mt-1.5 rounded-lg bg-white/80 px-2 py-1.5 text-[11px] font-extrabold text-red-800 ring-1 ring-red-200">
                المصروفات {formatMoney(s.totalExpenses)} − المقبوضات {formatMoney(s.totalReceived)} = العجز {formatMoney(s.deficit)} ر.س
              </p>
              <p className="mt-1.5 text-[11px] font-bold leading-relaxed text-red-700/90">
                قيمة المشتريات تتجاوز المقبوضات، وتمت تغطية الفرق من جيب معلم الجبس كعهدة مؤقتة
                تُستقطع من الدفعة القادمة.
              </p>
            </div>
          )}

          {/* جدول الدفعات */}
          <div className="p-4">
            <h2 className="mb-2 text-[14px] font-black text-slate-800">
              ✅ الدفعات المقبوضة ({pays.length})
            </h2>
            {pays.length === 0 ? (
              <p className="rounded-xl bg-slate-50 py-3 text-center text-[12px] font-bold text-slate-400">
                لا توجد دفعات مسجلة
              </p>
            ) : (
              <table className="w-full overflow-hidden rounded-xl text-[12px]">
                <thead>
                  <tr className="bg-emerald-50 text-emerald-800">
                    <th className="px-2 py-2 text-right font-extrabold">#</th>
                    <th className="px-2 py-2 text-right font-extrabold">التاريخ</th>
                    <th className="px-2 py-2 text-right font-extrabold">البيان</th>
                    <th className="px-2 py-2 text-left font-extrabold">المبلغ</th>
                  </tr>
                </thead>
                <tbody>
                  {pays.map((p, i) => (
                    <tr key={p.id} className="border-t border-slate-100 font-bold text-slate-700">
                      <td className="num px-2 py-2">{i + 1}</td>
                      <td className="num px-2 py-2">{formatDate(p.paidAt)}</td>
                      <td className="px-2 py-2">{p.note || "دفعة"}</td>
                      <td className="num px-2 py-2 text-left font-black text-emerald-700">
                        {formatMoney(p.amount)}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-emerald-50 font-black text-emerald-800">
                    <td colSpan={3} className="px-2 py-2">الإجمالي</td>
                    <td className="num px-2 py-2 text-left">{formatMoney(s.totalReceived)} ر.س</td>
                  </tr>
                </tbody>
              </table>
            )}
          </div>

          {/* جدول المصروفات */}
          <div className="px-4 pb-4">
            <h2 className="mb-2 text-[14px] font-black text-slate-800">
              🧾 فواتير المشتريات ({exps.length})
            </h2>
            {exps.length === 0 ? (
              <p className="rounded-xl bg-slate-50 py-3 text-center text-[12px] font-bold text-slate-400">
                لا توجد فواتير مسجلة
              </p>
            ) : (
              <table className="w-full overflow-hidden rounded-xl text-[12px]">
                <thead>
                  <tr className="bg-rose-50 text-rose-800">
                    <th className="px-2 py-2 text-right font-extrabold">#</th>
                    <th className="px-2 py-2 text-right font-extrabold">التاريخ</th>
                    <th className="px-2 py-2 text-right font-extrabold">البيان</th>
                    <th className="px-2 py-2 text-left font-extrabold">المبلغ</th>
                  </tr>
                </thead>
                <tbody>
                  {exps.map((e, i) => (
                    <tr key={e.id} className="border-t border-slate-100 font-bold text-slate-700">
                      <td className="num px-2 py-2">{i + 1}</td>
                      <td className="num px-2 py-2">{formatDate(e.spentAt)}</td>
                      <td className="px-2 py-2">
                        {e.category}
                        {e.vendor ? ` — ${e.vendor}` : ""}
                        {e.description ? ` (${e.description})` : ""}
                        {e.invoiceImage && (
                          <button
                            onClick={() => setViewImg(e.invoiceImage)}
                            className="no-print mr-1.5 rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-extrabold text-slate-600"
                          >
                            📷 عرض
                          </button>
                        )}
                      </td>
                      <td className="num px-2 py-2 text-left font-black text-rose-700">
                        {formatMoney(e.amount)}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-rose-50 font-black text-rose-800">
                    <td colSpan={3} className="px-2 py-2">الإجمالي</td>
                    <td className="num px-2 py-2 text-left">{formatMoney(s.totalExpenses)} ر.س</td>
                  </tr>
                </tbody>
              </table>
            )}
          </div>

          {/* التوقيعات */}
          <div className="grid grid-cols-2 gap-4 border-t border-slate-100 p-5 text-center text-[12px]">
            <div>
              <p className="font-extrabold text-slate-700">توقيع معلم الجبس</p>
              <div className="mx-auto mt-6 w-3/4 border-t-2 border-dashed border-slate-300" />
              <p className="num mt-1 font-bold text-slate-400">التاريخ: … / … / …</p>
            </div>
            <div>
              <p className="font-extrabold text-slate-700">توقيع صاحب البيت</p>
              <div className="mx-auto mt-6 w-3/4 border-t-2 border-dashed border-slate-300" />
              <p className="num mt-1 font-bold text-slate-400">التاريخ: … / … / …</p>
            </div>
          </div>

          <div className="bg-slate-50 px-5 py-3 text-center text-[11px] font-bold text-slate-400">
            تم إصدار هذا الكشف من تطبيق حسابات معلم الجبس 🧱
          </div>
        </article>
      </main>

      {/* ─── أزرار التصدير ─── */}
      <div className="no-print fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto grid max-w-md grid-cols-2 gap-2.5 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
          <button
            onClick={() => {
              try {
                window.print();
              } catch {
                /* قد تُحجب داخل المعاينة */
              }
            }}
            className="rounded-2xl bg-[#1E293B] py-3.5 text-[14px] font-black text-white transition active:scale-[0.98]"
          >
            🖨 طباعة / PDF
          </button>
          <WhatsAppShare
            phone={project.phone}
            defaultNumber={project.phone}
            text={waText}
            label={project.phone ? "✈ واتساب صاحب البيت" : "✈ مشاركة واتساب"}
            className="rounded-2xl bg-[#25D366] py-3.5 text-center text-[14px] font-black text-white shadow-[0_8px_24px_rgba(37,211,102,0.3)] transition active:scale-[0.98]"
          />
        </div>
        <div className="mx-auto max-w-md px-4 pb-3">
          {s.isDeficit && (
            <WhatsAppShare
              phone={project.phone}
              defaultNumber={project.phone}
              text={requestText}
              label={`📩 اطلب دفعة لتغطية العجز (${formatMoney(s.deficit)} ر.س)`}
              className="mb-2 w-full rounded-xl bg-amber-100 py-2.5 text-center text-[12px] font-extrabold text-amber-800 ring-1 ring-amber-300"
            />
          )}
          <Link
            href={`/projects/${id}`}
            className="block rounded-xl bg-slate-100 py-2.5 text-center text-[13px] font-extrabold text-slate-600"
          >
            العودة للمشروع
          </Link>
        </div>
      </div>

      <ImageViewer src={viewImg} onClose={() => setViewImg(null)} />
    </div>
  );
}
