"use client";

import { useEffect, useState } from "react";

/**
 * تهيئة PWA:
 * - تسجيل Service Worker (للعمل بدون إنترنت).
 * - فحص التحديثات تلقائياً وتطبيقها بسلاسة.
 * - عرض تنبيه صغير عند توفر إصدار جديد.
 */
export function RootInit() {
  const [updateReady, setUpdateReady] = useState(false);
  const [reg, setReg] = useState<ServiceWorkerRegistration | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;

    let cancelled = false;

    const register = async () => {
      try {
        const registration = await navigator.serviceWorker.register("/sw.js", {
          scope: "/",
          updateViaCache: "none",
        });
        if (cancelled) return;
        setReg(registration);

        registration.addEventListener("updatefound", () => {
          const installing = registration.installing;
          if (!installing) return;
          installing.addEventListener("statechange", () => {
            if (
              installing.state === "installed" &&
              navigator.serviceWorker.controller
            ) {
              setUpdateReady(true);
            }
          });
        });
      } catch {
        /* التسجيل غير متاح (http بدون localhost) */
      }
    };

    if (document.readyState === "complete") void register();
    else window.addEventListener("load", () => void register(), { once: true });

    // فحص التحديث عند العودة إلى التطبيق
    const onVisible = () => {
      if (document.visibilityState === "visible") {
        void reg?.update().catch(() => null);
      }
    };
    document.addEventListener("visibilitychange", onVisible);

    // إعادة تحميل مرة واحدة بعد تفعيل عامل الخدمة الجديد
    let reloaded = false;
    const onControllerChange = () => {
      if (reloaded) return;
      reloaded = true;
      window.location.reload();
    };
    navigator.serviceWorker.addEventListener("controllerchange", onControllerChange);

    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", onVisible);
      navigator.serviceWorker.removeEventListener(
        "controllerchange",
        onControllerChange
      );
    };
  }, [reg]);

  if (!updateReady) return null;

  return (
    <div className="fixed inset-x-0 bottom-4 z-[70] flex justify-center px-4">
      <div className="anim-pop flex w-full max-w-md items-center gap-3 rounded-2xl bg-[#1E293B] px-4 py-3 text-white shadow-[0_12px_32px_rgba(15,23,42,0.4)]">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#D97706] text-base">
          ⬆
        </span>
        <p className="min-w-0 flex-1 text-[12px] font-extrabold leading-relaxed">
          إصدار جديد من التطبيق جاهز
        </p>
        <button
          onClick={() => {
            reg?.waiting?.postMessage("SKIP_WAITING");
            setUpdateReady(false);
          }}
          className="shrink-0 rounded-xl bg-white px-3 py-2 text-[12px] font-black text-[#1E293B]"
        >
          تحديث
        </button>
      </div>
    </div>
  );
}
