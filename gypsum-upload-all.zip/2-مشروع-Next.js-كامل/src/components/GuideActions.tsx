"use client";

import React, { useEffect, useState } from "react";
import { useInstallPrompt } from "./InstallBanner";
import { FileDownload } from "./FileDownload";
import { ShareSheet } from "./ShareSheet";
import { appUrl, copyText, openExternal } from "@/lib/share";

export function GuideActions() {
  const { canInstall, installed, install } = useInstallPrompt();
  const [shareable, setShareable] = useState(false);
  const [copied, setCopied] = useState(false);
  const [link, setLink] = useState("");
  const [note, setNote] = useState("");
  const [shareOpen, setShareOpen] = useState(false);

  useEffect(() => {
    setShareable(typeof navigator !== "undefined" && typeof navigator.share === "function");
    setLink(window.location.origin);
  }, []);

  const share = async () => {
    const text = `تطبيق حسابات معلم الجبس 🧱\nإدارة المشاريع والمقبوضات والمصروفات وكشوف الحساب — يعمل بدون إنترنت.\n${link}`;
    try {
      if (typeof navigator.share === "function") {
        await navigator.share({ title: "حسابات معلم الجبس", text, url: link });
        return;
      }
    } catch {
      /* محجوب أو ألغي — نستخدم النسخ */
    }
    const ok = await copyText(text);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
      setNote("");
    } else {
      setShareOpen(true);
    }
  };

  return (
    <section className="rounded-2xl bg-white p-4 card-soft">
      <p className="text-[12px] font-extrabold text-slate-500">رابط التطبيق</p>
      <div className="mt-1.5 flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2.5 ring-1 ring-slate-200">
        <span className="num min-w-0 flex-1 truncate text-[12px] font-bold text-slate-700" dir="ltr">
          {link || "…"}
        </span>
        <button
          onClick={async () => {
            const ok = await copyText(link);
            if (ok) {
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            } else {
              setShareOpen(true);
            }
          }}
          className="shrink-0 rounded-lg bg-white px-2.5 py-1.5 text-[11px] font-extrabold text-slate-600 ring-1 ring-slate-200"
        >
          {copied ? "✓ نُسخ" : "نسخ"}
        </button>
      </div>

      <div className="mt-2.5 grid grid-cols-2 gap-2">
        {canInstall && !installed ? (
          <button
            onClick={() => void install()}
            className="rounded-xl bg-[#D97706] py-3 text-[12.5px] font-black text-white transition active:scale-95"
          >
            ⬇ تثبيت التطبيق
          </button>
        ) : (
          <div className="rounded-xl bg-emerald-50 py-3 text-center text-[12px] font-extrabold text-emerald-700 ring-1 ring-emerald-200">
            {installed ? "✅ مثبّت" : "استخدم قائمة المتصفح"}
          </div>
        )}
        <button
          onClick={() => void share()}
          className="rounded-xl bg-[#25D366] py-3 text-[12.5px] font-black text-white transition active:scale-95"
        >
          {shareable ? "↗ مشاركة" : "📋 نسخ ودعوة"}
        </button>
      </div>
      {note && (
        <p className="mt-2 text-center text-[11px] font-bold text-amber-700">{note}</p>
      )}

      <FileDownload
        url="/downloads/gypsum-offline.html"
        filename="حسابات-معلم-الجبس.html"
        className="mt-2.5 flex w-full items-center justify-between rounded-xl bg-emerald-600 px-3 py-3 text-white transition active:scale-[0.99]"
        title="📴 تنزيل التطبيق المستقل"
        subtitle="ملف واحد يعمل بدون إنترنت على أي جوال"
      >
        <span className="text-[12.5px] font-extrabold">📴 تنزيل التطبيق كملف واحد</span>
        <span className="text-[11px] font-bold text-emerald-50">يعمل بدون إنترنت</span>
      </FileDownload>

      <FileDownload
        url="/downloads/gypsum-app-source.zip"
        filename="gypsum-app-source.zip"
        className="mt-2.5 flex w-full items-center justify-between rounded-xl bg-slate-900 px-3 py-3 text-white transition active:scale-[0.99]"
        title="📦 كود المشروع"
        subtitle="مشروع كامل مع README للتشغيل والنشر"
      >
        <span className="text-[12.5px] font-extrabold">📦 تنزيل كود المشروع (ZIP)</span>
        <span className="text-[11px] font-bold text-slate-300">يشمل README</span>
      </FileDownload>

      <button
        onClick={() => openExternal(appUrl())}
        className="mt-2.5 w-full rounded-xl bg-white px-3 py-3 text-[12.5px] font-extrabold text-[#92400E] ring-1 ring-amber-300"
      >
        ↗ فتح التطبيق في نافذة مستقلة
      </button>

      <ShareSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        title="📤 مشاركة التطبيق"
        subtitle="انسخ الرابط أو النص وألصقه في واتساب"
        waText={`تطبيق حسابات معلم الجبس 🧱\nإدارة المشاريع والمقبوضات والمصروفات وكشوف الحساب — يعمل بدون إنترنت.\n${link}`}
        fileUrl="/downloads/gypsum-offline.html"
        fileLabel="فتح النسخة المستقلة (ملف واحد)"
      />
    </section>
  );
}
