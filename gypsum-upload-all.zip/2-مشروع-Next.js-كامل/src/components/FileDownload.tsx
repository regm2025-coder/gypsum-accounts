"use client";

import React, { useEffect, useState } from "react";
import {
  absoluteUrl,
  copyText,
  forcedDownloadUrl,
  isEmbedded,
  navigateTop,
} from "@/lib/share";
import { Sheet } from "./ui";

/**
 * زر تنزيل يعمل في كل البيئات:
 * - متصفح عادي: تنزيل مباشر بخواص إجبارية.
 * - داخل إطار المعاينة (يحجب التنزيل): يفتح ورقة بخيارات
 *   «افتح في النافذة الرئيسية» و«تنزيل مباشر» و«نسخ الرابط».
 */
export function FileDownload({
  url,
  filename,
  className = "",
  children,
  title = "⬇ تنزيل الملف",
  subtitle = "اختر طريقة التنزيل المناسبة",
}: {
  url: string;
  filename?: string;
  className?: string;
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
}) {
  const [open, setOpen] = useState(false);
  const [embedded, setEmbedded] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setEmbedded(isEmbedded());
  }, []);

  const forced = forcedDownloadUrl(url);
  const absolute = absoluteUrl(url);

  if (!embedded) {
    return (
      <a href={forced} download={filename} className={className}>
        {children}
      </a>
    );
  }

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={className}>
        {children}
      </button>

      <Sheet open={open} onClose={() => setOpen(false)} title={title} subtitle={subtitle}>
        <div className="space-y-2.5">
          <div className="rounded-xl bg-red-50 px-3 py-2.5 ring-1 ring-red-200">
            <p className="text-[12px] font-extrabold leading-relaxed text-red-800">
              🚫 أنت داخل معاينة محمية، والمتصفح يمنع التنزيل من الداخل. اضغط الزر الأول
              بالأسفل — سيفتح الملف في نافذة المتصفح الرئيسية ويُنزَّل فوراً.
            </p>
          </div>

          <button
            onClick={() => {
              setOpen(false);
              navigateTop(forced);
            }}
            className="w-full rounded-2xl bg-[#D97706] py-4 text-[15px] font-black text-white shadow-[0_8px_24px_rgba(217,119,6,0.35)] transition active:scale-[0.98]"
          >
            ⬇ تنزيل في النافذة الرئيسية
          </button>

          <button
            onClick={() => {
              setOpen(false);
              navigateTop(url);
            }}
            className="w-full rounded-2xl bg-[#1E293B] py-3.5 text-[14px] font-black text-white transition active:scale-[0.98]"
          >
            ↗ فتح الملف مباشرة (بدون تنزيل)
          </button>

          <a
            href={forced}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full rounded-2xl bg-emerald-600 py-3.5 text-center text-[14px] font-black text-white transition active:scale-[0.98]"
          >
            ⬇ تنزيل مباشر (رابط بخواص إجبارية)
          </a>

          <div className="rounded-2xl bg-white p-3 card-soft">
            <p className="text-[11.5px] font-extrabold text-slate-500">أو انسخ الرابط:</p>
            <div
              className="num mt-1.5 max-h-20 select-all overflow-auto break-all rounded-xl bg-slate-50 px-3 py-2 text-[11px] font-bold text-slate-600 ring-1 ring-slate-200"
              dir="ltr"
            >
              {absolute}
            </div>
            <button
              onClick={async () => {
                const ok = await copyText(absolute);
                setCopied(ok);
                setTimeout(() => setCopied(false), 2000);
              }}
              className="mt-2 w-full rounded-xl bg-slate-100 py-3 text-[13px] font-extrabold text-slate-700"
            >
              {copied ? "✅ تم نسخ الرابط — ألصقه في المتصفح" : "📋 نسخ رابط الملف"}
            </button>
            <p className="mt-2 text-[10.5px] font-bold leading-relaxed text-slate-400">
              إن فشل كل ذلك: انسخ الرابط وافتحه في متصفح جديد (كروم) — سيُنزَّل الملف مباشرة.
              يمكنك أيضاً إرساله لنفسك على واتساب وفتحه من هناك.
            </p>
          </div>
        </div>
      </Sheet>
    </>
  );
}
