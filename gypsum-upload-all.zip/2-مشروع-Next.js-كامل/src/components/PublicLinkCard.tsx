"use client";

import React, { useEffect, useState } from "react";
import {
  appUrl,
  copyText,
  isEmbedded,
  isUnshareableHost,
  openExternal,
} from "@/lib/share";
import { FileDownload } from "./FileDownload";
import { ShareSheet } from "./ShareSheet";

/**
 * بطاقة «شارك التطبيق»:
 * تعرض الرابط الصحيح للتطبيق + كود QR لمسحه بالجوال مباشرة،
 * وتنبّه إن كان المستخدم يفتح رابط منصة معاينة لا يعمل لغير المالك.
 */
export function PublicLinkCard({ compact = false }: { compact?: boolean }) {
  const [url, setUrl] = useState("");
  const [embedded, setEmbedded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [showQr, setShowQr] = useState(false);

  useEffect(() => {
    setUrl(appUrl());
    setEmbedded(isEmbedded());
  }, []);

  const badHost = isUnshareableHost(url);
  const waText = `تطبيق حسابات معلم الجبس 🧱\nإدارة المشاريع والمقبوضات والمصروفات وكشوف الحساب — يعمل بدون إنترنت.\n${url}`;

  return (
    <>
      <section
        className={`anim-rise overflow-hidden rounded-2xl bg-gradient-to-br from-[#0F172A] to-[#1E293B] p-4 text-white card-soft ${
          compact ? "" : "ring-1 ring-white/10"
        }`}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[13.5px] font-black">📤 شارك التطبيق مع صديقك</p>
            <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-slate-300">
              استخدم هذا الرابط بالضبط — هو الذي يفتح على جوال أي شخص.
            </p>
          </div>
          <button
            onClick={() => setShowQr((v) => !v)}
            className="shrink-0 rounded-xl bg-white/10 px-3 py-2 text-[11px] font-extrabold transition active:scale-95"
          >
            {showQr ? "إخفاء QR" : "كود QR"}
          </button>
        </div>

        {/* الرابط */}
        <div className="mt-2.5 flex items-center gap-2 rounded-xl bg-white/95 px-3 py-2.5">
          <span
            className="num min-w-0 flex-1 truncate text-[11.5px] font-bold text-slate-700"
            dir="ltr"
          >
            {url || "…"}
          </span>
          <button
            onClick={async () => {
              const ok = await copyText(url);
              if (ok) {
                setCopied(true);
                setTimeout(() => setCopied(false), 2200);
              } else {
                setShareOpen(true);
              }
            }}
            className={`shrink-0 rounded-lg px-2.5 py-1.5 text-[11px] font-extrabold transition active:scale-95 ${
              copied ? "bg-emerald-600 text-white" : "bg-[#D97706] text-white"
            }`}
          >
            {copied ? "✓ نُسخ" : "نسخ"}
          </button>
        </div>

        {badHost && (
          <p className="mt-2 rounded-xl bg-red-500/20 px-3 py-2 text-[11px] font-extrabold leading-relaxed text-red-200 ring-1 ring-red-400/40">
            ⚠️ هذا رابط منصة معاينة خاص (arena.site) ولن يفتح عند غيرك. افتح التطبيق في
            نافذة مستقلة ثم انسخ الرابط من هناك، أو استخدم كود QR بالأسفل.
          </p>
        )}

        {/* QR */}
        {showQr && (
          <div className="anim-pop mt-3 rounded-2xl bg-white p-3 text-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`/api/qr?size=320&text=${encodeURIComponent(url)}`}
              alt="كود QR لرابط التطبيق"
              width={220}
              height={220}
              className="mx-auto h-[220px] w-[220px] rounded-xl"
            />
            <p className="mt-1.5 text-[11px] font-extrabold text-slate-600">
              📷 امسح الكود بكاميرا الجوال لفتح التطبيق مباشرة
            </p>
            <a
              href={`/api/qr?size=700&text=${encodeURIComponent(url)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-block rounded-lg bg-slate-100 px-3 py-1.5 text-[11px] font-extrabold text-slate-600"
            >
              فتح الكود بحجم كبير
            </a>
          </div>
        )}

        {/* أزرار */}
        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            onClick={() => setShareOpen(true)}
            className="rounded-xl bg-[#25D366] py-2.5 text-[12px] font-black text-white transition active:scale-95"
          >
            ✈ إرسال واتساب
          </button>
          <button
            onClick={() => openExternal(url)}
            className="rounded-xl bg-white/10 py-2.5 text-[12px] font-black text-white transition active:scale-95"
          >
            ↗ نافذة مستقلة
          </button>
        </div>

        <FileDownload
          url="/downloads/gypsum-offline.html"
          filename="حسابات-معلم-الجبس.html"
          className="mt-2 block w-full rounded-xl bg-[#D97706] py-2.5 text-center text-[12px] font-black text-white transition active:scale-[0.98]"
          title="📴 النسخة المستقلة"
          subtitle="ملف واحد يعمل بدون إنترنت — أرسله على واتساب"
        >
          📴 تنزيل نسخة تعمل بدون إنترنت
        </FileDownload>

        {embedded && (
          <p className="mt-2 text-center text-[10px] font-bold text-slate-400">
            أنت داخل معاينة — زر «نافذة مستقلة» يفتح التطبيق برابطه الصحيح
          </p>
        )}
      </section>

      <ShareSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        title="📤 مشاركة التطبيق"
        subtitle="انسخ الرابط أو أرسله على واتساب"
        waText={waText}
        fileUrl="/downloads/gypsum-offline.html"
        fileLabel="فتح النسخة المستقلة (ملف واحد)"
      />
    </>
  );
}
