"use client";

import React, { useEffect, useState } from "react";
import { useStore } from "@/lib/store";
import { calcSummary, EXPENSE_CATEGORIES, PAYMENT_METHODS, type LocalPayment, type LocalProject } from "@/lib/types";
import { formatMoney, toInputDate } from "@/lib/format";
import { FieldWrap, GoldButton, Sheet } from "./ui";
import { ImagePicker } from "./ImagePicker";

// ─── إضافة مشروع جديد ───
export function AddProjectSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { addProject, addPayment } = useStore();
  const [title, setTitle] = useState("");
  const [clientName, setClientName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [total, setTotal] = useState("");
  const [notes, setNotes] = useState("");
  const [down, setDown] = useState("");
  const [err, setErr] = useState("");

  const reset = () => {
    setTitle("");
    setClientName("");
    setPhone("");
    setAddress("");
    setTotal("");
    setNotes("");
    setDown("");
    setErr("");
  };

  const submit = () => {
    if (!title.trim() || !clientName.trim()) {
      setErr("فضلاً أدخل اسم المشروع واسم صاحب البيت");
      return;
    }
    const amount = Number(total) || 0;
    if (amount <= 0) {
      setErr("فضلاً أدخل قيمة الاتفاقية (أكبر من صفر)");
      return;
    }
    const created = addProject({
      title,
      clientName,
      phone,
      address,
      agreementTotal: amount,
      notes,
    });
    // الدفعة المقدمة تُسجَّل كمقبوض حقيقي — وهي أساس حساب العجز/الفائض
    const downAmount = Number(down) || 0;
    if (downAmount > 0) {
      addPayment({
        projectId: created.id,
        amount: downAmount,
        paidAt: new Date().toISOString(),
        method: "cash",
        note: "دفعة مقدمة عند الاتفاق",
        receiptImage: null,
      });
    }
    reset();
    onClose();
  };

  return (
    <Sheet open={open} onClose={() => { reset(); onClose(); }} title="➕ مشروع جديد" subtitle="أدخل بيانات الاتفاقية مع صاحب البيت">
      <div className="space-y-3.5">
        <FieldWrap label="اسم المشروع / وصف الشغل">
          <input className="field" placeholder="مثال: مجلس + صالة — حي النرجس" value={title} onChange={(e) => setTitle(e.target.value)} />
        </FieldWrap>
        <div className="grid grid-cols-2 gap-3">
          <FieldWrap label="اسم صاحب البيت">
            <input className="field" placeholder="مثال: أبو محمد" value={clientName} onChange={(e) => setClientName(e.target.value)} />
          </FieldWrap>
          <FieldWrap label="الجوال">
            <input className="field num" inputMode="tel" placeholder="05xxxxxxxx" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </FieldWrap>
        </div>
        <FieldWrap label="العنوان / الحي">
          <input className="field" placeholder="مثال: الرياض — حي الياسمين" value={address} onChange={(e) => setAddress(e.target.value)} />
        </FieldWrap>
        <FieldWrap
          label="💰 إجمالي قيمة الاتفاقية (ر.س)"
          hint="المبلغ المتفق عليه كاملاً — وليس المبلغ المدفوع"
        >
          <input
            className="field num !border-amber-300 !bg-amber-50 text-center text-xl font-black text-[#92400E]"
            inputMode="decimal"
            type="number"
            min="0"
            placeholder="0"
            value={total}
            onChange={(e) => setTotal(e.target.value)}
          />
        </FieldWrap>

        {/* الدفعة المقدمة */}
        <div className="rounded-2xl bg-emerald-50 p-3.5 ring-1 ring-emerald-200">
          <div className="mb-2 flex items-center justify-between gap-2">
            <span className="text-[13px] font-extrabold text-emerald-800">
              💵 استلمت دفعة مقدمة الآن؟
            </span>
            {Number(total) > 0 && (
              <button
                type="button"
                onClick={() => setDown(down === total ? "" : total)}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-extrabold ring-1 transition active:scale-95 ${
                  down === total
                    ? "bg-emerald-600 text-white ring-emerald-600"
                    : "bg-white text-emerald-700 ring-emerald-300"
                }`}
              >
                دفع كامل الاتفاقية
              </button>
            )}
          </div>
          <input
            className="field num !border-emerald-300 !bg-white text-center text-lg font-black text-emerald-700"
            inputMode="decimal"
            type="number"
            min="0"
            placeholder="0"
            value={down}
            onChange={(e) => setDown(e.target.value)}
          />
          <p className="mt-1.5 text-[11px] font-bold leading-relaxed text-emerald-700/80">
            تُسجَّل تلقائياً كأول دفعة مقبوضة. بدونها سيعتبر النظام أن رصيدك صفر
            ويظهر العجز كاملاً عند تسجيل المشتريات.
          </p>
          {Number(down) > Number(total) && Number(total) > 0 && (
            <p className="mt-1.5 rounded-lg bg-amber-100 px-2 py-1.5 text-[11px] font-extrabold text-amber-800">
              ⚠️ الدفعة المقدمة أكبر من قيمة الاتفاقية بـ {formatMoney(Number(down) - Number(total))} ر.س
            </p>
          )}
        </div>

        <FieldWrap label="ملاحظات">
          <textarea className="field min-h-16" rows={2} placeholder="تفاصيل الاتفاقية، الدفعات المتفق عليها…" value={notes} onChange={(e) => setNotes(e.target.value)} />
        </FieldWrap>
        {err && (
          <p className="rounded-xl bg-red-50 px-3 py-2.5 text-center text-[13px] font-bold text-red-600">{err}</p>
        )}
        <GoldButton onClick={submit}>حفظ المشروع ✓</GoldButton>
      </div>
    </Sheet>
  );
}

// ─── تعديل مشروع ───
export function EditProjectSheet({
  project,
  onClose,
}: {
  project: LocalProject | null;
  onClose: () => void;
}) {
  const { updateProject } = useStore();
  const [title, setTitle] = useState("");
  const [clientName, setClientName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [total, setTotal] = useState("");
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState<LocalProject["status"]>("active");

  useEffect(() => {
    if (project) {
      setTitle(project.title);
      setClientName(project.clientName);
      setPhone(project.phone);
      setAddress(project.address);
      setTotal(String(project.agreementTotal));
      setNotes(project.notes);
      setStatus(project.status);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project?.id]);

  const submit = () => {
    if (!project) return;
    updateProject(project.id, {
      title: title.trim() || project.title,
      clientName: clientName.trim() || project.clientName,
      phone: phone.trim(),
      address: address.trim(),
      agreementTotal: Number(total) || project.agreementTotal,
      notes: notes.trim(),
      status,
    });
    onClose();
  };

  return (
    <Sheet open={!!project} onClose={onClose} title="✏️ تعديل المشروع" subtitle="تحديث بيانات الاتفاقية">
      <div className="space-y-3.5">
        <FieldWrap label="اسم المشروع">
          <input className="field" value={title} onChange={(e) => setTitle(e.target.value)} />
        </FieldWrap>
        <div className="grid grid-cols-2 gap-3">
          <FieldWrap label="اسم صاحب البيت">
            <input className="field" value={clientName} onChange={(e) => setClientName(e.target.value)} />
          </FieldWrap>
          <FieldWrap label="الجوال">
            <input className="field num" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </FieldWrap>
        </div>
        <FieldWrap label="العنوان">
          <input className="field" value={address} onChange={(e) => setAddress(e.target.value)} />
        </FieldWrap>
        <FieldWrap label="قيمة الاتفاقية (ر.س)">
          <input className="field num text-center text-lg font-black" type="number" min="0" value={total} onChange={(e) => setTotal(e.target.value)} />
        </FieldWrap>
        <FieldWrap label="حالة المشروع">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { v: "active", l: "نشط 🟢" },
                { v: "paused", l: "متوقف ⏸" },
                { v: "completed", l: "مكتمل ✅" },
              ] as const
            ).map((s) => (
              <button
                key={s.v}
                type="button"
                onClick={() => setStatus(s.v)}
                className={`rounded-xl border-2 py-2.5 text-[13px] font-extrabold transition ${
                  status === s.v
                    ? "border-[#D97706] bg-amber-50 text-[#92400E]"
                    : "border-slate-200 bg-white text-slate-500"
                }`}
              >
                {s.l}
              </button>
            ))}
          </div>
        </FieldWrap>
        <FieldWrap label="ملاحظات">
          <textarea className="field" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </FieldWrap>
        <GoldButton onClick={submit}>حفظ التعديلات ✓</GoldButton>
      </div>
    </Sheet>
  );
}

// ─── تنبيه مالي ملوّن ───
function AlertBox({
  tone,
  title,
  children,
}: {
  tone: "danger" | "warning" | "success" | "info";
  title: string;
  children?: React.ReactNode;
}) {
  const map = {
    danger: "bg-red-50 text-red-700 ring-red-200",
    warning: "bg-amber-50 text-amber-800 ring-amber-200",
    success: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    info: "bg-sky-50 text-sky-800 ring-sky-200",
  } as const;
  return (
    <div className={`rounded-xl px-3 py-2.5 ring-1 ${map[tone]}`}>
      <p className="text-[13px] font-extrabold leading-relaxed">{title}</p>
      {children && (
        <div className="mt-1 text-[12px] font-bold leading-relaxed opacity-90">
          {children}
        </div>
      )}
    </div>
  );
}

// ─── إضافة دفعة مقبوضة ───
export function AddPaymentSheet({
  open,
  onClose,
  projectId,
  initialAmount,
  initialNote,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  initialAmount?: number;
  initialNote?: string;
}) {
  const { addPayment, paymentsOf, expensesOf, projectById } = useStore();
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(() => toInputDate(new Date().toISOString()));
  const [method, setMethod] = useState<LocalPayment["method"]>("cash");
  const [note, setNote] = useState("");
  const [img, setImg] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [ack, setAck] = useState(false);

  // تعبئة مسبقة (مثل: تسجيل الدفعة المقدمة المستحقة)
  useEffect(() => {
    if (open) {
      if (initialAmount && initialAmount > 0) setAmount(String(initialAmount));
      if (initialNote) setNote(initialNote);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const project = projectById(projectId);
  const summary = calcSummary(project?.agreementTotal ?? 0, paymentsOf(projectId), expensesOf(projectId));
  const amt = Number(amount) || 0;
  const newRemaining = summary.remainingOnClient - amt;
  const isOver = amt > 0 && newRemaining < 0;
  const coversDeficit = summary.isDeficit && amt > 0;

  const submit = () => {
    const v = Number(amount) || 0;
    if (v <= 0) {
      setErr("فضلاً أدخل مبلغ الدفعة");
      return;
    }
    if (isOver && !ack) {
      setErr("المبلغ أكبر من المتبقي على صاحب البيت — يرجى تأكيد التنبيه أولاً");
      return;
    }
    addPayment({
      projectId,
      amount: v,
      paidAt: new Date(date + "T12:00:00").toISOString(),
      method,
      note,
      receiptImage: img,
    });
    setAmount("");
    setNote("");
    setImg(null);
    setErr("");
    setAck(false);
    setDate(toInputDate(new Date().toISOString()));
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} title="💵 دفعة مقبوضة جديدة" subtitle="سجّل المبلغ المستلم من صاحب البيت">
      <div className="space-y-3.5">
        {/* الوضع الحالي */}
        <div className="rounded-xl bg-slate-100 px-3 py-2 text-center">
          <p className="num text-[11px] font-extrabold text-slate-500">
            الاتفاقية {formatMoney(summary.agreementTotal)} • المقبوض حتى الآن{" "}
            <span className="text-emerald-700">{formatMoney(summary.totalReceived)}</span>
          </p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-amber-50 p-2.5 text-center">
            <p className="text-[11px] font-bold text-amber-600">📌 المتبقي على صاحب البيت</p>
            <p className="num text-[16px] font-black text-[#92400E]">{formatMoney(summary.remainingOnClient)}</p>
          </div>
          <div className={`rounded-xl p-2.5 text-center ${summary.isDeficit ? "bg-red-50" : "bg-emerald-50"}`}>
            <p className={`text-[11px] font-bold ${summary.isDeficit ? "text-red-600" : "text-emerald-600"}`}>
              {summary.isDeficit ? "🚨 العجز الحالي" : "💵 الكاش باليد"}
            </p>
            <p className={`num text-[16px] font-black ${summary.isDeficit ? "text-red-700" : "text-emerald-700"}`}>
              {formatMoney(Math.abs(summary.cashInHand))}
            </p>
          </div>
        </div>

        {summary.isDeficit && (
          <AlertBox tone="warning" title={`🚨 يوجد عجز حالي ${formatMoney(summary.deficit)} ر.س`}>
            هذه الدفعة ستُستخدم أولاً لتغطية العجز المدفوع من جيبك.
          </AlertBox>
        )}

        <FieldWrap label="المبلغ المقبوض (ر.س)">
          <input
            className="field num !border-emerald-300 !bg-emerald-50 text-center text-2xl font-black text-emerald-700"
            type="number"
            min="0"
            inputMode="decimal"
            placeholder="0"
            autoFocus
            value={amount}
            onChange={(e) => { setAmount(e.target.value); setErr(""); }}
          />
        </FieldWrap>
        {/* أزرار مبالغ سريعة */}
        <div className="grid grid-cols-5 gap-1.5">
          {[500, 1000, 2000, 5000].map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => setAmount(String((Number(amount) || 0) + q))}
              className="num rounded-xl bg-emerald-50 py-2 text-[12px] font-extrabold text-emerald-700 transition active:scale-95"
            >
              +{q.toLocaleString("en-US")}
            </button>
          ))}
          {summary.remainingOnClient > 0 && (
            <button
              type="button"
              onClick={() => setAmount(String(summary.remainingOnClient))}
              className="num rounded-xl bg-[#1E293B] py-2 text-[11px] font-extrabold text-white transition active:scale-95"
            >
              الباقي كامل
            </button>
          )}
        </div>

        {/* معاينة النتيجة */}
        {amt > 0 && (
          <div className="rounded-xl bg-slate-50 p-3">
            <p className="text-[11px] font-extrabold text-slate-500">بعد تسجيل هذه الدفعة:</p>
            <div className="mt-1.5 flex items-center justify-between text-[12px] font-extrabold">
              <span className="text-slate-600">المتبقي على صاحب البيت</span>
              <span className={`num ${newRemaining < 0 ? "text-red-600" : "text-[#92400E]"}`}>
                {formatMoney(newRemaining)} ر.س
              </span>
            </div>
            <div className="mt-1 flex items-center justify-between text-[12px] font-extrabold">
              <span className="text-slate-600">الكاش باليد</span>
              <span className={`num ${summary.cashInHand + amt < 0 ? "text-red-600" : "text-emerald-700"}`}>
                {formatMoney(summary.cashInHand + amt)} ر.س
              </span>
            </div>
            {coversDeficit && (
              <p className="mt-2 rounded-lg bg-emerald-100 px-2 py-1.5 text-[11px] font-extrabold text-emerald-800">
                {summary.cashInHand + amt >= 0
                  ? "✅ ستنتهي حالة العجز نهائياً بعد هذه الدفعة"
                  : `✅ ستنخفض نسبة العجز إلى ${formatMoney(Math.abs(summary.cashInHand + amt))} ر.س`}
              </p>
            )}
          </div>
        )}

        {isOver && (
          <AlertBox tone="danger" title={`⚠️ المبلغ أكبر من المتبقي على صاحب البيت بـ ${formatMoney(Math.abs(newRemaining))} ر.س`}>
            تأكد من قيمة الاتفاقية أو من الدفعات المسجلة قبل الحفظ.
            <label className="mt-2 flex cursor-pointer items-center gap-2 rounded-lg bg-white px-2.5 py-2 text-[12px] font-extrabold text-red-700 ring-1 ring-red-200">
              <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="h-4 w-4 accent-red-600" />
              أفهم ذلك وأريد حفظ الدفعة
            </label>
          </AlertBox>
        )}

        <div className="grid grid-cols-2 gap-3">
          <FieldWrap label="التاريخ">
            <input type="date" className="field num" value={date} onChange={(e) => setDate(e.target.value)} />
          </FieldWrap>
          <FieldWrap label="طريقة الدفع">
            <select className="field" value={method} onChange={(e) => setMethod(e.target.value as LocalPayment["method"])}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </select>
          </FieldWrap>
        </div>
        <FieldWrap label="ملاحظة">
          <input className="field" placeholder="مثال: الدفعة الثانية" value={note} onChange={(e) => setNote(e.target.value)} />
        </FieldWrap>
        <ImagePicker value={img} onChange={setImg} label="صورة السند / الإيصال" />
        {err && <p className="rounded-xl bg-red-50 px-3 py-2.5 text-center text-[13px] font-bold text-red-600">{err}</p>}
        <GoldButton onClick={submit} disabled={isOver && !ack}>حفظ الدفعة ✓</GoldButton>
      </div>
    </Sheet>
  );
}

// ─── إضافة فاتورة مشتريات ───
export function AddExpenseSheet({
  open,
  onClose,
  projectId,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
}) {
  const { addExpense, paymentsOf, expensesOf, projectById } = useStore();
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(() => toInputDate(new Date().toISOString()));
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]);
  const [vendor, setVendor] = useState("");
  const [desc, setDesc] = useState("");
  const [img, setImg] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [ack, setAck] = useState(false);

  const project = projectById(projectId);
  const summary = calcSummary(project?.agreementTotal ?? 0, paymentsOf(projectId), expensesOf(projectId));
  const available = summary.cashInHand; // الكاش المتاح فعلياً (قد يكون سالباً)
  const amt = Number(amount) || 0;
  const cashAfter = available - amt;
  const newDeficit = cashAfter < 0 ? Math.abs(cashAfter) : 0;
  const willDeficit = amt > 0 && cashAfter < 0;

  const submit = () => {
    const v = Number(amount) || 0;
    if (v <= 0) {
      setErr("فضلاً أدخل قيمة الفاتورة");
      return;
    }
    if (willDeficit && !ack) {
      setErr("هذه الفاتورة تُحدث عجزاً — يرجى تأكيد التنبيه أولاً");
      return;
    }
    addExpense({
      projectId,
      amount: v,
      spentAt: new Date(date + "T12:00:00").toISOString(),
      category,
      vendor,
      description: desc,
      invoiceImage: img,
    });
    setAmount("");
    setVendor("");
    setDesc("");
    setImg(null);
    setErr("");
    setAck(false);
    setDate(toInputDate(new Date().toISOString()));
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} title="🧾 فاتورة مشتريات جديدة" subtitle="سجّل مصروفات المواد والأجور">
      <div className="space-y-3.5">
        {/* الكاش المتاح */}
        <div className={`rounded-xl p-3 text-center ring-1 ${available < 0 ? "bg-red-50 ring-red-200" : "bg-emerald-50 ring-emerald-200"}`}>
          <p className={`text-[11px] font-extrabold ${available < 0 ? "text-red-600" : "text-emerald-600"}`}>
            {available < 0 ? "🚨 عجز حالي — تدعم من جيبك" : "💵 الكاش المتاح لديك الآن"}
          </p>
          <p className={`num text-[22px] font-black leading-tight ${available < 0 ? "text-red-700" : "text-emerald-700"}`}>
            {formatMoney(Math.abs(available))} <span className="text-[12px]">ر.س</span>
          </p>
          <p className="num mt-0.5 text-[11px] font-bold text-slate-500">
            المقبوض {formatMoney(summary.totalReceived)} − المصروف {formatMoney(summary.totalExpenses)}
          </p>
        </div>

        <FieldWrap label="قيمة الفاتورة (ر.س)">
          <input
            className="field num !border-rose-300 !bg-rose-50 text-center text-2xl font-black text-rose-700"
            type="number"
            min="0"
            inputMode="decimal"
            placeholder="0"
            autoFocus
            value={amount}
            onChange={(e) => { setAmount(e.target.value); setErr(""); }}
          />
        </FieldWrap>

        {/* تنبيه العجز الحي */}
        {willDeficit ? (
          <AlertBox
            tone="danger"
            title={`🚨 تنبيه عجز: ${formatMoney(newDeficit)} ر.س`}
          >
            <span className="num block rounded-lg bg-white/70 px-2 py-1.5 text-[11px] font-extrabold text-red-800 ring-1 ring-red-200">
              العجز = المصروفات بعد الفاتورة − المقبوضات = {formatMoney(summary.totalExpenses + amt)} − {formatMoney(summary.totalReceived)} = {formatMoney(newDeficit)}
            </span>
            ستدفع الفرق <b className="num">{formatMoney(newDeficit)} ر.س</b> من جيبك حتى تستلم الدفعة القادمة.
            {summary.totalReceived === 0 && (
              <span className="mt-1 block font-extrabold text-red-800">
                ملاحظة: لم تُسجَّل أي دفعة مقبوضة لهذا المشروع بعد — إن سبق أن استلمت مبلغاً فسجّله كدفعة ليصح الحساب.
              </span>
            )}
            {summary.remainingOnClient > 0 && (
              <> المتبقي على صاحب البيت <b className="num">{formatMoney(summary.remainingOnClient)} ر.س</b> — يمكنك طلب دفعة.</>
            )}
            <label className="mt-2 flex cursor-pointer items-center gap-2 rounded-lg bg-white px-2.5 py-2 text-[12px] font-extrabold text-red-700 ring-1 ring-red-200">
              <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="h-4 w-4 accent-red-600" />
              أفهم العجز وأريد تسجيل الفاتورة
            </label>
          </AlertBox>
        ) : amt > 0 ? (
          <AlertBox tone="success" title={`✅ الكاش يكفي — سيتبقى ${formatMoney(cashAfter)} ر.س بعد هذه الفاتورة`} />
        ) : null}

        <div className="grid grid-cols-2 gap-3">
          <FieldWrap label="التاريخ">
            <input type="date" className="field num" value={date} onChange={(e) => setDate(e.target.value)} />
          </FieldWrap>
          <FieldWrap label="التصنيف">
            <select className="field" value={category} onChange={(e) => setCategory(e.target.value)}>
              {EXPENSE_CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </FieldWrap>
        </div>
        <FieldWrap label="اسم المحل / المورد">
          <input className="field" placeholder="مثال: مؤسسة الأنوار للجبس" value={vendor} onChange={(e) => setVendor(e.target.value)} />
        </FieldWrap>
        <FieldWrap label="وصف المشتريات">
          <input className="field" placeholder="مثال: 20 لوح جبس + مسامير ومعجون" value={desc} onChange={(e) => setDesc(e.target.value)} />
        </FieldWrap>
        <ImagePicker value={img} onChange={setImg} label="📷 صورة الفاتورة" />
        {err && <p className="rounded-xl bg-red-50 px-3 py-2.5 text-center text-[13px] font-bold text-red-600">{err}</p>}
        <GoldButton onClick={submit} disabled={willDeficit && !ack}>
          {willDeficit ? "تسجيل الفاتورة مع العجز ⚠️" : "حفظ الفاتورة ✓"}
        </GoldButton>
      </div>
    </Sheet>
  );
}
