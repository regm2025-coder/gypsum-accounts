"use client";

import React, { useRef, useState } from "react";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { Sheet } from "./ui";
import { useInstallPrompt } from "./InstallBanner";
import { FileDownload } from "./FileDownload";
import { ShareSheet } from "./ShareSheet";
import { appUrl, copyText, openExternal, startDownload } from "@/lib/share";

export function SettingsSheet({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { exportBackup, importBackup, clearAllLocal, projects, payments, expenses } =
    useStore();
  const { canInstall, installed, install } = useInstallPrompt();
  const fileRef = useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
  }, []);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [canShare, setCanShare] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const download = () => {
    const json = exportBackup();
    const d = new Date();
    const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const filename = `نسخة-احتياطية-حسابات-الجبس-${stamp}.json`;
    try {
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      startDownload(url, filename);
      setMsg({
        ok: true,
        text: "تم تجهيز النسخة الاحتياطية — تحقق من مجلد التنزيلات. إذا لم تظهر، افتح التطبيق في نافذة مستقلة.",
      });
    } catch {
      setMsg({ ok: false, text: "تعذر التنزيل داخل المعاينة — افتح التطبيق في نافذة مستقلة" });
    }
  };

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    const txt = await f.text();
    const res = importBackup(txt);
    setMsg({ ok: res.ok, text: res.message });
  };

  const shareApp = async () => {
    const url = appUrl();
    const text = `تطبيق حسابات معلم الجبس 🧱\nإدارة المشاريع والمقبوضات والمصروفات وكشوف الحساب — يعمل بدون إنترنت.\n${url}`;
    try {
      if (typeof navigator.share === "function") {
        await navigator.share({ title: "حسابات معلم الجبس", text, url });
        return;
      }
    } catch {
      /* محجوب داخل المعاينة أو ألغى المستخدم — نكمل للبدائل */
    }
    const ok = await copyText(text);
    if (ok) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } else {
      setShareOpen(true);
    }
  };

  const sendBackupWhatsApp = () => {
    const url = typeof window !== "undefined" ? window.location.origin : "";
    const text = `تطبيق حسابات معلم الجبس 🧱\n${url}\n\nيعمل على الجوال بدون إنترنت، ونزّله من زر «إضافة إلى الشاشة الرئيسية».`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <Sheet open={open} onClose={onClose} title="⚙️ الإعدادات والمشاركة" subtitle="ثبّت التطبيق وانقل بياناتك بسهولة">
      <div className="space-y-3">
        {/* ملخص البيانات */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { l: "مشاريع", v: projects.length, c: "text-[#1E293B]" },
            { l: "دفعات", v: payments.length, c: "text-emerald-600" },
            { l: "فواتير", v: expenses.length, c: "text-rose-600" },
          ].map((x) => (
            <div key={x.l} className="rounded-xl bg-white p-3 text-center card-soft">
              <p className={`num text-[20px] font-black ${x.c}`}>{x.v}</p>
              <p className="text-[11px] font-bold text-slate-400">{x.l}</p>
            </div>
          ))}
        </div>

        {/* تثبيت */}
        <div className="rounded-2xl bg-[#1E293B] p-4 text-white">
          <p className="text-[14px] font-black">📲 تثبيت التطبيق على الجوال</p>
          <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-slate-300">
            {installed
              ? "التطبيق مثبّت بالفعل على هذا الجهاز ✅"
              : canInstall
                ? "اضغط الزر ليُضاف كتطبيق مستقل على شاشتك الرئيسية."
                : "من قائمة المتصفح اختر «إضافة إلى الشاشة الرئيسية» (أندرويد) أو «مشاركة ← إضافة إلى الشاشة الرئيسية» (آيفون)."}
          </p>
          {canInstall && !installed && (
            <button
              onClick={() => void install()}
              className="mt-2.5 w-full rounded-xl bg-[#D97706] py-3 text-[13px] font-black text-white transition active:scale-95"
            >
              تثبيت الآن ⬇
            </button>
          )}
        </div>

        {/* مشاركة التطبيق */}
        <div className="rounded-2xl bg-white p-4 card-soft">
          <p className="text-[14px] font-black text-slate-800">🔗 إرسال التطبيق لصديق</p>
          <p className="mt-0.5 text-[11px] font-bold text-slate-500">
            أرسل الرابط عبر واتساب — يفتحه على جواله ويثبّته كتطبيق.
          </p>
          <div className="mt-2.5 grid grid-cols-2 gap-2">
            <button
              onClick={() => void shareApp()}
              className="rounded-xl bg-slate-100 py-2.5 text-[12px] font-extrabold text-slate-700"
            >
              {copiedLink ? "✅ تم نسخ الرابط" : canShare ? "مشاركة الرابط ↗" : "نسخ الرابط 📋"}
            </button>
            <button
              onClick={() => setShareOpen(true)}
              className="rounded-xl bg-[#25D366] py-2.5 text-[12px] font-extrabold text-white"
            >
              واتساب ✈
            </button>
          </div>
          <button
            onClick={() => openExternal(appUrl())}
            className="mt-2 w-full rounded-xl bg-white py-2.5 text-[12px] font-extrabold text-[#92400E] ring-1 ring-amber-300"
          >
            ↗ فتح التطبيق في نافذة مستقلة
          </button>
        </div>

        {/* نسخة احتياطية */}
        <div className="rounded-2xl bg-white p-4 card-soft">
          <p className="text-[14px] font-black text-slate-800">💾 النسخ الاحتياطي</p>
          <p className="mt-0.5 text-[11px] font-bold text-slate-500">
            البيانات محفوظة على هذا الجهاز. صدّرها كملف لنقلها لجوال آخر أو لحفظها.
          </p>
          <button
            onClick={download}
            className="mt-2.5 w-full rounded-xl bg-[#D97706] py-3 text-[13px] font-black text-white transition active:scale-[0.98]"
          >
            ⬇ تنزيل نسخة احتياطية (JSON)
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            onChange={onFile}
            className="hidden"
          />
          <button
            onClick={() => fileRef.current?.click()}
            className="mt-2 w-full rounded-xl bg-slate-100 py-3 text-[13px] font-extrabold text-slate-700 transition active:scale-[0.98]"
          >
            ⬆ استيراد نسخة احتياطية
          </button>
        </div>

        {msg && (
          <div
            className={`rounded-xl px-3 py-2.5 text-center text-[12px] font-extrabold ring-1 ${
              msg.ok
                ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                : "bg-red-50 text-red-700 ring-red-200"
            }`}
          >
            {msg.text}
          </div>
        )}

        {/* حذف البيانات */}
        <div className="rounded-2xl bg-white p-4 card-soft">
          <p className="text-[13px] font-black text-red-700">🗑 حذف بيانات هذا الجهاز</p>
          <p className="mt-0.5 text-[11px] font-bold text-slate-500">
            تُحذف المشاريع والدفعات والفواتير من هذا الجهاز فقط (قد تبقى في السحابة).
          </p>
          {confirmClear ? (
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button
                onClick={() => setConfirmClear(false)}
                className="rounded-xl bg-slate-100 py-2.5 text-[12px] font-extrabold text-slate-700"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  clearAllLocal();
                  setConfirmClear(false);
                  setMsg({ ok: true, text: "تم حذف بيانات هذا الجهاز" });
                }}
                className="rounded-xl bg-red-600 py-2.5 text-[12px] font-extrabold text-white"
              >
                تأكيد الحذف
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmClear(true)}
              className="mt-2 w-full rounded-xl bg-red-50 py-2.5 text-[12px] font-extrabold text-red-700 ring-1 ring-red-200"
            >
              حذف البيانات المحلية
            </button>
          )}
        </div>

        {/* نسخة مستقلة تعمل على أي جوال */}
        <FileDownload
          url="/downloads/gypsum-offline.html"
          filename="حسابات-معلم-الجبس.html"
          className="block w-full rounded-2xl bg-gradient-to-l from-emerald-600 to-emerald-500 p-4 text-right text-white card-soft transition active:scale-[0.99]"
          title="📴 النسخة المستقلة"
          subtitle="ملف واحد يعمل بدون إنترنت — أرسله لصديقك على واتساب"
        >
          <p className="text-[14px] font-black">📴 نسخة تعمل على أي جوال فوراً</p>
          <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-emerald-50">
            ملف واحد بدون إنترنت وبدون استضافة — أرسله لصديقك على واتساب ويفتحه مباشرة.
          </p>
          <span className="mt-2.5 block rounded-xl bg-white py-2.5 text-center text-[12.5px] font-black text-emerald-700">
            ⬇ تنزيل النسخة المستقلة
          </span>
        </FileDownload>

        {/* كود المشروع */}
        <FileDownload
          url="/downloads/gypsum-app-source.zip"
          filename="gypsum-app-source.zip"
          className="block w-full rounded-2xl bg-[#1E293B] p-4 text-right text-white card-soft transition active:scale-[0.99]"
          title="📦 كود التطبيق"
          subtitle="مشروع كامل + README للتشغيل والنشر والتعديل"
        >
          <p className="text-[14px] font-black">📦 تنزيل كود التطبيق (ZIP)</p>
          <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-slate-300">
            المشروع كامل ليشتغل عليه صديقك أو لتعديله لاحقاً — فيه ملف README بخطوات
            التشغيل والنشر على Vercel و Supabase.
          </p>
          <span className="mt-2.5 block rounded-xl bg-[#D97706] py-2.5 text-center text-[12.5px] font-black">
            ⬇ تنزيل المشروع
          </span>
        </FileDownload>

        <Link
          href="/download"
          onClick={onClose}
          className="block rounded-2xl bg-sky-600 p-4 text-right text-white card-soft"
        >
          <p className="text-[14px] font-black">⬇ مركز التنزيل</p>
          <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-sky-50">
            APK للأندرويد • رابط دائم netlify/vercel • تثبيت PWA • نسخة أوفلاين
          </p>
        </Link>

        <Link
          href="/guide"
          onClick={onClose}
          className="block rounded-2xl bg-white py-3 text-center text-[13px] font-extrabold text-slate-700 card-soft"
        >
          📖 دليل التثبيت والمشاركة
        </Link>

        <p className="pb-1 text-center text-[10px] font-bold text-slate-400">
          حسابات معلم الجبس — الإصدار 1.0 • يعمل بدون إنترنت
        </p>
      </div>

      <ShareSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        title="📤 إرسال التطبيق لصديق"
        subtitle="مشاركة الرابط أو نسخه — يعمل بدون إنترنت"
        waText={`تطبيق حسابات معلم الجبس 🧱\nإدارة المشاريع والمقبوضات والمصروفات وكشوف الحساب — يعمل بدون إنترنت.\n${appUrl()}`}
        fileUrl="/downloads/gypsum-offline.html"
        fileLabel="فتح النسخة المستقلة (ملف واحد)"
      />
    </Sheet>
  );
}
