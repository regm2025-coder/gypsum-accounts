"use client";

import React, { useEffect, useState } from "react";
import { appUrl, copyText, isEmbedded, openExternal } from "@/lib/share";

/**
 * تنبيه يظهر فقط عند عرض التطبيق داخل إطار معاينة محمي،
 * لأن الإطار يمنع المشاركة والتنزيل المباشر.
 */
export function EmbedNotice() {
  const [embedded, setEmbedded] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setEmbedded(isEmbedded());
  }, []);

  if (!embedded || hidden) return null;

  return (
    <section className="anim-rise rounded-2xl bg-amber-50 p-3.5 ring-1 ring-amber-300">
      <div className="flex items-start gap-2.5">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-500 text-base text-white">
          ⚠️
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-black leading-relaxed text-amber-900">
            أنت داخل معاينة محمية — المشاركة والتنزيل قد لا يعملان هنا.
          </p>
          <p className="mt-0.5 text-[11px] font-bold leading-relaxed text-amber-800">
            لا تنسخ رابط شريط العنوان — استخدم زر «نسخ الرابط» هنا فهو الرابط الصحيح الذي
            يفتح عند صديقك. ويمكنك تنزيل النسخة المستقلة من ⚙️ الإعدادات.
          </p>
          <div className="mt-2 flex gap-2">
            <button
              onClick={() => openExternal(appUrl())}
              className="flex-1 rounded-xl bg-[#D97706] py-2.5 text-[12px] font-black text-white transition active:scale-95"
            >
              ↗ نافذة مستقلة
            </button>
            <button
              onClick={async () => {
                const ok = await copyText(appUrl());
                setCopied(ok);
                setTimeout(() => setCopied(false), 2200);
              }}
              className="rounded-xl bg-white px-3 py-2.5 text-[12px] font-extrabold text-amber-900 ring-1 ring-amber-300"
            >
              {copied ? "✓ نُسخ" : "نسخ الرابط"}
            </button>
            <button
              onClick={() => setHidden(true)}
              aria-label="إغلاق"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-[13px] font-bold text-amber-900 ring-1 ring-amber-300"
            >
              ✕
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
