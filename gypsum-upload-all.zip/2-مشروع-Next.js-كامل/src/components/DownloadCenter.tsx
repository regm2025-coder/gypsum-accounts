"use client";

import React, { useEffect, useState } from "react";
import {
  appUrl,
  copyText,
  forcedDownloadUrl,
  isUnshareableHost,
  navigateTop,
  openExternal,
} from "@/lib/share";
import { FileDownload } from "./FileDownload";
import { PwaDiagnostics } from "./PwaDiagnostics";
import { useInstallPrompt } from "./InstallBanner";

type Status = "checking" | "ok" | "fail";

export function DownloadCenter() {
  const [url, setUrl] = useState("");
  const [copied, setCopied] = useState(false);
  const [copiedCommands, setCopiedCommands] = useState(false);
  const [checks, setChecks] = useState<Record<string, Status>>({});
  const { canInstall, installed, install } = useInstallPrompt();

  useEffect(() => {
    const u = appUrl();
    setUrl(u);
    // تحقق فعلي من إتاحة الملفات والرابط
    const targets: Record<string, string> = {
      site: u,
      offline: "/downloads/gypsum-offline.html",
      staticKit: "/downloads/gypsum-static-site.zip",
      apkKit: "/downloads/gypsum-apk-kit.zip",
      sourceKit: "/downloads/gypsum-app-source.zip",
    };
    Object.entries(targets).forEach(([key, target]) => {
      fetch(target, { method: "HEAD", cache: "no-store" })
        .then((r) => setChecks((p) => ({ ...p, [key]: r.ok ? "ok" : "fail" })))
        .catch(() => setChecks((p) => ({ ...p, [key]: "fail" })));
    });
  }, []);

  const badge = (key: string) => {
    const s = checks[key];
    if (s === "ok")
      return (
        <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-black text-emerald-700">
          ✓ متاح
        </span>
      );
    if (s === "fail")
      return (
        <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-black text-red-700">
          ✕ غير متاح
        </span>
      );
    return (
      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-black text-slate-500">
        … فحص
      </span>
    );
  };

  return (
    <div className="space-y-3">
      {/* 0) أهم زر: فتح التطبيق خارج المعاينة */}
      <section className="anim-rise overflow-hidden rounded-2xl bg-[#D97706] p-4 text-white shadow-[0_10px_30px_rgba(217,119,6,0.35)]">
        <h2 className="text-[15px] font-black">🚀 شغّل التطبيق الآن (خارج المعاينة)</h2>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-amber-50">
          كل مشاكل التنزيل والتثبيت سببها إطار المعاينة. اضغط الزر ليفتح التطبيق في
          نافذة المتصفح الرئيسية — ومن هناك يعمل التثبيت والتنزيل والمشاركة بشكل طبيعي.
        </p>
        <button
          onClick={() => navigateTop(appUrl())}
          className="mt-2.5 w-full rounded-xl bg-white py-3.5 text-[14px] font-black text-[#92400E] transition active:scale-[0.98]"
        >
          ↗ فتح التطبيق في نافذة مستقلة
        </button>
        <button
          onClick={() => navigateTop("/downloads/gypsum-offline.html")}
          className="mt-2 w-full rounded-xl bg-black/20 py-3 text-[12.5px] font-black text-white transition active:scale-[0.98]"
        >
          📴 فتح النسخة الأوفلاين مباشرة (تعمل فوراً)
        </button>
      </section>

      {/* 1) رابط التطبيق + QR */}
      <section className="anim-rise overflow-hidden rounded-2xl bg-[#1E293B] p-4 text-white card-soft">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black">🔗 رابط التطبيق المباشر</h2>
          {badge("site")}
        </div>
        <div className="num mt-2 select-all break-all rounded-xl bg-white/95 px-3 py-2.5 text-[11px] font-bold text-slate-700" dir="ltr">
          {url || "…"}
        </div>
        {isUnshareableHost(url) && (
          <p className="mt-2 rounded-lg bg-red-500/20 px-2.5 py-2 text-[11px] font-extrabold text-red-200 ring-1 ring-red-400/40">
            ⚠️ هذا نطاق منصة معاينة ولا يفتح لغيرك. افتح مركز التنزيل من رابط e2b.app أو انشر
            الحزمة الجاهزة للحصول على رابط دائم.
          </p>
        )}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={`/api/qr?size=320&text=${encodeURIComponent(url)}`}
          alt="QR رابط التطبيق"
          width={180}
          height={180}
          className="mx-auto mt-3 h-[180px] w-[180px] rounded-xl bg-white p-2"
        />
        <p className="mt-1 text-center text-[10.5px] font-bold text-slate-300">
          امسح الكود لفتح التطبيق على جوالك
        </p>
        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            onClick={async () => {
              const ok = await copyText(url);
              if (ok) {
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }
            }}
            className="rounded-xl bg-[#D97706] py-2.5 text-[12px] font-black text-white"
          >
            {copied ? "✓ نُسخ" : "📋 نسخ الرابط"}
          </button>
          <button
            onClick={() => openExternal(url)}
            className="rounded-xl bg-white/10 py-2.5 text-[12px] font-black text-white"
          >
            ↗ فتح مستقل
          </button>
        </div>
      </section>

      {/* 1-ب) فحص الجاهزية */}
      <PwaDiagnostics />

      {/* 2) تثبيت PWA */}
      <section className="anim-rise rounded-2xl bg-white p-4 card-soft">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black text-slate-900">📲 تثبيت كتطبيق (PWA)</h2>
          <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-black text-emerald-700">
            الأسرع
          </span>
        </div>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-500">
          يفتح كتطبيق مستقل على شاشتك الرئيسية، ويعمل بدون إنترنت. لا يحتاج متجر تطبيقات.
        </p>
        {installed ? (
          <p className="mt-2 rounded-xl bg-emerald-50 py-2.5 text-center text-[12px] font-black text-emerald-700">
            ✓ التطبيق مثبّت على هذا الجهاز
          </p>
        ) : canInstall ? (
          <button
            onClick={() => void install()}
            className="mt-2 w-full rounded-xl bg-[#D97706] py-3 text-[13px] font-black text-white"
          >
            ⬇ تثبيت الآن
          </button>
        ) : (
          <div className="mt-2 rounded-xl bg-slate-50 p-3 text-[11px] font-bold leading-relaxed text-slate-600">
            <p>🤖 أندرويد (Chrome): القائمة ⋮ ← «تثبيت التطبيق».</p>
            <p className="mt-1">🍏 آيفون (Safari): زر المشاركة ⬆ ← «إضافة إلى الشاشة الرئيسية».</p>
          </div>
        )}
      </section>

      {/* 3) نسخة مستقلة */}
      <section className="anim-rise rounded-2xl bg-white p-4 card-soft">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black text-slate-900">📴 نسخة مستقلة (ملف واحد)</h2>
          {badge("offline")}
        </div>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-500">
          ملف HTML واحد (78KB) يعمل على أي جوال بدون إنترنت ولا استضافة — أرسله على واتساب
          ويفتحه مباشرة.
        </p>
        <a
          href={forcedDownloadUrl("/downloads/gypsum-offline.html")}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 block w-full rounded-xl bg-slate-900 py-3 text-center text-[12.5px] font-black text-white"
        >
          ⬇ رابط تنزيل مباشر (فقط عند فتحه في متصفح)
        </a>
        <FileDownload
          url="/downloads/gypsum-offline.html"
          filename="gypsum-app.html"
          className="mt-2 block w-full rounded-xl bg-emerald-600 py-3 text-center text-[13px] font-black text-white"
          title="📴 النسخة المستقلة"
          subtitle="ملف واحد يعمل بدون إنترنت"
        >
          ⬇ تنزيل الملف المستقل
        </FileDownload>
      </section>

      {/* 4) رابط دائم: حزمة نشر */}
      <section className="anim-rise rounded-2xl bg-white p-4 card-soft ring-2 ring-amber-200">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black text-slate-900">
            🌐 رابط دائم (.netlify.app / .vercel.app)
          </h2>
          {badge("staticKit")}
        </div>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-500">
          حزمة موقع جاهزة 100% — اسحبها على Netlify Drop لتحصل على رابط دائم خلال دقيقة،
          أو ارفعها على Vercel. بالداخل manifest و service worker وأيقونات.
        </p>
        <FileDownload
          url="/downloads/gypsum-static-site.zip"
          filename="gypsum-static-site.zip"
          className="mt-2 block w-full rounded-xl bg-[#1E293B] py-3 text-center text-[13px] font-black text-white"
          title="🌐 حزمة الموقع الجاهزة"
          subtitle="اسحبها على Netlify Drop أو ارفعها على Vercel"
        >
          ⬇ تنزيل حزمة النشر (51KB)
        </FileDownload>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button
            onClick={() => openExternal("https://app.netlify.com/drop")}
            className="rounded-xl bg-slate-100 py-2.5 text-[11.5px] font-extrabold text-slate-700"
          >
            Netlify Drop ↗
          </button>
          <button
            onClick={() => openExternal("https://vercel.com/new")}
            className="rounded-xl bg-slate-100 py-2.5 text-[11.5px] font-extrabold text-slate-700"
          >
            Vercel ↗
          </button>
        </div>
        <p className="mt-2 rounded-lg bg-amber-50 px-2.5 py-2 text-[10.5px] font-bold leading-relaxed text-amber-800">
          الخطوات داخل ملف README بالحزمة. بعد النشر: افتح الرابط ← ثبّت التطبيق ← شارك الرابط
          مع صديقك (لن يتغيّر).
        </p>
        <a
          href={forcedDownloadUrl("/downloads/gypsum-static-site.zip")}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 block w-full rounded-xl bg-slate-200 py-2.5 text-center text-[11.5px] font-extrabold text-slate-700"
        >
          ⬇ رابط مباشر لحزمة النشر
        </a>
      </section>

      {/* 5) APK */}
      <section className="anim-rise rounded-2xl bg-white p-4 card-soft ring-2 ring-sky-200">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black text-slate-900">📱 ملف APK للأندرويد</h2>
          {badge("apkKit")}
        </div>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-500">
          حزمة مشروع <b>Capacitor</b> جاهزة تُنتج لك APK حقيقياً وموقّعاً — بالبناء التلقائي
          على GitHub (بدون Android Studio) أو عبر PWABuilder خلال دقيقتين.
        </p>
        <FileDownload
          url="/downloads/gypsum-apk-kit.zip"
          filename="gypsum-apk-kit.zip"
          className="mt-2 block w-full rounded-xl bg-sky-600 py-3 text-center text-[13px] font-black text-white"
          title="📱 حزمة بناء APK"
          subtitle="مشروع Capacitor + GitHub Actions + README"
        >
          ⬇ تنزيل حزمة APK (65KB)
        </FileDownload>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button
            onClick={() => openExternal("https://www.pwabuilder.com")}
            className="rounded-xl bg-slate-100 py-2.5 text-[11.5px] font-extrabold text-slate-700"
          >
            PWABuilder ↗
          </button>
          <button
            onClick={() => openExternal("https://github.com/new")}
            className="rounded-xl bg-slate-100 py-2.5 text-[11.5px] font-extrabold text-slate-700"
          >
            GitHub ↗
          </button>
        </div>
        <a
          href={forcedDownloadUrl("/downloads/gypsum-apk-kit.zip")}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 block w-full rounded-xl bg-slate-200 py-2.5 text-center text-[11.5px] font-extrabold text-slate-700"
        >
          ⬇ رابط مباشر لحزمة APK
        </a>
        <div className="mt-2.5 space-y-1.5 rounded-xl bg-slate-50 p-3 text-[11px] font-bold leading-relaxed text-slate-600">
          <p className="font-black text-slate-800">طريقان للحصول على APK:</p>
          <p>
            <b>الأسرع:</b> انشر حزمة الموقع (بالأعلى) ← افتح PWABuilder ← ألصق الرابط ←
            Android ← نزّل APK/AAB.
          </p>
          <p>
            <b>الأدق:</b> ارفع حزمة APK على GitHub ← Actions ← «بناء APK» ← نزّل الملف من
            Artifacts (<span className="num">app-debug.apk</span>).
          </p>
          <p className="text-slate-500">
            ملاحظة: بيئة المعاينة هذه لا تضم Java/Android SDK، لذلك لا يمكن إخراج APK جاهز هنا
            مباشرة؛ الحزمة تقوم بذلك على أي جهاز أو عبر السحابة مجاناً.
          </p>
        </div>
      </section>

      {/* 4-ب) GitHub Pages — رابطك جاهز */}
      <section className="anim-rise rounded-2xl bg-white p-4 card-soft ring-2 ring-emerald-300">
        <div className="flex items-start justify-between gap-2">
          <h2 className="text-[14px] font-black text-slate-900">🐙 GitHub Pages — رابطك العام</h2>
          <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-black text-emerald-700">
            مفعّل
          </span>
        </div>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-500">
          مستودعك <span dir="ltr" className="num">regm2025-coder/gypsum-accounts</span> موجود و
          GitHub Pages مفعّل عليه. ارفع هذه الحزمة ليصبح رابطك العام:
        </p>
        <div
          className="num mt-2 select-all break-all rounded-xl bg-emerald-50 px-3 py-2 text-[11px] font-black text-emerald-800 ring-1 ring-emerald-200"
          dir="ltr"
        >
          https://regm2025-coder.github.io/gypsum-accounts/
        </div>
        <FileDownload
          url="/downloads/gypsum-github-pages.zip"
          filename="gypsum-github-pages.zip"
          className="mt-2 block w-full rounded-xl bg-emerald-600 py-3 text-center text-[12.5px] font-black text-white"
          title="🐙 حزمة GitHub Pages"
          subtitle="index.html + manifest + sw + أيقونات + .nojekyll"
        >
          ⬇ تنزيل حزمة النشر على GitHub Pages
        </FileDownload>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button
            onClick={() => openExternal("https://github.com/regm2025-coder/gypsum-accounts/upload/main")}
            className="rounded-xl bg-[#1E293B] py-2.5 text-[11.5px] font-black text-white"
          >
            رفع الملفات ↗
          </button>
          <button
            onClick={() => openExternal("https://regm2025-coder.github.io/gypsum-accounts/")}
            className="rounded-xl bg-slate-100 py-2.5 text-[11.5px] font-black text-slate-700"
          >
            فتح الرابط ↗
          </button>
        </div>
        <p className="mt-2 rounded-lg bg-slate-50 px-2.5 py-2 text-[10.5px] font-bold leading-relaxed text-slate-500">
          الطريقة الأسرع: افتح رابط الرفع ← اسحب محتويات الحزمة ← Commit ← انتظر دقيقة.
          للأوامر الصحيحة راجع <span className="num">GITHUB-PAGES.md</span> في حزمة المستودع.
        </p>
      </section>

      {/* 5-أ) GitHub: هل يوجد مستودع؟ */}
      <section className="anim-rise rounded-2xl bg-gradient-to-br from-slate-900 to-[#1E293B] p-4 text-white card-soft ring-2 ring-white/10">
        <div className="flex items-start justify-between gap-2">
          <h2 className="text-[14px] font-black">🐙 مستودع GitHub — خطوتان فقط</h2>
          <span className="rounded-full bg-emerald-400/20 px-2 py-0.5 text-[10px] font-black text-emerald-300">
            مستعد
          </span>
        </div>
        <p className="mt-1 text-[11px] font-bold leading-relaxed text-slate-300">
          التطبيق ليس على حسابي في GitHub (لا أملك صلاحية النشر). حمّل الحزمة الجاهزة وارفعها
          إلى مستودعك، ثم Deploy على Vercel — الرابط الدائم يصبح لك.
        </p>

        <div className="mt-2.5 space-y-1.5 rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
          <p className="text-[11.5px] font-black text-amber-300">الطريقة أ) بدون أوامر (الأسهل)</p>
          <ol className="space-y-1 text-[11px] font-bold leading-relaxed text-slate-300">
            <li><span className="num">1.</span> GitHub ← New repository ← اسمه <span dir="ltr" className="num">gypsum-accounts</span></li>
            <li><span className="num">2.</span> «uploading an existing file» ← اسحب محتويات الحزمة ← Commit</li>
            <li><span className="num">3.</span> vercel.com/new ← Import ← Deploy ✅</li>
          </ol>
        </div>

        <div className="mt-2 space-y-1.5 rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
          <p className="text-[11.5px] font-black text-amber-300">الطريقة ب) أمر واحد (إن كان Git مثبتاً)</p>
          <div
            className="num max-h-24 select-all overflow-auto break-all rounded-lg bg-black/40 px-2.5 py-2 text-[10px] font-bold text-emerald-300"
            dir="ltr"
          >
            bash push-to-github.sh https://github.com/USERNAME/gypsum-accounts.git
          </div>
          <button
            onClick={async () => {
              await copyText(
                "bash push-to-github.sh https://github.com/USERNAME/gypsum-accounts.git"
              );
              setCopiedCommands(true);
              setTimeout(() => setCopiedCommands(false), 2000);
            }}
            className="w-full rounded-lg bg-white/10 py-2 text-[11px] font-extrabold text-white"
          >
            {copiedCommands ? "✓ تم نسخ الأمر" : "📋 نسخ الأمر"}
          </button>
          <p className="text-[10px] font-bold leading-relaxed text-slate-400">
            السكريبت داخل الحزمة (push-to-github.sh) يعمل git init + commit + push تلقائياً.
            الخطوات الكاملة في DEPLOY-AR.md.
          </p>
        </div>

        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            onClick={() => openExternal("https://github.com/new")}
            className="rounded-xl bg-white py-2.5 text-[12px] font-black text-[#0F172A]"
          >
            إنشاء مستودع ↗
          </button>
          <button
            onClick={() => openExternal("https://vercel.com/new")}
            className="rounded-xl bg-[#D97706] py-2.5 text-[12px] font-black text-white"
          >
            Vercel Deploy ↗
          </button>
        </div>

        <FileDownload
          url="/downloads/gypsum-github-repo.zip"
          filename="gypsum-github-repo.zip"
          className="mt-2 block w-full rounded-xl bg-emerald-600 py-3 text-center text-[12.5px] font-black text-white"
          title="🐙 حزمة المستودع الجاهزة"
          subtitle="كل ملفات المشروع + push-to-github.sh + DEPLOY-AR.md"
        >
          ⬇ تنزيل حزمة GitHub (408KB)
        </FileDownload>
      </section>

      {/* 5-ب) النشر السريع من GitHub */}
      <section className="anim-rise rounded-2xl bg-[#1E293B] p-4 text-white card-soft ring-2 ring-amber-400/40">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black">🚀 عندك مستودع GitHub؟ انشر الآن (5 دقائق)</h2>
        </div>
        <ol className="mt-2 space-y-1.5 text-[11.5px] font-bold leading-relaxed text-slate-300">
          <li><span className="num font-black text-amber-300">1)</span> ارفع الكود إلى مستودعك ( أوامر git في الحزمة ).</li>
          <li><span className="num font-black text-amber-300">2)</span> افتح Vercel ← Import Git Repository ← اختر المستودع.</li>
          <li><span className="num font-black text-amber-300">3)</span> اضغط Deploy — بدون أي إعدادات. تأخذ رابطاً دائماً <span dir="ltr" className="num">*.vercel.app</span>.</li>
        </ol>
        <p className="mt-2 rounded-xl bg-emerald-500/15 px-2.5 py-2 text-[11px] font-extrabold leading-relaxed text-emerald-200 ring-1 ring-emerald-400/30">
          ✅ لا تحتاج قاعدة بيانات — التطبيق يعمل أوفلاين-أولاً ويحفظ البيانات على الجوال.
        </p>
        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            onClick={() => openExternal("https://vercel.com/new")}
            className="rounded-xl bg-white py-2.5 text-[12px] font-black text-[#0F172A]"
          >
            Vercel Import ↗
          </button>
          <button
            onClick={() => openExternal("https://github.com/new")}
            className="rounded-xl bg-white/10 py-2.5 text-[12px] font-black text-white"
          >
            مستودع GitHub ↗
          </button>
        </div>
        <FileDownload
          url="/downloads/gypsum-github-repo.zip"
          filename="gypsum-github-repo.zip"
          className="mt-2 block w-full rounded-xl bg-[#D97706] py-3 text-center text-[12.5px] font-black text-white"
          title="📤 حزمة جاهزة للرفع على GitHub"
          subtitle="تحتوي كل ملفات المشروع + GITHUB-DEPLOY.md + vercel.json"
        >
          ⬇ تنزيل حزمة المستودع الجاهزة
        </FileDownload>
      </section>

      {/* 6) كود المصدر */}
      <section className="anim-rise rounded-2xl bg-white p-4 card-soft">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-black text-slate-900">📦 كود المشروع الكامل</h2>
          {badge("sourceKit")}
        </div>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-500">
          Next.js + PostgreSQL + Drizzle + PWA، مع README للتشغيل والنشر والتعديل لاحقاً.
        </p>
        <FileDownload
          url="/downloads/gypsum-app-source.zip"
          filename="gypsum-app-source.zip"
          className="mt-2 block w-full rounded-xl bg-slate-100 py-3 text-center text-[13px] font-black text-slate-700"
          title="📦 كود المشروع"
          subtitle="مشروع كامل + README"
        >
          ⬇ تنزيل ZIP (164KB)
        </FileDownload>
      </section>
    </div>
  );
}
