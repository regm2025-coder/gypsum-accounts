"use client";

import React, { useEffect, useState } from "react";
import { isEmbedded, whatsappLinkSafe } from "@/lib/share";
import { ShareSheet } from "./ShareSheet";

/**
 * زر واتساب:
 * - متصفح عادي: رابط مباشر يفتح محادثة صاحب البيت.
 * - داخل إطار المعاينة (يحجب النوافذ/المشاركة): يفتح ورقة بدائل فيها
 *   رابط واتساب + نسخ النص/الرقم، حتى تعمل المشاركة في كل الأحوال.
 */
export function WhatsAppShare({
  phone,
  text,
  className = "",
  label = "✈ واتساب",
  defaultNumber = "",
}: {
  phone?: string;
  text: string;
  className?: string;
  label?: string;
  defaultNumber?: string;
}) {
  const [open, setOpen] = useState(false);
  const [embedded, setEmbedded] = useState(false);

  useEffect(() => {
    setEmbedded(isEmbedded());
  }, []);

  const target = phone || defaultNumber || "";
  const hasPhone = (phone ?? "").replace(/\D/g, "").length >= 8;
  const href = whatsappLinkSafe(target, text);

  return (
    <>
      {embedded || !hasPhone ? (
        <button type="button" onClick={() => setOpen(true)} className={className}>
          {label}
        </button>
      ) : (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className={className}
        >
          {label}
        </a>
      )}

      <ShareSheet
        open={open}
        onClose={() => setOpen(false)}
        title="✈ مشاركة عبر واتساب"
        subtitle={
          hasPhone
            ? `إلى صاحب البيت: ${target}`
            : "لا يوجد رقم مسجّل — اختر جهة اتصال أو انسخ النص"
        }
        waPhone={target}
        waText={text}
      />
    </>
  );
}
