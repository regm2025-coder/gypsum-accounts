"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import {
  buildRequestPaymentText,
  calcSummary,
  PAYMENT_METHODS,
} from "@/lib/types";
import { buildStatementText, formatDate, formatMoney } from "@/lib/format";
import { AddExpenseSheet, AddPaymentSheet, EditProjectSheet } from "./forms";
import { WhatsAppShare } from "./WhatsAppShare";
import {
  ConfirmDelete,
  EmptyState,
  ImageViewer,
  StatusBadge,
  TopBar,
} from "./ui";

export function ProjectDetail({ id }: { id: string }) {
  const router = useRouter();
  const {
    ready,
    projectById,
    paymentsOf,
    expensesOf,
    deletePayment,
    deleteExpense,
    deleteProject,
    online,
  } = useStore();

  const [tab, setTab] = useState<"payments" | "expenses">("payments");
  const [showPay, setShowPay] = useState(false);
  const [payPrefill, setPayPrefill] = useState<number | undefined>(undefined);
  const [showExp, setShowExp] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [viewImg, setViewImg] = useState<string | null>(null);
  const [delPay, setDelPay] = useState<string | null>(null);
  const [delExp, setDelExp] = useState<string | null>(null);
  const [delProj, setDelProj] = useState(false);

  const project = projectById(id);
  const pays = useMemo(() => paymentsOf(id), [paymentsOf, id]);
  const exps = useMemo(() => expensesOf(id), [expensesOf, id]);
  const summary = useMemo(
    () => calcSummary(project?.agreementTotal ?? 0, pays, exps),
    [project?.agreementTotal, pays, exps]
  );

  if (ready && !project) {
    return (
      <div className="min-h-dvh bg-[#F8FAFC]">
        <TopBar title="المشروع" onBack={() => router.back()} />
        <main className="mx-auto max-w-md px-4 pt-8">
          <EmptyState icon="🔍" title="المشروع غير موجود" hint="ربما تم حذفه من جهاز آخر" />
          <Link href="/" className="mt-4 block rounded-2xl bg-[#1E293B] py-3.5 text-center text-sm font-extrabold text-white">
            العودة للرئيسية
          </Link>
        </main>
      </div>
    );
  }

  const waText = project
    ? buildStatementText({
        title: project.title,
        clientName: project.clientName,
        agreementTotal: summary.agreementTotal,
        totalReceived: summary.totalReceived,
        totalExpenses: summary.totalExpenses,
        cashInHand: summary.cashInHand,
        remainingOnClient: summary.remainingOnClient,
        paymentsCount: pays.length,
        expensesCount: exps.length,
      })
    : "";
  const requestText = project
    ? buildRequestPaymentText({
        title: project.title,
        clientName: project.clientName,
        totalReceived: summary.totalReceived,
        remainingOnClient: summary.remainingOnClient,
        deficit: summary.deficit,
      })
    : "";

  const methodLabel = (m: string) =>
    PAYMENT_METHODS.find((x) => x.value === m)?.label ?? m;

  return (
    <div className="min-h-dvh bg-[#F8FAFC]">
      <TopBar
        title={project?.title ?? "…"}
        subtitle={project ? `👤 ${project.clientName}` : undefined}
        onBack={() => router.back()}
        right={
          <div className="relative">
            <button
              onClick={() => setShowMenu((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 text-lg transition active:scale-95"
            >
              ⋮
            </button>
            {showMenu && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
                <div className="anim-pop absolute left-0 top-12 z-50 w-48 overflow-hidden rounded-2xl bg-white text-slate-800 card-soft">
                  <button
                    onClick={() => { setShowMenu(false); setShowEdit(true); }}
                    className="block w-full px-4 py-3 text-right text-[14px] font-bold hover:bg-slate-50"
                  >
                    ✏️ تعديل المشروع
                  </button>
                  <Link
                    href={`/projects/${id}/statement`}
                    className="block px-4 py-3 text-[14px] font-bold hover:bg-slate-50"
                  >
                    🖨 كشف الحساب
                  </Link>
                  <button
                    onClick={() => { setShowMenu(false); setDelProj(true); }}
                    className="block w-full px-4 py-3 text-right text-[14px] font-bold text-red-600 hover:bg-red-50"
                  >
                    🗑 حذف المشروع
                  </button>
                </div>
              </>
            )}
          </div>
        }
      />

      <main className="mx-auto max-w-md space-y-4 px-4 pb-40 pt-4">
        {/* ─── بطاقة ملخص الحساب (داكنة) ─── */}
        <section className="anim-rise overflow-hidden rounded-2xl bg-[#1E293B] text-white card-soft">
          <div className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[12px] font-bold text-slate-300">💰 قيمة الاتفاقية</p>
                <p className="num mt-1 text-[30px] font-black leading-none">
                  {formatMoney(summary.agreementTotal)}
                  <span className="mr-1 text-[13px] font-bold text-slate-300">ر.س</span>
                </p>
              </div>
              <div className="text-left">
                {project && <StatusBadge status={project.status} />}
                <p className="num mt-2 text-[12px] font-black text-amber-300">
                  تحصيل {summary.progress}%
                </p>
              </div>
            </div>
            <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-l from-amber-400 to-[#D97706]"
                style={{ width: `${summary.progress}%` }}
              />
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2.5">
              <div className="rounded-xl bg-white/[0.07] p-3.5 ring-1 ring-emerald-400/20">
                <p className="text-[12px] font-bold text-emerald-300">✅ المقبوضات</p>
                <p className="num mt-1 text-[22px] font-black leading-none text-emerald-300">
                  {formatMoney(summary.totalReceived)}
                </p>
                <p className="num mt-1 text-[11px] font-bold text-emerald-200/70">
                  {pays.length} دفعات
                </p>
              </div>
              <div className="rounded-xl bg-white/[0.07] p-3.5 ring-1 ring-rose-400/20">
                <p className="text-[12px] font-bold text-rose-300">🧾 المصروفات</p>
                <p className="num mt-1 text-[22px] font-black leading-none text-rose-300">
                  {formatMoney(summary.totalExpenses)}
                </p>
                <p className="num mt-1 text-[11px] font-bold text-rose-200/70">
                  {exps.length} فواتير
                </p>
              </div>
              <div
                className={`rounded-xl p-3.5 ring-1 ${
                  summary.isDeficit
                    ? "bg-red-500/15 ring-red-400/50"
                    : "bg-white/[0.07] ring-sky-400/20"
                }`}
              >
                <p className={`text-[12px] font-bold ${summary.isDeficit ? "text-red-300" : "text-sky-300"}`}>
                  {summary.isDeficit ? "🚨 عجز بالكاش" : "💵 الكاش باليد"}
                </p>
                <p className={`num mt-1 text-[22px] font-black leading-none ${summary.isDeficit ? "text-red-400" : "text-sky-300"}`}>
                  {formatMoney(Math.abs(summary.cashInHand))}
                </p>
                <p className={`mt-1 text-[11px] font-bold ${summary.isDeficit ? "text-red-200/80" : "text-sky-200/70"}`}>
                  {summary.isDeficit ? "تدفعها من جيبك" : "المقبوض − المصروف"}
                </p>
              </div>
              <div className="rounded-xl bg-[#D97706]/25 p-3.5 ring-1 ring-[#D97706]/50">
                <p className="text-[12px] font-bold text-amber-300">📌 متبقي على الزبون</p>
                <p className="num mt-1 text-[22px] font-black leading-none text-amber-300">
                  {formatMoney(summary.remainingOnClient)}
                </p>
                <p className="mt-1 text-[11px] font-bold text-amber-200/70">
                  الاتفاقية − المقبوض
                </p>
              </div>
            </div>
          </div>

          {/* أزرار التواصل والتصدير */}
          <div className="grid grid-cols-3 gap-2 bg-white/[0.05] p-3">
            {project?.phone ? (
              <a
                href={`tel:${project.phone}`}
                className="rounded-xl bg-white/10 py-2.5 text-center text-[12px] font-extrabold transition active:scale-95"
              >
                📞 اتصال
              </a>
            ) : (
              <span className="rounded-xl bg-white/5 py-2.5 text-center text-[12px] font-extrabold text-slate-400">
                📞 لا يوجد رقم
              </span>
            )}
            <Link
              href={`/projects/${id}/statement`}
              className="rounded-xl bg-white/10 py-2.5 text-center text-[12px] font-extrabold transition active:scale-95"
            >
              🖨 كشف حساب
            </Link>
            <WhatsAppShare
              phone={project?.phone}
              defaultNumber={project?.phone}
              text={waText}
              label="✈ واتساب"
              className="rounded-xl bg-[#25D366] py-2.5 text-center text-[12px] font-extrabold text-white transition active:scale-95"
            />
          </div>
        </section>

        {/* ─── تنبيه: لا توجد دفعات مسجلة ─── */}
        {pays.length === 0 && summary.totalExpenses > 0 && (
          <section className="anim-rise rounded-2xl bg-amber-50 p-4 ring-2 ring-amber-300 card-soft">
            <p className="text-[14px] font-black text-amber-900">⚠️ لم تُسجَّل أي دفعة مقبوضة بعد</p>
            <p className="mt-1 text-[12px] font-bold leading-relaxed text-amber-800">
              قيمة الاتفاقية ({formatMoney(summary.agreementTotal)} ر.س) ليست مبلغاً مقبوضاً.
              إذا سبق أن استلمت من صاحب البيت {formatMoney(Math.min(summary.agreementTotal, summary.totalExpenses))} ر.س
              فسجّلها الآن لتظهر الأرصدة والعجز بشكل صحيح.
            </p>
            <button
              onClick={() => {
                setPayPrefill(summary.remainingOnClient);
                setShowPay(true);
              }}
              className="mt-3 w-full rounded-xl bg-[#D97706] py-3 text-[13px] font-black text-white shadow-[0_6px_18px_rgba(217,119,6,0.35)] transition active:scale-[0.98]"
            >
              💵 تسجيل الدفعة المقدمة {summary.remainingOnClient > 0 ? formatMoney(summary.remainingOnClient) : ""} ر.س
            </button>
          </section>
        )}

        {/* ─── تنبيه العجز / الكاش ─── */}
        {summary.isDeficit ? (
          <section className="anim-rise overflow-hidden rounded-2xl bg-red-50 ring-2 ring-red-200 card-soft">
            <div className="flex items-start gap-3 p-4">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-red-600 text-xl text-white shadow-[0_6px_16px_rgba(220,38,38,0.35)]">
                🚨
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-black text-red-800">تنبيه عجز في الكاش</p>
                <p className="num mt-0.5 text-[24px] font-black leading-none text-red-700">
                  {formatMoney(summary.deficit)} <span className="text-[12px] font-bold">ر.س</span>
                </p>
                <p className="num mt-2 rounded-lg bg-white/70 px-2.5 py-1.5 text-[11px] font-extrabold text-red-800 ring-1 ring-red-200">
                  المصروفات {formatMoney(summary.totalExpenses)} − المقبوضات {formatMoney(summary.totalReceived)} = العجز {formatMoney(summary.deficit)}
                </p>
                <p className="mt-1.5 text-[12px] font-bold leading-relaxed text-red-700/90">
                  مصروفاتك تجاوزت المقبوضات — هذا المبلغ مدفوع من جيبك.
                  {summary.remainingOnClient > 0
                    ? ` المتبقي على صاحب البيت ${formatMoney(summary.remainingOnClient)} ر.س، اطلب دفعة لتغطية العجز.`
                    : " لا يوجد مبلغ متبقٍ على صاحب البيت حسب الاتفاقية."}
                </p>
                <div className="mt-3 flex gap-2">
                  <WhatsAppShare
                    phone={project?.phone}
                    defaultNumber={project?.phone}
                    text={requestText}
                    label="📩 اطلب دفعة"
                    className="flex-1 rounded-xl bg-[#25D366] py-2.5 text-[12px] font-black text-white transition active:scale-95"
                  />
                  <Link
                    href={`/projects/${id}/statement`}
                    className="flex-1 rounded-xl bg-white py-2.5 text-center text-[12px] font-black text-red-700 ring-1 ring-red-200"
                  >
                    🖨 كشف الحساب
                  </Link>
                </div>
              </div>
            </div>
          </section>
        ) : (
          summary.totalReceived > 0 && (
            <section className="anim-rise flex items-center gap-2.5 rounded-2xl bg-emerald-50 px-4 py-3 ring-1 ring-emerald-200">
              <span className="text-lg">✅</span>
              <p className="text-[12px] font-extrabold text-emerald-800">
                {summary.cashInHand > 0
                  ? `💰 كاش زائد باليد ${formatMoney(summary.cashInHand)} ر.س — المصروفات مغطاة بالكامل.`
                  : "✅ لا يوجد عجز — المقبوضات تغطي المصروفات بالضبط."}
              </p>
            </section>
          )
        )}

        {/* ─── التبويبات ─── */}
        <section className="anim-rise grid grid-cols-2 gap-2 rounded-2xl bg-white p-2 card-soft" style={{ animationDelay: "0.08s" }}>
          <button
            onClick={() => setTab("payments")}
            className={`rounded-xl py-3 text-[14px] font-extrabold transition ${
              tab === "payments" ? "bg-[#1E293B] text-white" : "text-slate-500"
            }`}
          >
            💵 الدفعات ({pays.length})
          </button>
          <button
            onClick={() => setTab("expenses")}
            className={`rounded-xl py-3 text-[14px] font-extrabold transition ${
              tab === "expenses" ? "bg-[#1E293B] text-white" : "text-slate-500"
            }`}
          >
            🧾 المشتريات ({exps.length})
          </button>
        </section>

        {/* ─── القوائم ─── */}
        {tab === "payments" ? (
          <section className="space-y-2.5">
            {pays.length === 0 ? (
              <EmptyState icon="💵" title="لا توجد دفعات بعد" hint="سجّل أول دفعة مستلمة من صاحب البيت" />
            ) : (
              pays.map((p) => (
                <div key={p.id} className="anim-rise flex items-center gap-3 rounded-2xl bg-white p-3.5 card-soft">
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-emerald-50 text-xl">
                    💵
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <p className="num text-[17px] font-black text-slate-900">
                        {formatMoney(p.amount)} <span className="text-[11px] font-bold text-slate-400">ر.س</span>
                      </p>
                      {!p._synced && <span className="h-2 w-2 rounded-full bg-amber-500" title="بانتظار المزامنة" />}
                    </div>
                    <p className="mt-0.5 truncate text-[12px] font-bold text-slate-500">
                      📅 {formatDate(p.paidAt)} • {methodLabel(p.method)}
                      {p.note ? ` • ${p.note}` : ""}
                    </p>
                  </div>
                  {p.receiptImage && (
                    <button
                      onClick={() => setViewImg(p.receiptImage)}
                      className="h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-slate-200"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={p.receiptImage} alt="السند" className="h-full w-full object-cover" />
                    </button>
                  )}
                  <button
                    onClick={() => setDelPay(p.id)}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-red-50 text-[15px] transition active:scale-90"
                  >
                    🗑
                  </button>
                </div>
              ))
            )}
          </section>
        ) : (
          <section className="space-y-2.5">
            {exps.length === 0 ? (
              <EmptyState icon="🧾" title="لا توجد فواتير بعد" hint="سجّل مشتريات المواد والأجور مع صورة الفاتورة" />
            ) : (
              exps.map((e) => (
                <div key={e.id} className="anim-rise flex items-center gap-3 rounded-2xl bg-white p-3.5 card-soft">
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-rose-50 text-xl">
                    🧾
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <p className="num text-[17px] font-black text-slate-900">
                        {formatMoney(e.amount)} <span className="text-[11px] font-bold text-slate-400">ر.س</span>
                      </p>
                      {!e._synced && <span className="h-2 w-2 rounded-full bg-amber-500" title="بانتظار المزامنة" />}
                    </div>
                    <p className="mt-0.5 truncate text-[12px] font-bold text-slate-500">
                      {e.category}
                      {e.vendor ? ` • 🏪 ${e.vendor}` : ""}
                      {e.description ? ` • ${e.description}` : ""}
                    </p>
                    <p className="num text-[11px] font-bold text-slate-400">📅 {formatDate(e.spentAt)}</p>
                  </div>
                  {e.invoiceImage && (
                    <button
                      onClick={() => setViewImg(e.invoiceImage)}
                      className="h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-slate-200"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={e.invoiceImage} alt="الفاتورة" className="h-full w-full object-cover" />
                    </button>
                  )}
                  <button
                    onClick={() => setDelExp(e.id)}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-red-50 text-[15px] transition active:scale-90"
                  >
                    🗑
                  </button>
                </div>
              ))
            )}
          </section>
        )}

        {!online && (
          <p className="rounded-2xl bg-amber-50 px-4 py-3 text-center text-[12px] font-bold text-amber-700 ring-1 ring-amber-200">
            ⚡ أنت أوفلاين — كل ما تدخله محفوظ على الهاتف وسيُزامَن تلقائياً
          </p>
        )}
      </main>

      {/* ─── شريط الإجراءات السفلي ─── */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto grid max-w-md grid-cols-2 gap-2.5 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
          <button
            onClick={() => { setPayPrefill(undefined); setShowPay(true); }}
            className="rounded-2xl bg-[#D97706] py-3.5 text-[14px] font-black text-white shadow-[0_8px_24px_rgba(217,119,6,0.35)] transition active:scale-[0.98]"
          >
            + دفعة مقبوضة 💵
          </button>
          <button
            onClick={() => setShowExp(true)}
            className="rounded-2xl bg-[#1E293B] py-3.5 text-[14px] font-black text-white transition active:scale-[0.98]"
          >
            + فاتورة مشتريات 🧾
          </button>
        </div>
      </div>

      <AddPaymentSheet
        open={showPay}
        onClose={() => { setShowPay(false); setPayPrefill(undefined); }}
        projectId={id}
        initialAmount={payPrefill}
        initialNote={payPrefill ? "دفعة مقدمة / دفعة من الحساب" : undefined}
      />
      <AddExpenseSheet open={showExp} onClose={() => setShowExp(false)} projectId={id} />
      <EditProjectSheet project={showEdit ? project ?? null : null} onClose={() => setShowEdit(false)} />
      <ImageViewer src={viewImg} onClose={() => setViewImg(null)} />

      <ConfirmDelete
        open={!!delPay}
        title="حذف الدفعة؟"
        message="سيتم حذف هذه الدفعة نهائياً من الحساب."
        onCancel={() => setDelPay(null)}
        onConfirm={() => { if (delPay) deletePayment(delPay); setDelPay(null); }}
      />
      <ConfirmDelete
        open={!!delExp}
        title="حذف الفاتورة؟"
        message="سيتم حذف هذه الفاتورة نهائياً من المصروفات."
        onCancel={() => setDelExp(null)}
        onConfirm={() => { if (delExp) deleteExpense(delExp); setDelExp(null); }}
      />
      <ConfirmDelete
        open={delProj}
        title="حذف المشروع؟"
        message="سيتم حذف المشروع وكل دفعاته وفواتيره نهائياً."
        onCancel={() => setDelProj(false)}
        onConfirm={() => { deleteProject(id); router.replace("/"); }}
      />
    </div>
  );
}
