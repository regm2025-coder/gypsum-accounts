"use client";

import React, { useRef, useState } from "react";
import { compressImage } from "@/lib/image";

export function ImagePicker({
  value,
  onChange,
  label = "صورة الفاتورة",
}: {
  value: string | null;
  onChange: (v: string | null) => void;
  label?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const pick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    setBusy(true);
    try {
      const dataUrl = await compressImage(f);
      onChange(dataUrl);
    } catch {
      alert("تعذر قراءة الصورة، حاول مجدداً");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <span className="mb-1.5 block text-[13px] font-extrabold text-slate-700">
        {label} <span className="font-medium text-slate-400">(اختياري)</span>
      </span>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={pick}
        className="hidden"
      />
      {value ? (
        <div className="relative overflow-hidden rounded-2xl border-2 border-slate-200">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={value} alt="الفاتورة" className="h-40 w-full object-cover" />
          <div className="absolute inset-x-0 bottom-0 flex gap-2 bg-gradient-to-t from-slate-950/70 to-transparent p-3 pt-8">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="flex-1 rounded-xl bg-white/95 py-2 text-[13px] font-extrabold text-slate-800"
            >
              📷 تغيير
            </button>
            <button
              type="button"
              onClick={() => onChange(null)}
              className="flex-1 rounded-xl bg-red-600/95 py-2 text-[13px] font-extrabold text-white"
            >
              ✕ إزالة
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-slate-300 bg-white px-4 py-5 text-[14px] font-extrabold text-slate-500 transition active:scale-[0.98] disabled:opacity-60"
        >
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#FEF3C7] text-xl">
            📷
          </span>
          {busy ? "جارٍ معالجة الصورة…" : "التقط صورة الفاتورة"}
        </button>
      )}
    </div>
  );
}
