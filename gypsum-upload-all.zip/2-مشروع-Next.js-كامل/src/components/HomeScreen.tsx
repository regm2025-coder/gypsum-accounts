"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { calcSummary } from "@/lib/types";
import { formatMoney } from "@/lib/format";
import { AddProjectSheet } from "./forms";
import { EmptyState, StatusBadge, TopBar, useCountUp } from "./ui";
import { InstallBanner } from "./InstallBanner";
import { PublicLinkCard } from "./PublicLinkCard";
import { SettingsSheet } from "./SettingsSheet";

export function HomeScreen() {
  const { ready, projects, payments, expenses, online, lastSyncAt } = useStore();
  const [showAdd, setShowAdd] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "completed">("all");

  const totals = useMemo(() => {
    const agreement = projects.reduce((s, p) => s + (Number(p.agreementTotal) || 0), 0);
    const received = payments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
    const spent = expenses.reduce((s, e) => s + (Number(e.amount) || 0), 0);
    return { agreement, received, spent, cash: received - spent };
  }, [projects, payments, expenses]);

  const animAgreement = useCountUp(totals.agreement);
  const animCash = useCountUp(Math.max(0, totals.cash));

  const filtered = useMemo(() => {
    return projects.filter((p) => {
      if (filter !== "all" && p.status !== filter) return false;
      if (!q.trim()) return true;
      const needle = q.trim();
      return (
        p.title.includes(needle) ||
        p.clientName.includes(needle) ||
        p.phone.includes(needle)
      );
    });
  }, [projects, q, filter]);

  return (
    <div className="min-h-dvh bg-[#F8FAFC]">
      <TopBar
        title="🧱 حسابات معلم الجبس"
        subtitle={
          ready
            ? `${projects.length} مشاريع • يعمل ${online ? "متصلاً" : "بدون إنترنت"}`
            : "جارٍ التحميل…"
        }
        right={
          <button
            onClick={() => setShowSettings(true)}
            aria-label="الإعدادات"
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/10 text-base transition active:scale-95"
          >
            ⚙️
          </button>
        }
      />

      <main className="mx-auto max-w-md space-y-4 px-4 pb-28 pt-4">
        {/* ─── بطاقة النظرة العامة ─── */}
        <section className="anim-rise overflow-hidden rounded-2xl bg-[#1E293B] text-white card-soft">
          <div className="p-5 pb-4">
            <p className="text-[12px] font-bold text-slate-300">إجمالي قيم الاتفاقيات</p>
            <p className="num mt-1 text-[34px] font-black leading-none">
              {formatMoney(animAgreement)}
              <span className="mr-1.5 text-[14px] font-bold text-slate-300">ر.س</span>
            </p>
            <div className="mt-4 grid grid-cols-3 gap-2.5">
              <div className="rounded-xl bg-white/[0.07] p-3">
                <p className="text-[11px] font-bold text-emerald-300">✅ مقبوض</p>
                <p className="num mt-0.5 truncate text-[16px] font-black text-emerald-300">
                  {formatMoney(totals.received)}
                </p>
              </div>
              <div className="rounded-xl bg-white/[0.07] p-3">
                <p className="text-[11px] font-bold text-rose-300">🧾 مصروف</p>
                <p className="num mt-0.5 truncate text-[16px] font-black text-rose-300">
                  {formatMoney(totals.spent)}
                </p>
              </div>
              <div className={`rounded-xl p-3 ring-1 ${totals.cash < 0 ? "bg-red-500/20 ring-red-400/50" : "bg-[#D97706]/20 ring-[#D97706]/40"}`}>
                <p className={`text-[11px] font-bold ${totals.cash < 0 ? "text-red-300" : "text-amber-300"}`}>
                  {totals.cash < 0 ? "🚨 عجز" : "💵 كاش باليد"}
                </p>
                <p className={`num mt-0.5 truncate text-[16px] font-black ${totals.cash < 0 ? "text-red-400" : "text-amber-300"}`}>
                  {formatMoney(Math.abs(totals.cash))}
                </p>
              </div>
            </div>
          </div>
          {totals.cash < 0 && (
            <div className="mx-4 mb-4 flex items-start gap-2 rounded-xl bg-red-500/15 px-3 py-2.5 ring-1 ring-red-400/40">
              <span className="text-base">🚨</span>
              <p className="text-[11px] font-extrabold leading-relaxed text-red-200">
                إجمالي المصروفات أعلى من المقبوضات بـ {formatMoney(Math.abs(totals.cash))} ر.س — أنت تغطي هذا العجز من جيبك.
              </p>
            </div>
          )}
          <div className="flex items-center justify-between bg-white/[0.05] px-5 py-2.5 text-[11px] font-bold text-slate-300">
            <span>
              {lastSyncAt
                ? `☁ آخر مزامنة: ${new Date(lastSyncAt).toLocaleTimeString("ar-SA-u-nu-latn", { hour: "2-digit", minute: "2-digit" })}`
                : "☁ لم تتم المزامنة بعد"}
            </span>
            <span>{online ? "🟢 متصل" : "🟡 أوفلاين"}</span>
          </div>
        </section>

        <PublicLinkCard compact />

        <Link
          href="/download"
          className="anim-rise flex items-center justify-between rounded-2xl bg-white px-4 py-3 card-soft"
        >
          <span className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-sky-50 text-base">⬇</span>
            <span>
              <span className="block text-[13px] font-black text-slate-900">مركز التنزيل</span>
              <span className="block text-[10.5px] font-bold text-slate-500">
                APK • رابط دائم • تثبيت PWA • نسخة أوفلاين
              </span>
            </span>
          </span>
          <span className="text-slate-400">←</span>
        </Link>

        <InstallBanner onOpenGuide={() => setShowSettings(true)} />

        {/* ─── البحث والفلاتر ─── */}
        <section className="anim-rise space-y-2.5" style={{ animationDelay: "0.06s" }}>
          <div className="relative">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="🔍 ابحث باسم المشروع أو الزبون أو الجوال…"
              className="field !rounded-2xl !py-3 pr-4 card-soft"
            />
          </div>
          <div className="flex gap-2">
            {(
              [
                { v: "all", l: "الكل" },
                { v: "active", l: "نشط 🟢" },
                { v: "completed", l: "مكتمل ✅" },
              ] as const
            ).map((f) => (
              <button
                key={f.v}
                onClick={() => setFilter(f.v)}
                className={`flex-1 rounded-xl py-2.5 text-[13px] font-extrabold transition ${
                  filter === f.v
                    ? "bg-[#1E293B] text-white card-soft"
                    : "bg-white text-slate-500 card-soft"
                }`}
              >
                {f.l}
              </button>
            ))}
          </div>
        </section>

        {/* ─── قائمة المشاريع ─── */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-[15px] font-extrabold text-slate-800">
              📋 المشاريع ({filtered.length})
            </h2>
          </div>

          {!ready ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-36 animate-pulse rounded-2xl bg-slate-200/70" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            projects.length === 0 ? (
              <EmptyState
                icon="🏠"
                title="لا توجد مشاريع بعد"
                hint="اضغط زر + لإضافة أول مشروع واتفاقية مع صاحب البيت"
              />
            ) : (
              <EmptyState icon="🔍" title="لا توجد نتائج" hint="جرّب كلمة بحث مختلفة" />
            )
          ) : (
            <div className="stagger space-y-3">
              {filtered.map((p) => {
                const pays = payments.filter((x) => x.projectId === p.id);
                const exps = expenses.filter((x) => x.projectId === p.id);
                const s = calcSummary(p.agreementTotal, pays, exps);
                return (
                  <Link
                    key={p.id}
                    href={`/projects/${p.id}`}
                    className="block rounded-2xl bg-white p-4 card-soft transition active:scale-[0.99]"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="truncate text-[15px] font-extrabold text-slate-900">
                            {p.title}
                          </h3>
                          {!p._synced && (
                            <span title="بانتظار المزامنة" className="h-2.5 w-2.5 shrink-0 rounded-full bg-amber-500" />
                          )}
                        </div>
                        <p className="mt-0.5 truncate text-[13px] font-bold text-slate-500">
                          👤 {p.clientName}
                          {p.phone ? <span className="num"> • {p.phone}</span> : ""}
                        </p>
                      </div>
                      <StatusBadge status={p.status} />
                    </div>

                    {/* شريط التقدم */}
                    <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full rounded-full bg-gradient-to-l from-[#D97706] to-amber-400 transition-all"
                        style={{ width: `${s.progress}%` }}
                      />
                    </div>

                    <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                      <div className="rounded-xl bg-slate-50 py-2">
                        <p className="text-[10px] font-bold text-slate-400">الاتفاقية</p>
                        <p className="num text-[14px] font-black text-slate-800">
                          {formatMoney(p.agreementTotal)}
                        </p>
                      </div>
                      <div className="rounded-xl bg-emerald-50 py-2">
                        <p className="text-[10px] font-bold text-emerald-600">مقبوض {s.progress}%</p>
                        <p className="num text-[14px] font-black text-emerald-700">
                          {formatMoney(s.totalReceived)}
                        </p>
                      </div>
                      <div className="rounded-xl bg-amber-50 py-2">
                        <p className="text-[10px] font-bold text-amber-600">متبقي عليه</p>
                        <p className="num text-[14px] font-black text-[#B45309]">
                          {formatMoney(s.remainingOnClient)}
                        </p>
                      </div>
                    </div>

                    {s.isDeficit && (
                      <p className="mt-2 rounded-lg bg-red-50 px-2 py-1.5 text-center text-[11px] font-extrabold text-red-700 ring-1 ring-red-100">
                        🚨 عجز كاش {formatMoney(s.deficit)} ر.س — مغطّى من جيبك
                      </p>
                    )}
                    {pays.length === 0 && (
                      <p className="mt-2 rounded-lg bg-amber-50 px-2 py-1.5 text-center text-[11px] font-extrabold text-amber-800 ring-1 ring-amber-100">
                        ⚠️ لا توجد دفعات مسجلة — سجّل الدفعة المقدمة ليصح الحساب
                      </p>
                    )}
                  </Link>
                );
              })}
            </div>
          )}
        </section>
      </main>

      {/* ─── زر الإضافة العائم ─── */}
      <button
        onClick={() => setShowAdd(true)}
        className="fixed bottom-6 left-1/2 z-40 flex w-[calc(100%-2rem)] max-w-md -translate-x-1/2 items-center justify-center gap-2 rounded-2xl bg-[#D97706] py-4 text-[16px] font-black text-white shadow-[0_12px_32px_rgba(217,119,6,0.45)] transition active:scale-[0.98]"
        style={{ left: "50%" }}
      >
        <span className="grid h-7 w-7 place-items-center rounded-full bg-white/20 text-lg leading-none">+</span>
        إضافة مشروع جديد
      </button>

      <AddProjectSheet open={showAdd} onClose={() => setShowAdd(false)} />
      <SettingsSheet open={showSettings} onClose={() => setShowSettings(false)} />
    </div>
  );
}
