import { db, isDbConfigured } from "@/db";
import { projects, payments, expenses } from "@/db/schema";
import { inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

// GET: إرجاع كل البيانات (للمزامنة الأولية)
export async function GET() {
  if (!isDbConfigured) {
    return Response.json({ projects: [], payments: [], expenses: [], db: false });
  }
  try {
    const [p, pay, exp] = await Promise.all([
      db.select().from(projects),
      db.select().from(payments),
      db.select().from(expenses),
    ]);
    return Response.json({ projects: p, payments: pay, expenses: exp });
  } catch (e) {
    console.error("sync GET failed", e);
    // لا نُسقط العميل — يستمر بالعمل محلياً
    return Response.json({
      projects: [],
      payments: [],
      expenses: [],
      db: false,
      warning: "database unavailable",
    });
  }
}

// POST: رفع البيانات المحلية (upsert) + تنفيذ الحذف، ثم إرجاع لقطة جديدة
export async function POST(req: Request) {
  if (!isDbConfigured) {
    // بدون قاعدة بيانات: نحفظ محلياً فقط ولا نفقد أي شيء
    return Response.json(
      { projects: [], payments: [], expenses: [], db: false, saved: "local-only" },
      { status: 200 }
    );
  }
  try {
    const body = await req.json().catch(() => ({}));
    const inProjects: Record<string, unknown>[] = Array.isArray(body.projects)
      ? body.projects
      : [];
    const inPayments: Record<string, unknown>[] = Array.isArray(body.payments)
      ? body.payments
      : [];
    const inExpenses: Record<string, unknown>[] = Array.isArray(body.expenses)
      ? body.expenses
      : [];
    const deleted = body.deleted ?? { projects: [], payments: [], expenses: [] };

    // تنفيذ الحذف أولاً
    if (Array.isArray(deleted.projects) && deleted.projects.length > 0) {
      await db.delete(projects).where(inArray(projects.id, deleted.projects));
    }
    if (Array.isArray(deleted.payments) && deleted.payments.length > 0) {
      await db.delete(payments).where(inArray(payments.id, deleted.payments));
    }
    if (Array.isArray(deleted.expenses) && deleted.expenses.length > 0) {
      await db.delete(expenses).where(inArray(expenses.id, deleted.expenses));
    }

    // upsert المشاريع
    for (const r of inProjects) {
      const id = String(r.id ?? "");
      if (!id) continue;
      const row = {
        id,
        title: String(r.title ?? ""),
        clientName: String(r.clientName ?? ""),
        phone: String(r.phone ?? ""),
        address: String(r.address ?? ""),
        agreementTotal: Number(r.agreementTotal ?? 0),
        notes: String(r.notes ?? ""),
        status: String(r.status ?? "active"),
        updatedAt: new Date(),
      };
      await db
        .insert(projects)
        .values(row)
        .onConflictDoUpdate({
          target: projects.id,
          set: {
            title: row.title,
            clientName: row.clientName,
            phone: row.phone,
            address: row.address,
            agreementTotal: row.agreementTotal,
            notes: row.notes,
            status: row.status,
            updatedAt: row.updatedAt,
          },
        });
    }

    // upsert الدفعات
    for (const r of inPayments) {
      const id = String(r.id ?? "");
      const projectId = String(r.projectId ?? "");
      if (!id || !projectId) continue;
      const paidAt = safeDate(r.paidAt);
      const row = {
        id,
        projectId,
        amount: Number(r.amount ?? 0),
        paidAt,
        method: String(r.method ?? "cash"),
        note: String(r.note ?? ""),
        receiptImage: (r.receiptImage as string) ?? null,
      };
      await db
        .insert(payments)
        .values(row)
        .onConflictDoUpdate({
          target: payments.id,
          set: {
            amount: row.amount,
            paidAt: row.paidAt,
            method: row.method,
            note: row.note,
            receiptImage: row.receiptImage,
          },
        });
    }

    // upsert المصروفات
    for (const r of inExpenses) {
      const id = String(r.id ?? "");
      const projectId = String(r.projectId ?? "");
      if (!id || !projectId) continue;
      const spentAt = safeDate(r.spentAt);
      const row = {
        id,
        projectId,
        amount: Number(r.amount ?? 0),
        spentAt,
        category: String(r.category ?? "أخرى"),
        vendor: String(r.vendor ?? ""),
        description: String(r.description ?? ""),
        invoiceImage: (r.invoiceImage as string) ?? null,
      };
      await db
        .insert(expenses)
        .values(row)
        .onConflictDoUpdate({
          target: expenses.id,
          set: {
            amount: row.amount,
            spentAt: row.spentAt,
            category: row.category,
            vendor: row.vendor,
            description: row.description,
            invoiceImage: row.invoiceImage,
          },
        });
    }

    const [p, pay, exp] = await Promise.all([
      db.select().from(projects),
      db.select().from(payments),
      db.select().from(expenses),
    ]);
    return Response.json({ projects: p, payments: pay, expenses: exp });
  } catch (e) {
    console.error("sync POST failed", e);
    return Response.json(
      { projects: [], payments: [], expenses: [], db: false, saved: "local-only" },
      { status: 200 }
    );
  }
}

function safeDate(v: unknown): Date {
  try {
    const d = new Date(String(v));
    if (isNaN(d.getTime())) return new Date();
    return d;
  } catch {
    return new Date();
  }
}
