import { readFile } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const FILES: Record<
  string,
  { file: string; name: string; type: string; display: string }
> = {
  offline: {
    file: "gypsum-offline.html",
    name: "gypsum-app.html",
    type: "application/octet-stream",
    display: "التطبيق المستقل (ملف واحد)",
  },
  "static-site": {
    file: "gypsum-static-site.zip",
    name: "gypsum-static-site.zip",
    type: "application/zip",
    display: "حزمة الموقع الجاهزة (Netlify / Vercel)",
  },
  "apk-kit": {
    file: "gypsum-apk-kit.zip",
    name: "gypsum-apk-kit.zip",
    type: "application/zip",
    display: "حزمة بناء APK",
  },
  source: {
    file: "gypsum-app-source.zip",
    name: "gypsum-app-source.zip",
    type: "application/zip",
    display: "كود المشروع الكامل",
  },
  "github-pages": {
    file: "gypsum-github-pages.zip",
    name: "gypsum-github-pages.zip",
    type: "application/zip",
    display: "حزمة النشر على GitHub Pages",
  },
  "github-repo": {
    file: "gypsum-github-repo.zip",
    name: "gypsum-github-repo.zip",
    type: "application/zip",
    display: "حزمة المستودع الجاهزة للنشر",
  },
};

/**
 * تنزيل مباشر بخواص إجبارية (Content-Disposition: attachment)
 * حتى ينزّل المتصفح الملف بدل عرضه داخل إطار المعاينة.
 */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ kind: string }> }
) {
  const { kind } = await params;
  const meta = FILES[kind];

  if (!meta) {
    return new Response("not found", { status: 404 });
  }

  try {
    const filePath = path.join(process.cwd(), "public", "downloads", meta.file);
    const data = await readFile(filePath);
    return new Response(new Uint8Array(data), {
      status: 200,
      headers: {
        "Content-Type": meta.type,
        "Content-Disposition": `attachment; filename="${meta.name}"`,
        "Content-Length": String(data.byteLength),
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "ALLOWALL",
      },
    });
  } catch {
    return new Response("file missing", { status: 500 });
  }
}
