import { db, isDbConfigured } from "@/db";
import { projects, payments, expenses } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  if (!isDbConfigured) {
    return Response.json({ error: "not found", db: false }, { status: 404 });
  }
  try {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    if (!project) return Response.json({ error: "not found" }, { status: 404 });
    const [pay, exp] = await Promise.all([
      db.select().from(payments).where(eq(payments.projectId, id)),
      db.select().from(expenses).where(eq(expenses.projectId, id)),
    ]);
    return Response.json({ project, payments: pay, expenses: exp });
  } catch {
    return Response.json({ error: "not found", db: false }, { status: 404 });
  }
}
