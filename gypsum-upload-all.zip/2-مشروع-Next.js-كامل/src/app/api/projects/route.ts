import { db, isDbConfigured } from "@/db";
import { projects } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!isDbConfigured) return Response.json([]);
  try {
    const rows = await db
      .select()
      .from(projects)
      .orderBy(desc(projects.createdAt));
    return Response.json(rows);
  } catch {
    return Response.json([]);
  }
}
