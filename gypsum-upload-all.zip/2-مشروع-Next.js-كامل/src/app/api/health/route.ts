import { db, isDbConfigured } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  // التطبيق يعمل أوفلاين-أولاً؛ غياب قاعدة البيانات لا يُسقط الخدمة.
  if (!isDbConfigured) {
    return Response.json({ ok: true, db: false, mode: "offline-first" });
  }
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, db: true });
  } catch {
    return Response.json({ ok: true, db: false, mode: "offline-first" });
  }
}
