import QRCode from "qrcode";

export const dynamic = "force-dynamic";

/**
 * يولّد كود QR للرابط المطلوب.
 * GET /api/qr?text=<url>&size=<px>
 */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    let text = url.searchParams.get("text") ?? "";

    // إن لم يُحدَّد نص، نستخدم أصل الطلب نفسه (رابط التطبيق العام)
    if (!text) {
      const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? "";
      const proto =
        req.headers.get("x-forwarded-proto") ??
        (host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https");
      text = host ? `${proto}://${host}/` : "";
    }

    if (!text) {
      return new Response("text is required", { status: 400 });
    }

    const size = Math.min(1000, Math.max(120, Number(url.searchParams.get("size")) || 320));

    const png = await QRCode.toBuffer(text, {
      type: "png",
      width: size,
      margin: 1,
      errorCorrectionLevel: "M",
      color: { dark: "#1E293BFF", light: "#FFFFFFFF" },
    });

    return new Response(new Uint8Array(png), {
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "public, max-age=300",
      },
    });
  } catch {
    return new Response("qr failed", { status: 500 });
  }
}
