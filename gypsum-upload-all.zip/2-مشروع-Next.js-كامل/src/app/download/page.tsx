import type { Metadata } from "next";
import Link from "next/link";
import { DownloadCenter } from "@/components/DownloadCenter";

export const metadata: Metadata = {
  title: "مركز التنزيل | حسابات معلم الجبس",
  description:
    "حمّل التطبيق: تثبيت PWA على الجوال، نسخة مستقلة تعمل بدون إنترنت، حزمة نشر دائمة، أو حزمة بناء APK للأندرويد.",
};

export default function DownloadPage() {
  return (
    <main className="mx-auto max-w-md px-4 pb-14 pt-6">
      <div className="mb-5 text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#1E293B] text-3xl shadow-[0_8px_24px_rgba(30,41,59,0.3)]">
          ⬇
        </div>
        <h1 className="mt-3 text-xl font-black text-slate-900">مركز التنزيل</h1>
        <p className="mt-1 text-[12.5px] font-bold text-slate-500">
          اختر الطريقة المناسبة لك — كلها تعمل على أي جوال
        </p>
      </div>

      <DownloadCenter />

      <div className="mt-4 rounded-2xl bg-slate-100 p-4">
        <h2 className="text-[13px] font-black text-slate-800">📌 ملاحظة صريحة</h2>
        <p className="mt-1 text-[11.5px] font-bold leading-relaxed text-slate-600">
          ملف APK هو ملف أندرويد تنفيذي يحتاج إلى تجميع بـ Java + Android SDK. هذه البيئة لا
          تتضمنهما، لذلك لا يمكن إنشاء APK جاهز هنا. الحزم أدناه تُنتج لك APK حقيقياً
          بالضبط بخطوات مضمونة (بناء تلقائي على GitHub أو عبر PWABuilder) دون الحاجة إلى
          Android Studio.
        </p>
      </div>

      <Link
        href="/"
        className="mt-4 block rounded-2xl bg-[#D97706] py-3.5 text-center text-[15px] font-black text-white shadow-[0_8px_24px_rgba(217,119,6,0.35)]"
      >
        العودة للتطبيق
      </Link>
    </main>
  );
}
