import type { Metadata } from "next";
import Link from "next/link";
import { GuideActions } from "@/components/GuideActions";
import { PublicLinkCard } from "@/components/PublicLinkCard";

export const metadata: Metadata = {
  title: "دليل التثبيت والمشاركة | حسابات معلم الجبس",
  description: "طريقة تثبيت التطبيق على الجوال ومشاركته مع صديقك",
};

const steps = {
  android: [
    "افتح رابط التطبيق في متصفح Chrome على جوال الأندرويد.",
    "اضغط قائمة النقاط الثلاث ⋮ أعلى المتصفح.",
    "اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».",
    "أكّد التثبيت — ستظهر أيقونة التطبيق 🧱 على شاشتك.",
  ],
  iphone: [
    "افتح رابط التطبيق في متصفح Safari على الآيفون (مهم: Safari وليس متصفح آخر).",
    "اضغط زر المشاركة ⬆ أسفل الشاشة.",
    "اختر «إضافة إلى الشاشة الرئيسية».",
    "اضغط «إضافة» — ستظهر أيقونة التطبيق 🧱 على شاشتك.",
  ],
};

export default function GuidePage() {
  return (
    <main className="mx-auto max-w-md px-4 pb-16 pt-6">
      <div className="mb-5 text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#1E293B] text-3xl shadow-[0_8px_24px_rgba(30,41,59,0.3)]">
          🧱
        </div>
        <h1 className="mt-3 text-xl font-black text-slate-900">دليل التثبيت والمشاركة</h1>
        <p className="mt-1 text-[13px] font-bold text-slate-500">
          ثبّت التطبيق على الجوال وأرسله لصديقك في دقيقة
        </p>
      </div>

      {/* الرابط الصحيح + QR */}
      <PublicLinkCard />

      <Link
        href="/download"
        className="mt-3 block rounded-2xl bg-sky-600 py-3.5 text-center text-[14px] font-black text-white"
      >
        ⬇ فتح مركز التنزيل (APK ورابط دائم)
      </Link>

      {/* زر تنزيل نسخة الويب */}
      <div className="mt-3">
        <GuideActions />
      </div>

      <section className="mt-4 rounded-2xl bg-red-50 p-4 ring-1 ring-red-200">
        <h2 className="text-[14px] font-black text-red-900">⚠️ لماذا تظهر «المعاينة غير متاحة»؟</h2>
        <p className="mt-1 text-[12px] font-bold leading-relaxed text-red-800">
          لأنك فتحت رابط <span dir="ltr" className="num font-black">arena.site</span> — وهو نطاق
          منصة المعاينة، ويعمل فقط داخل arena.ai. رابط التطبيق الصحيح هو الذي تراه في بطاقة
          «📤 شارك التطبيق» بالأعلى (نطاق <span dir="ltr" className="num font-black">e2b.app</span>).
          استخدم زر «نسخ» أو امسح كود QR، ولا تنسخ رابط شريط العنوان إذا كان arena.site.
        </p>
      </section>

      <section className="mt-3 rounded-2xl bg-white p-4 card-soft">
        <h2 className="mb-2 text-[15px] font-black text-slate-800">🔀 خيارات المشاركة</h2>
        <div className="space-y-2">
          <div className="rounded-xl bg-emerald-50 p-3 ring-1 ring-emerald-200">
            <p className="text-[12.5px] font-black text-emerald-900">1) الأسرع: ملف واحد (بدون استضافة)</p>
            <p className="mt-0.5 text-[11.5px] font-bold leading-relaxed text-emerald-800">
              نزّل «التطبيق كملف واحد» وأرسله لصديقك على واتساب — يفتحه بأي متصفح ويعمل
              بدون إنترنت، وبياناته تُحفظ على جواله.
            </p>
          </div>
          <div className="rounded-xl bg-amber-50 p-3 ring-1 ring-amber-200">
            <p className="text-[12.5px] font-black text-amber-900">2) الأنسب للاستخدام الدائم: نشر مجاني</p>
            <p className="mt-0.5 text-[11.5px] font-bold leading-relaxed text-amber-800">
              ارفع المشروع على Vercel واربط قاعدة بيانات Supabase (مجاناً) — يصبح لديك رابط
              دائم يُثبَّت كتطبيق ويتزامن بين الأجهزة. الخطوات في ملف README داخل ZIP.
            </p>
          </div>
          <div className="rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200">
            <p className="text-[12.5px] font-black text-slate-900">3) للتعديل لاحقاً: كود المشروع</p>
            <p className="mt-0.5 text-[11.5px] font-bold leading-relaxed text-slate-700">
              نزّل ZIP كامل وأرسله لصديقك أو لأي مبرمج لتطويره مستقبلاً.
            </p>
          </div>
        </div>
      </section>

      <section className="mt-4 rounded-2xl bg-white p-4 card-soft">
        <h2 className="mb-2 flex items-center gap-2 text-[15px] font-black text-slate-800">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-50 text-base">🤖</span>
          أندرويد (Chrome)
        </h2>
        <ol className="space-y-2">
          {steps.android.map((s, i) => (
            <li key={i} className="flex gap-2.5 text-[12.5px] font-bold leading-relaxed text-slate-600">
              <span className="num grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#FEF3C7] text-[11px] font-black text-[#92400E]">
                {i + 1}
              </span>
              {s}
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-3 rounded-2xl bg-white p-4 card-soft">
        <h2 className="mb-2 flex items-center gap-2 text-[15px] font-black text-slate-800">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100 text-base"></span>
          آيفون (Safari)
        </h2>
        <ol className="space-y-2">
          {steps.iphone.map((s, i) => (
            <li key={i} className="flex gap-2.5 text-[12.5px] font-bold leading-relaxed text-slate-600">
              <span className="num grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#FEF3C7] text-[11px] font-black text-[#92400E]">
                {i + 1}
              </span>
              {s}
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-3 rounded-2xl bg-[#1E293B] p-4 text-white card-soft">
        <h2 className="text-[15px] font-black">⚡ العمل بدون إنترنت</h2>
        <ul className="mt-2 space-y-1.5 text-[12px] font-bold leading-relaxed text-slate-300">
          <li>• البيانات تُحفظ على الجوال أولاً، لذلك يعمل التطبيق بدون شبكة.</li>
          <li>• عند عودة الاتصال تُزامَن البيانات تلقائياً مع السحابة.</li>
          <li>• الشريط العلوي يعرض حالة الاتصال وعدد العناصر المعلّقة.</li>
          <li>• من ⚙️ الإعدادات يمكنك تنزيل نسخة احتياطية أو استيرادها.</li>
        </ul>
      </section>

      <section className="mt-3 rounded-2xl bg-amber-50 p-4 ring-1 ring-amber-200">
        <h2 className="text-[14px] font-black text-amber-900">🔁 نقل البيانات لجوال صديقك</h2>
        <p className="mt-1 text-[12px] font-bold leading-relaxed text-amber-800">
          من ⚙️ الإعدادات اضغط «تنزيل نسخة احتياطية (JSON)» وأرسل الملف لصديقك عبر واتساب،
          ثم من جواله: الإعدادات ← «استيراد نسخة احتياطية» واختر الملف.
        </p>
      </section>

      <Link
        href="/"
        className="mt-5 block rounded-2xl bg-[#D97706] py-3.5 text-center text-[15px] font-black text-white shadow-[0_8px_24px_rgba(217,119,6,0.35)]"
      >
        العودة للرئيسية
      </Link>
    </main>
  );
}
