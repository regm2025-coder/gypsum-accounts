import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { StoreProvider } from "@/lib/store";
import { RootInit } from "@/components/RootInit";
import "./globals.css";

export const metadata: Metadata = {
  title: "حسابات معلم الجبس | إدارة مشاريع الديكور",
  description:
    "تطبيق محاسبة لمعلم الجبس والديكور: إدارة المشاريع والمقبوضات والمصروفات وكشوف الحساب — يعمل بدون إنترنت",
  manifest: "/manifest.json",
  applicationName: "حسابات الجبس",
  appleWebApp: {
    capable: true,
    title: "حسابات الجبس",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon.svg", type: "image/svg+xml" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
    shortcut: ["/favicon-32.png"],
  },
  other: {
    "mobile-web-app-capable": "yes",
    "apple-touch-fullscreen": "yes",
    "apple-mobile-web-app-title": "حسابات الجبس",
    "format-detection": "telephone=no",
    "theme-color": "#1E293B",
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#1E293B",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
        <link rel="apple-touch-startup-image" href="/screenshots/home.png" />
        <meta name="msapplication-TileColor" content="#1E293B" />
        <meta name="msapplication-TileImage" content="/icon-192.png" />
      </head>
      <body>
        <StoreProvider>
          <RootInit />
          {children}
        </StoreProvider>
      </body>
    </html>
  );
}
