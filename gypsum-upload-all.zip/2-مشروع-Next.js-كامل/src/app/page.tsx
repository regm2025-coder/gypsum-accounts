import { HomeScreen } from "@/components/HomeScreen";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <HomeScreen />;
}
