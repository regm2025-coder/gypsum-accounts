// ─── أنواع البيانات المحلية (Offline-First) ───

export interface LocalProject {
  id: string;
  title: string;
  clientName: string;
  phone: string;
  address: string;
  agreementTotal: number;
  notes: string;
  status: "active" | "completed" | "paused";
  createdAt: string;
  updatedAt: string;
  _synced: boolean;
}

export interface LocalPayment {
  id: string;
  projectId: string;
  amount: number;
  paidAt: string;
  method: "cash" | "transfer" | "bank";
  note: string;
  receiptImage: string | null;
  createdAt: string;
  _synced: boolean;
}

export interface LocalExpense {
  id: string;
  projectId: string;
  amount: number;
  spentAt: string;
  category: string;
  vendor: string;
  description: string;
  invoiceImage: string | null;
  createdAt: string;
  _synced: boolean;
}

export interface DeletedQueue {
  projects: string[];
  payments: string[];
  expenses: string[];
}

export interface LocalDB {
  projects: LocalProject[];
  payments: LocalPayment[];
  expenses: LocalExpense[];
  deleted: DeletedQueue;
  lastSyncAt: string | null;
}

export interface ProjectSummary {
  agreementTotal: number;
  totalReceived: number;
  totalExpenses: number;
  cashInHand: number;
  remainingOnClient: number;
  progress: number; // 0..100 نسبة التحصيل
  expectedProfit: number; // الاتفاقية - المصروفات
  /** عجز الكاش: مصروفات أعلى من المقبوضات (يدفعها المعلم من جيبه) */
  deficit: number;
  /** هل الكاش باليد يكفي لتغطية كل المصروفات؟ */
  isDeficit: boolean;
  /** المبلغ المطلوب استلامه من صاحب البيت لتغطية العجز */
  neededToCover: number;
}

export function calcSummary(
  agreementTotal: number,
  payments: LocalPayment[],
  expenses: LocalExpense[]
): ProjectSummary {
  const totalReceived = payments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
  const totalExpenses = expenses.reduce((s, e) => s + (Number(e.amount) || 0), 0);
  const cashInHand = totalReceived - totalExpenses;
  const remainingOnClient = Math.max(0, agreementTotal - totalReceived);
  const progress =
    agreementTotal > 0
      ? Math.min(100, Math.round((totalReceived / agreementTotal) * 100))
      : 0;
  const expectedProfit = agreementTotal - totalExpenses;
  const deficit = cashInHand < 0 ? Math.abs(cashInHand) : 0;
  return {
    agreementTotal,
    totalReceived,
    totalExpenses,
    cashInHand,
    remainingOnClient,
    progress,
    expectedProfit,
    deficit,
    isDeficit: deficit > 0,
    neededToCover: deficit,
  };
}

/** نص طلب دفعة من صاحب البيت لتغطية العجز */
export function buildRequestPaymentText(opts: {
  title: string;
  clientName: string;
  totalReceived: number;
  remainingOnClient: number;
  deficit: number;
}): string {
  const ask = opts.remainingOnClient > 0 ? opts.remainingOnClient : opts.deficit;
  return [
    `السلام عليكم ${opts.clientName} 🌙`,
    `بخصوص مشروع: ${opts.title}`,
    "",
    ...(opts.deficit > 0
      ? [
          `تم صرف مواد ومشتريات بقيمة تتجاوز المقبوض بمقدار ${opts.deficit.toLocaleString("en-US")} ر.س،`,
          "وذلك لتسريع سير العمل 🙏",
        ]
      : []),
    opts.remainingOnClient > 0
      ? `المتبقي من قيمة الاتفاقية: ${opts.remainingOnClient.toLocaleString("en-US")} ر.س`
      : "",
    ask > 0 ? `نرجو تحويل دفعة بقيمة ${ask.toLocaleString("en-US")} ر.س لاستكمال المواد.` : "",
    "",
    "شاكرين تعاونكم 🤝",
  ]
    .filter(Boolean)
    .join("\n");
}

export const EXPENSE_CATEGORIES = [
  "مواد جبس",
  "جبس بورد",
  "دهان ولوازم",
  "كهرباء وإنارة",
  "أجور عمال",
  "نقل ومواصلات",
  "عدد وأدوات",
  "أخرى",
];

export const PAYMENT_METHODS: { value: LocalPayment["method"]; label: string }[] = [
  { value: "cash", label: "نقدي" },
  { value: "transfer", label: "تحويل" },
  { value: "bank", label: "شبكة / بنك" },
];
