"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type {
  LocalDB,
  LocalExpense,
  LocalPayment,
  LocalProject,
} from "./types";
import { uid } from "./format";

const STORAGE_KEY = "gypsum_decorator_db_v1";

const emptyDB: LocalDB = {
  projects: [],
  payments: [],
  expenses: [],
  deleted: { projects: [], payments: [], expenses: [] },
  lastSyncAt: null,
};

function loadLocal(): LocalDB {
  if (typeof window === "undefined") return emptyDB;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyDB;
    const parsed = JSON.parse(raw) as LocalDB;
    return {
      projects: Array.isArray(parsed.projects) ? parsed.projects : [],
      payments: Array.isArray(parsed.payments) ? parsed.payments : [],
      expenses: Array.isArray(parsed.expenses) ? parsed.expenses : [],
      deleted: parsed.deleted ?? { projects: [], payments: [], expenses: [] },
      lastSyncAt: parsed.lastSyncAt ?? null,
    };
  } catch {
    return emptyDB;
  }
}

function saveLocal(db: LocalDB) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    // التخزين ممتلئ (صور كثيرة) — نتجاهل بصمت
  }
}

// تحويل صفوف السيرفر إلى الشكل المحلي
function mapProject(r: Record<string, unknown>): LocalProject {
  return {
    id: String(r.id),
    title: String(r.title ?? ""),
    clientName: String(r.clientName ?? r.client_name ?? ""),
    phone: String(r.phone ?? ""),
    address: String(r.address ?? ""),
    agreementTotal: Number(r.agreementTotal ?? r.agreement_total ?? 0),
    notes: String(r.notes ?? ""),
    status: (String(r.status ?? "active") as LocalProject["status"]) || "active",
    createdAt: String(r.createdAt ?? r.created_at ?? new Date().toISOString()),
    updatedAt: String(r.updatedAt ?? r.updated_at ?? new Date().toISOString()),
    _synced: true,
  };
}
function mapPayment(r: Record<string, unknown>): LocalPayment {
  return {
    id: String(r.id),
    projectId: String(r.projectId ?? r.project_id ?? ""),
    amount: Number(r.amount ?? 0),
    paidAt: String(r.paidAt ?? r.paid_at ?? new Date().toISOString()),
    method: (String(r.method ?? "cash") as LocalPayment["method"]) || "cash",
    note: String(r.note ?? ""),
    receiptImage: (r.receiptImage as string) ?? (r.receipt_image as string) ?? null,
    createdAt: String(r.createdAt ?? r.created_at ?? new Date().toISOString()),
    _synced: true,
  };
}
function mapExpense(r: Record<string, unknown>): LocalExpense {
  return {
    id: String(r.id),
    projectId: String(r.projectId ?? r.project_id ?? ""),
    amount: Number(r.amount ?? 0),
    spentAt: String(r.spentAt ?? r.spent_at ?? new Date().toISOString()),
    category: String(r.category ?? "أخرى"),
    vendor: String(r.vendor ?? ""),
    description: String(r.description ?? ""),
    invoiceImage: (r.invoiceImage as string) ?? (r.invoice_image as string) ?? null,
    createdAt: String(r.createdAt ?? r.created_at ?? new Date().toISOString()),
    _synced: true,
  };
}

interface StoreValue {
  ready: boolean;
  online: boolean;
  syncing: boolean;
  lastSyncAt: string | null;
  pendingCount: number;
  projects: LocalProject[];
  payments: LocalPayment[];
  expenses: LocalExpense[];
  paymentsOf: (projectId: string) => LocalPayment[];
  expensesOf: (projectId: string) => LocalExpense[];
  projectById: (id: string) => LocalProject | undefined;
  addProject: (d: {
    title: string;
    clientName: string;
    phone: string;
    address: string;
    agreementTotal: number;
    notes: string;
  }) => LocalProject;
  updateProject: (id: string, patch: Partial<LocalProject>) => void;
  deleteProject: (id: string) => void;
  addPayment: (d: {
    projectId: string;
    amount: number;
    paidAt: string;
    method: LocalPayment["method"];
    note: string;
    receiptImage: string | null;
  }) => LocalPayment;
  deletePayment: (id: string) => void;
  addExpense: (d: {
    projectId: string;
    amount: number;
    spentAt: string;
    category: string;
    vendor: string;
    description: string;
    invoiceImage: string | null;
  }) => LocalExpense;
  deleteExpense: (id: string) => void;
  syncNow: () => Promise<boolean>;
  exportBackup: () => string;
  importBackup: (json: string) => { ok: boolean; message: string };
  clearAllLocal: () => void;
}

const StoreCtx = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [db, setDb] = useState<LocalDB>(emptyDB);
  const [ready, setReady] = useState(false);
  const [online, setOnline] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const dbRef = useRef(db);
  dbRef.current = db;
  const syncingRef = useRef(false);

  // تحميل محلي أولاً (Offline-First)
  useEffect(() => {
    setDb(loadLocal());
    setReady(true);
    setOnline(typeof navigator !== "undefined" ? navigator.onLine : true);
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  // حفظ تلقائي محلياً عند كل تغيير
  useEffect(() => {
    if (ready) saveLocal(db);
  }, [db, ready]);

  const pendingCount = useMemo(() => {
    const un =
      db.projects.filter((p) => !p._synced).length +
      db.payments.filter((p) => !p._synced).length +
      db.expenses.filter((e) => !e._synced).length;
    const del =
      db.deleted.projects.length +
      db.deleted.payments.length +
      db.deleted.expenses.length;
    return un + del;
  }, [db]);

  /** المزامنة مع السيرفر (Supabase/Postgres) */
  const syncNow = useCallback(async (): Promise<boolean> => {
    if (syncingRef.current) return false;
    if (typeof navigator !== "undefined" && !navigator.onLine) return false;
    syncingRef.current = true;
    setSyncing(true);
    try {
      const cur = dbRef.current;
      const unsyncedProjects = cur.projects.filter((p) => !p._synced);
      const unsyncedPayments = cur.payments.filter((p) => !p._synced);
      const unsyncedExpenses = cur.expenses.filter((e) => !e._synced);

      // لو لا يوجد شيء معلق، نجلب أحدث نسخة فقط
      if (
        unsyncedProjects.length === 0 &&
        unsyncedPayments.length === 0 &&
        unsyncedExpenses.length === 0 &&
        cur.deleted.projects.length === 0 &&
        cur.deleted.payments.length === 0 &&
        cur.deleted.expenses.length === 0
      ) {
        const res = await fetch("/api/sync", { cache: "no-store" });
        if (res.ok) {
          const snap = await res.json();
          const serverProjects: LocalProject[] = (snap.projects ?? []).map(mapProject);
          const serverPayments: LocalPayment[] = (snap.payments ?? []).map(mapPayment);
          const serverExpenses: LocalExpense[] = (snap.expenses ?? []).map(mapExpense);
          setDb((prev) => ({
            projects: mergeById(serverProjects, prev.projects.filter((p) => !p._synced)),
            payments: mergeById(serverPayments, prev.payments.filter((p) => !p._synced)),
            expenses: mergeById(serverExpenses, prev.expenses.filter((e) => !e._synced)),
            deleted: prev.deleted,
            lastSyncAt: new Date().toISOString(),
          }));
          return true;
        }
        return false;
      }

      const res = await fetch("/api/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projects: unsyncedProjects,
          payments: unsyncedPayments,
          expenses: unsyncedExpenses,
          deleted: cur.deleted,
        }),
      });
      if (!res.ok) return false;
      const snap = await res.json();
      const serverProjects: LocalProject[] = (snap.projects ?? []).map(mapProject);
      const serverPayments: LocalPayment[] = (snap.payments ?? []).map(mapPayment);
      const serverExpenses: LocalExpense[] = (snap.expenses ?? []).map(mapExpense);
      // بعد نجاح الرفع: السيرفر هو المرجع + أي سجلات محلية جديدة أُنشئت أثناء المزامنة
      setDb((prev) => {
        const stillUnsyncedP = prev.projects.filter((p) => !p._synced);
        const stillUnsyncedPay = prev.payments.filter((p) => !p._synced);
        const stillUnsyncedExp = prev.expenses.filter((e) => !e._synced);
        const pushedIds = new Set([
          ...unsyncedProjects.map((p) => p.id),
          ...stillUnsyncedP.map((p) => p.id),
        ]);
        void pushedIds;
        return {
          projects: mergeById(
            serverProjects,
            stillUnsyncedP.filter((p) => !unsyncedProjects.some((u) => u.id === p.id))
          ),
          payments: mergeById(
            serverPayments,
            stillUnsyncedPay.filter((p) => !unsyncedPayments.some((u) => u.id === p.id))
          ),
          expenses: mergeById(
            serverExpenses,
            stillUnsyncedExp.filter((e) => !unsyncedExpenses.some((u) => u.id === e.id))
          ),
          deleted: { projects: [], payments: [], expenses: [] },
          lastSyncAt: new Date().toISOString(),
        };
      });
      return true;
    } catch {
      return false;
    } finally {
      syncingRef.current = false;
      setSyncing(false);
    }
  }, []);

  // مزامنة تلقائية: عند العودة للاتصال + دورياً كل 20 ثانية
  useEffect(() => {
    if (!ready) return;
    // جلب أولي
    const t = setTimeout(() => void syncNow(), 800);
    const iv = setInterval(() => void syncNow(), 20000);
    const onVis = () => {
      if (document.visibilityState === "visible") void syncNow();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      clearTimeout(t);
      clearInterval(iv);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [ready, syncNow]);

  useEffect(() => {
    if (ready && online) void syncNow();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online]);

  const addProject: StoreValue["addProject"] = useCallback((d) => {
    const now = new Date().toISOString();
    const p: LocalProject = {
      id: uid(),
      title: d.title.trim(),
      clientName: d.clientName.trim(),
      phone: d.phone.trim(),
      address: d.address.trim(),
      agreementTotal: Number(d.agreementTotal) || 0,
      notes: d.notes.trim(),
      status: "active",
      createdAt: now,
      updatedAt: now,
      _synced: false,
    };
    setDb((prev) => ({ ...prev, projects: [p, ...prev.projects] }));
    setTimeout(() => void syncNow(), 300);
    return p;
  }, [syncNow]);

  const updateProject: StoreValue["updateProject"] = useCallback((id, patch) => {
    setDb((prev) => ({
      ...prev,
      projects: prev.projects.map((p) =>
        p.id === id
          ? { ...p, ...patch, updatedAt: new Date().toISOString(), _synced: false }
          : p
      ),
    }));
  }, []);

  const deleteProject: StoreValue["deleteProject"] = useCallback((id) => {
    setDb((prev) => {
      const target = prev.projects.find((p) => p.id === id);
      const wasSynced = target?._synced;
      return {
        projects: prev.projects.filter((p) => p.id !== id),
        payments: prev.payments.filter((p) => p.projectId !== id),
        expenses: prev.expenses.filter((e) => e.projectId !== id),
        deleted: {
          projects: wasSynced ? [...prev.deleted.projects, id] : prev.deleted.projects,
          payments: prev.deleted.payments,
          expenses: prev.deleted.expenses,
        },
        lastSyncAt: prev.lastSyncAt,
      };
    });
  }, []);

  const addPayment: StoreValue["addPayment"] = useCallback((d) => {
    const now = new Date().toISOString();
    const pay: LocalPayment = {
      id: uid(),
      projectId: d.projectId,
      amount: Number(d.amount) || 0,
      paidAt: d.paidAt,
      method: d.method,
      note: d.note.trim(),
      receiptImage: d.receiptImage,
      createdAt: now,
      _synced: false,
    };
    setDb((prev) => ({ ...prev, payments: [pay, ...prev.payments] }));
    setTimeout(() => void syncNow(), 300);
    return pay;
  }, [syncNow]);

  const deletePayment: StoreValue["deletePayment"] = useCallback((id) => {
    setDb((prev) => {
      const target = prev.payments.find((p) => p.id === id);
      return {
        ...prev,
        payments: prev.payments.filter((p) => p.id !== id),
        deleted: {
          ...prev.deleted,
          payments: target?._synced
            ? [...prev.deleted.payments, id]
            : prev.deleted.payments,
        },
      };
    });
  }, []);

  const addExpense: StoreValue["addExpense"] = useCallback((d) => {
    const now = new Date().toISOString();
    const exp: LocalExpense = {
      id: uid(),
      projectId: d.projectId,
      amount: Number(d.amount) || 0,
      spentAt: d.spentAt,
      category: d.category,
      vendor: d.vendor.trim(),
      description: d.description.trim(),
      invoiceImage: d.invoiceImage,
      createdAt: now,
      _synced: false,
    };
    setDb((prev) => ({ ...prev, expenses: [exp, ...prev.expenses] }));
    setTimeout(() => void syncNow(), 300);
    return exp;
  }, [syncNow]);

  const deleteExpense: StoreValue["deleteExpense"] = useCallback((id) => {
    setDb((prev) => {
      const target = prev.expenses.find((e) => e.id === id);
      return {
        ...prev,
        expenses: prev.expenses.filter((e) => e.id !== id),
        deleted: {
          ...prev.deleted,
          expenses: target?._synced
            ? [...prev.deleted.expenses, id]
            : prev.deleted.expenses,
        },
      };
    });
  }, []);

  const paymentsOf = useCallback(
    (projectId: string) =>
      db.payments
        .filter((p) => p.projectId === projectId)
        .sort((a, b) => +new Date(b.paidAt) - +new Date(a.paidAt)),
    [db.payments]
  );
  const expensesOf = useCallback(
    (projectId: string) =>
      db.expenses
        .filter((e) => e.projectId === projectId)
        .sort((a, b) => +new Date(b.spentAt) - +new Date(a.spentAt)),
    [db.expenses]
  );
  const projectById = useCallback(
    (id: string) => db.projects.find((p) => p.id === id),
    [db.projects]
  );

  /** تصدير نسخة احتياطية كاملة (JSON) — تُرسل للصديق أو تُحفظ */
  const exportBackup = useCallback((): string => {
    const cur = dbRef.current;
    return JSON.stringify(
      {
        app: "gypsum-accounting",
        version: 1,
        exportedAt: new Date().toISOString(),
        data: {
          projects: cur.projects,
          payments: cur.payments,
          expenses: cur.expenses,
        },
      },
      null,
      2
    );
  }, []);

  /** استيراد نسخة احتياطية — تدمج البيانات وتعتبرها بحاجة للمزامنة */
  const importBackup = useCallback(
    (json: string): { ok: boolean; message: string } => {
      try {
        const parsed = JSON.parse(json);
        const d = parsed?.data ?? parsed;
        const inProjects: LocalProject[] = Array.isArray(d.projects) ? d.projects : [];
        const inPayments: LocalPayment[] = Array.isArray(d.payments) ? d.payments : [];
        const inExpenses: LocalExpense[] = Array.isArray(d.expenses) ? d.expenses : [];
        if (inProjects.length === 0 && inPayments.length === 0 && inExpenses.length === 0) {
          return { ok: false, message: "الملف لا يحتوي على بيانات صالحة" };
        }
        setDb((prev) => {
          const pMap = new Map(prev.projects.map((p) => [p.id, p]));
          for (const p of inProjects) if (!pMap.has(p.id)) pMap.set(p.id, { ...p, _synced: false });
          const payMap = new Map(prev.payments.map((p) => [p.id, p]));
          for (const p of inPayments) if (!payMap.has(p.id)) payMap.set(p.id, { ...p, _synced: false });
          const expMap = new Map(prev.expenses.map((e) => [e.id, e]));
          for (const e of inExpenses) if (!expMap.has(e.id)) expMap.set(e.id, { ...e, _synced: false });
          return {
            ...prev,
            projects: [...pMap.values()],
            payments: [...payMap.values()],
            expenses: [...expMap.values()],
          };
        });
        setTimeout(() => void syncNow(), 400);
        return {
          ok: true,
          message: `تم الاستيراد: ${inProjects.length} مشروع، ${inPayments.length} دفعة، ${inExpenses.length} فاتورة`,
        };
      } catch {
        return { ok: false, message: "الملف غير صالح — تأكد أنه ملف نسخة احتياطية" };
      }
    },
    [syncNow]
  );

  /** حذف كل البيانات من هذا الجهاز */
  const clearAllLocal = useCallback(() => {
    setDb({ ...emptyDB });
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  const value: StoreValue = {
    ready,
    online,
    syncing,
    lastSyncAt: db.lastSyncAt,
    pendingCount,
    projects: useMemo(
      () =>
        [...db.projects].sort(
          (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
        ),
      [db.projects]
    ),
    payments: db.payments,
    expenses: db.expenses,
    paymentsOf,
    expensesOf,
    projectById,
    addProject,
    updateProject,
    deleteProject,
    addPayment,
    deletePayment,
    addExpense,
    deleteExpense,
    syncNow,
    exportBackup,
    importBackup,
    clearAllLocal,
  };

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

function mergeById<T extends { id: string }>(server: T[], localUnsynced: T[]): T[] {
  const ids = new Set(server.map((s) => s.id));
  const extras = localUnsynced.filter((l) => !ids.has(l.id));
  return [...extras, ...server];
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
