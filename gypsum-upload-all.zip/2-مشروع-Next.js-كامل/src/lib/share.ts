// ─── مساعدات المشاركة والتنزيل (تعمل داخل الإطارات المقيّدة أيضاً) ───

/** هل التطبيق معروض داخل iframe (مثل معاينة المنصة)؟ */
export function isEmbedded(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

export function appUrl(): string {
  if (typeof window === "undefined") return "";
  // داخل المعاينة يكون location هو رابط التطبيق الحقيقي القابل للمشاركة
  return window.location.origin + "/";
}

/** هل الرابط الحالي هو نطاق منصة المعاينة (غير قابل للمشاركة)؟ */
export function isUnshareableHost(url: string): boolean {
  return /arena\.(site|ai)/i.test(url);
}

export function absoluteUrl(path: string): string {
  if (typeof window === "undefined") return path;
  try {
    return new URL(path, window.location.origin).toString();
  } catch {
    return path;
  }
}

/** نسخ نص مع بديل يعمل على المتصفحات القديمة/الإطارات */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* نكمل للبديل */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "-1000px";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

/** فتح رابط خارجي بأكثر من طريقة */
export function openExternal(url: string): void {
  try {
    const w = window.open(url, "_blank", "noopener,noreferrer");
    if (w) return;
  } catch {
    /* ممنوع */
  }
  try {
    if (window.top && window.top !== window.self) {
      window.top.location.href = url;
      return;
    }
  } catch {
    /* منع عبور النطاق */
  }
  try {
    window.location.href = url;
  } catch {
    /* لا شيء */
  }
}

/** تنزيل ملف — يحاول التنزيل المباشر ثم يفتح الملف في تبويب جديد */
export function startDownload(url: string, filename?: string): "downloaded" | "opened" {
  try {
    const a = document.createElement("a");
    a.href = url;
    if (filename) a.download = filename;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch {
    /* نتجاهل */
  }
  return isEmbedded() ? "opened" : "downloaded";
}

/** رابط واتساب مباشر لرقم (يوحّد الصيغة السعودية) أو لاختيار جهة اتصال */
export function whatsappLinkSafe(phone: string | undefined, text: string): string {
  let d = (phone ?? "").replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("966")) {
    const rest = d.slice(3);
    d = rest.startsWith("0") ? "966" + rest.slice(1) : d;
  } else if (d.startsWith("0")) {
    d = "966" + d.slice(1);
  } else if (d.length === 9 && d.startsWith("5")) {
    d = "966" + d;
  }
  const enc = encodeURIComponent(text);
  return d.length >= 8 ? `https://wa.me/${d}?text=${enc}` : `https://wa.me/?text=${enc}`;
}

/** تحويل مسار ملف إلى نقطة تنزيل إجبارية (Content-Disposition: attachment) */
const FORCED: Record<string, string> = {
  "/downloads/gypsum-offline.html": "/api/download/offline",
  "/downloads/gypsum-static-site.zip": "/api/download/static-site",
  "/downloads/gypsum-apk-kit.zip": "/api/download/apk-kit",
  "/downloads/gypsum-app-source.zip": "/api/download/source",
  "/downloads/gypsum-github-repo.zip": "/api/download/github-repo",
  "/downloads/gypsum-github-pages.zip": "/api/download/github-pages",
};

export function forcedDownloadUrl(url: string): string {
  return FORCED[url] ?? url;
}

/** الانتقال بالنافذة العليا (يتجاوز قيود إطار المعاينة) */
export function navigateTop(url: string): boolean {
  try {
    if (typeof window === "undefined") return false;
    if (window.top && window.top !== window.self) {
      window.top.location.href = url;
      return true;
    }
  } catch {
    /* cross-origin: نجرّب البدائل */
  }
  try {
    const w = window.open(url, "_blank", "noopener,noreferrer");
    if (w) return true;
  } catch {
    /* محجوب */
  }
  try {
    window.location.href = url;
    return true;
  } catch {
    return false;
  }
}
