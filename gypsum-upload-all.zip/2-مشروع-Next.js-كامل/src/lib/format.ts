// تنسيق الأرقام والتواريخ بالعربية

export function formatMoney(n: number): string {
  const v = Number(n) || 0;
  return v.toLocaleString("en-US", { maximumFractionDigits: 2 });
}

export function formatMoneyAr(n: number): string {
  return `${formatMoney(n)} ر.س`;
}

export function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleDateString("ar-SA-u-nu-latn", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "";
  }
}

export function formatDateTime(iso: string): string {
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return (
      d.toLocaleDateString("ar-SA-u-nu-latn", {
        year: "numeric",
        month: "short",
        day: "numeric",
      }) +
      " • " +
      d.toLocaleTimeString("ar-SA-u-nu-latn", {
        hour: "2-digit",
        minute: "2-digit",
      })
    );
  } catch {
    return "";
  }
}

export function toInputDate(iso: string): string {
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return new Date().toISOString().slice(0, 10);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return (
    "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10)
  );
}

/** توحيد رقم الجوال إلى صيغة دولية صالحة لواتساب (السعودية افتراضياً) */
export function normalizePhone(raw: string): string {
  let d = (raw || "").replace(/\D/g, "");
  if (!d) return "";
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("966")) {
    // 9665xxxxxxxx أو 96605xxxxxxxx
    const rest = d.slice(3);
    if (rest.startsWith("0")) d = "966" + rest.slice(1);
    return d;
  }
  if (d.startsWith("0")) return "966" + d.slice(1); // 05xxxxxxxx
  if (d.length === 9 && d.startsWith("5")) return "966" + d; // 5xxxxxxxx
  return d;
}

/** رابط واتساب مباشر إلى رقم الزبون، أو إلى اختيار جهة اتصال إن لم يوجد رقم */
export function whatsappLink(phone: string | undefined, text: string): string {
  const n = normalizePhone(phone ?? "");
  const enc = encodeURIComponent(text);
  return n ? `https://wa.me/${n}?text=${enc}` : `https://wa.me/?text=${enc}`;
}

/** نص كشف الحساب للمشاركة عبر واتساب */
export function buildStatementText(opts: {
  title: string;
  clientName: string;
  agreementTotal: number;
  totalReceived: number;
  totalExpenses: number;
  cashInHand: number;
  remainingOnClient: number;
  paymentsCount: number;
  expensesCount: number;
}): string {
  const lines = [
    "🧾 *كشف حساب مشروع ديكور وجبس*",
    "━━━━━━━━━━━━━━",
    `🏠 المشروع: ${opts.title}`,
    `👤 صاحب البيت: ${opts.clientName}`,
    "━━━━━━━━━━━━━━",
    `💰 قيمة الاتفاقية: ${formatMoney(opts.agreementTotal)} ر.س`,
    `✅ إجمالي المقبوض: ${formatMoney(opts.totalReceived)} ر.س (${opts.paymentsCount} دفعات)`,
    `🧱 إجمالي المصروفات: ${formatMoney(opts.totalExpenses)} ر.س (${opts.expensesCount} فواتير)`,
    opts.cashInHand < 0
      ? `🚨 عجز مؤقت في الكاش: ${formatMoney(Math.abs(opts.cashInHand))} ر.س (المصروفات أعلى من المقبوضات)`
      : `💵 الكاش المتبقي باليد: ${formatMoney(opts.cashInHand)} ر.س`,
    `📌 المتبقي على صاحب البيت: ${formatMoney(opts.remainingOnClient)} ر.س`,
    ...(opts.cashInHand < 0
      ? [
          "━━━━━━━━━━━━━━",
          `⚠️ ملاحظة: تمت تغطية فرق ${formatMoney(Math.abs(opts.cashInHand))} ر.س من جيب معلم الجبس بشكل مؤقت (عهدة)، ويُستقطع من الدفعة القادمة.`,
        ]
      : []),
    "━━━━━━━━━━━━━━",
    `📅 التاريخ: ${new Date().toLocaleDateString("ar-SA-u-nu-latn", { year: "numeric", month: "long", day: "numeric" })}`,
    "شكراً لتعاملكم 🤝",
  ];
  return lines.join("\n");
}
