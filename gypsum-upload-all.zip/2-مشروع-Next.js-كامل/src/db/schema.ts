import {
  pgTable,
  text,
  doublePrecision,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

// ─── المشاريع ─────────────────────────────────────────────
export const projects = pgTable("projects", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  clientName: text("client_name").notNull(),
  phone: text("phone").notNull().default(""),
  address: text("address").notNull().default(""),
  agreementTotal: doublePrecision("agreement_total").notNull().default(0),
  notes: text("notes").notNull().default(""),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;

// ─── الدفعات المقبوضة من صاحب البيت ──────────────────────
export const payments = pgTable(
  "payments",
  {
    id: text("id").primaryKey(),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    amount: doublePrecision("amount").notNull(),
    paidAt: timestamp("paid_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    method: text("method").notNull().default("cash"),
    note: text("note").notNull().default(""),
    receiptImage: text("receipt_image"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("payments_project_idx").on(t.projectId)]
);

export type Payment = typeof payments.$inferSelect;
export type NewPayment = typeof payments.$inferInsert;

// ─── مصروفات / فواتير المشتريات ──────────────────────────
export const expenses = pgTable(
  "expenses",
  {
    id: text("id").primaryKey(),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    amount: doublePrecision("amount").notNull(),
    spentAt: timestamp("spent_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    category: text("category").notNull().default("مواد جبس"),
    vendor: text("vendor").notNull().default(""),
    description: text("description").notNull().default(""),
    invoiceImage: text("invoice_image"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("expenses_project_idx").on(t.projectId)]
);

export type Expense = typeof expenses.$inferSelect;
export type NewExpense = typeof expenses.$inferInsert;
