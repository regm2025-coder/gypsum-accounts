import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = (process.env.DATABASE_URL ?? "").trim();

/** هل تم تكوين قاعدة البيانات؟ التطبيق يعمل بدونها أيضاً (أوفلاين أولاً). */
export const isDbConfigured = databaseUrl.length > 0;

const globalForDb = globalThis as typeof globalThis & {
  __gypsumPool?: Pool;
  __gypsumDb?: NodePgDatabase<Record<string, never>>;
};

export function getPool(): Pool | null {
  if (!isDbConfigured) return null;
  if (globalForDb.__gypsumPool) return globalForDb.__gypsumPool;
  const pool = new Pool({
    connectionString: databaseUrl,
    max: 5,
    ssl: /supabase\.co|neon\.tech|render\.com/i.test(databaseUrl)
      ? { rejectUnauthorized: false }
      : undefined,
  });
  globalForDb.__gypsumPool = pool;
  return pool;
}

export function getDb(): NodePgDatabase<Record<string, never>> | null {
  if (!isDbConfigured) return null;
  if (globalForDb.__gypsumDb) return globalForDb.__gypsumDb;
  const pool = getPool();
  if (!pool) return null;
  const instance = drizzle(pool);
  globalForDb.__gypsumDb = instance;
  return instance;
}

/**
 * كائن db متوافق مع الاستيراد المباشر، يُنشأ عند أول استخدام.
 * يرمي خطأً واضحاً إن لم تُضبط قاعدة البيانات — والمسارات تتعامل معه بأمان.
 */
export const db = new Proxy({} as NodePgDatabase<Record<string, never>>, {
  get(_target, prop) {
    const real = getDb();
    if (!real) {
      throw new Error("DATABASE_URL is not configured");
    }
    const value = (real as unknown as Record<string | symbol, unknown>)[prop];
    return typeof value === "function" ? value.bind(real) : value;
  },
});

export const pool = getPool();
