# 🚀 النشر السريع: GitHub → Vercel (5 دقائق)

## 1) ارفع الكود إلى مستودعك
```bash
# داخل مجلد المشروع
git init
git add -A
git commit -m "تطبيق حسابات معلم الجبس"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```
> أو من واجهة GitHub: **Add file → Upload files** واسحب الملفات (بدون `node_modules`).

## 2) اربط المستودع بـ Vercel
1. افتح 👉 https://vercel.com/new
2. اختر **Import Git Repository** → مستودعك.
3. Framework: **Next.js** (يُكتشف تلقائياً) — لا تغيّر شيئاً.
4. اضغط **Deploy**.

✅ هذا كل شيء. التطبيق **لا يحتاج قاعدة بيانات** ليعمل (أوفلاين-أولاً).
ستحصل على رابط دائم مثل: `https://your-repo.vercel.app`

## 3) (اختياري) فعّل المزامنة السحابية
1. أنشئ قاعدة مجانية على [supabase.com](https://supabase.com) أو [neon.tech](https://neon.tech).
2. انسخ **Connection String** (Postgres URI).
3. في Vercel: **Settings → Environment Variables** أضف:
   - `DATABASE_URL` = رابط الاتصال
4. من جهازك أنشئ الجداول:
   ```bash
   DATABASE_URL="رابط-قاعدتك" npx drizzle-kit push
   ```
5. **Redeploy** من تبويب Deployments.

## 4) ثبّت التطبيق على الجوال
افتح رابط Vercel على الجوال:
- **أندرويد/Chrome:** ⋮ ← «تثبيت التطبيق»
- **آيفون/Safari:** مشاركة ⬆ ← «إضافة إلى الشاشة الرئيسية»

## 5) (اختياري) APK للأندرويد
- الأسرع: [pwabuilder.com](https://www.pwabuilder.com) ← ألصق رابط Vercel ← Android ← نزّل APK.
- أو ارفع `gypsum-apk-kit.zip` (من مركز التنزيل) على مستودع منفصل ← Actions ← «بناء APK».

## ملاحظات
- `vercel.json` جاهز (ترويسات sw.js ومسارات التنزيل).
- المجلدات المشمولة في الرفع: `src`, `public`, `package.json`, `tsconfig.json`, `next.config.ts`, `drizzle.config.json`, `postcss.config.mjs`, `eslint.config.mjs`, `vercel.json`, `README.md`.
- لا ترفع `.env` (فيه كلمة سر قاعدة البيانات).
