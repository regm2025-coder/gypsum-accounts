# 🚀 رابط عام حقيقي اليوم — GitHub Pages (مستودعك جاهز ومفعّل)

مستودعك: `regm2025-coder/gypsum-accounts` • GitHub Pages **مفعّل** بالفعل.
التالي: نضع نسخة الويب (PWA) داخل المستودع ليصبح الرابط:

**https://regm2025-coder.github.io/gypsum-accounts/**

---

## الطريقة أ) من واجهة GitHub (بدون أوامر — الأسهل)

1. نزّل `gypsum-github-pages.zip` من مركز التنزيل وفك الضغط.
2. افتح: https://github.com/regm2025-coder/gypsum-accounts
3. اضغط **Add file → Upload files**
4. اسحب **كل محتويات المجلد** (بما فيها الملفات المخفية مثل `.nojekyll`)
5. في الأسفل: **Commit changes**
6. انتظر دقيقة → افتح: https://regm2025-coder.github.io/gypsum-accounts/

## الطريقة ب) بالأوامر (الصحيحة)

> الرابط الذي كتبته سابقاً فيه خطأ: `https://github.com/https://...` — الصيغة الصحيحة لا تحتوي
> على `github.com` مرتين.

```bash
# داخل مجلد الحزمة بعد فك الضغط
git init
git add -A
git commit -m "تطبيق حسابات الجبس والديكور - PWA"
git branch -M main
git remote add origin https://github.com/regm2025-coder/gypsum-accounts.git
git push -u origin main --force
```

> `--force` ضروري لأن المستودع يحتوي README فقط ونريد استبداله بملفات الموقع.

## إعداد GitHub Pages (إن لم يكن مفعّلاً)

Settings → **Pages** → Source: *Deploy from a branch* → Branch: **main** → Folder: **/ (root)** → Save

---

## ⚠️ لماذا هذه النسخة وليست مشروع Next.js؟

GitHub Pages يستضيف **ملفات ثابتة فقط** ولا يشغّل Node.js. لذلك:
- **GitHub Pages** = التطبيق كاملاً في ملف `index.html` (يعمل أوفلاين + تثبيت PWA). ✅ مناسب فوراً.
- **Vercel** = مشروع Next.js الكامل (قاعدة بيانات + مزامنة سحابية). استخدمه عندما تريد المزامنة.

كلاهما يعطي **HTTPS حقيقي** وقابل للمشاركة على واتساب.

## بعد النشر

| المهمة | كيف |
|---|---|
| تثبيت على أندرويد | Chrome ← ⋮ ← «تثبيت التطبيق» |
| تثبيت على آيفون | Safari ← مشاركة ⬆ ← «إضافة إلى الشاشة الرئيسية» |
| مشاركة | أرسل الرابط على واتساب |
| APK | pwabuilder.com ← ألصق الرابط ← Android ← تنزيل APK |
| نقل البيانات | ⚙️ الإعدادات ← نسخة احتياطية JSON |
