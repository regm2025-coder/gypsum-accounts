/* ────────────────────────────────────────────────────────────
   Service Worker — حسابات معلم الجبس
   الاستراتيجية: Offline-First
   1) التنقل (HTML): network-first ← fallback للكاش ← /offline.html
   2) أصول Next.js الثابتة: cache-first (بصمات فريدة)
   3) الصور والأيقونات: cache-first مع تنقية
   4) /api/*: تجاوز تماماً (المزامنة يتولاها التطبيق)
   ──────────────────────────────────────────────────────────── */

const VERSION = "v4";
const SHELL = `gypsum-shell-${VERSION}`;
const RUNTIME = `gypsum-runtime-${VERSION}`;

const PRECACHE = [
  "/",
  "/offline.html",
  "/manifest.json",
  "/manifest.webmanifest",
  "/icon.svg",
  "/icon-192.png",
  "/icon-512.png",
  "/icon-maskable-512.png",
  "/apple-touch-icon.png",
  "/favicon-32.png",
  "/download",
  "/guide",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL);
      // كل ملف على حدة حتى لا يفشل التثبيت بملف واحد مفقود
      await Promise.all(
        PRECACHE.map((url) =>
          cache.add(new Request(url, { cache: "reload" })).catch(() => null)
        )
      );
      await self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => k !== SHELL && k !== RUNTIME)
          .map((k) => caches.delete(k))
      );
      if (self.registration.navigationPreload) {
        try {
          await self.registration.navigationPreload.disable();
        } catch {
          /* ignore */
        }
      }
      await self.clients.claim();
    })()
  );
});

self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

function isStaticAsset(url) {
  return (
    url.pathname.startsWith("/_next/static/") ||
    /\.(?:css|js|woff2?|ttf|png|jpg|jpeg|svg|webp|ico|json|webmanifest)$/i.test(
      url.pathname
    )
  );
}

async function networkFirst(request) {
  const cache = await caches.open(RUNTIME);
  try {
    const fresh = await fetch(request);
    if (fresh && fresh.status === 200) cache.put(request, fresh.clone()).catch(() => null);
    return fresh;
  } catch {
    const cached = await caches.match(request, { ignoreSearch: true });
    if (cached) return cached;
    const shell = await caches.match("/", { ignoreSearch: true });
    if (shell) return shell;
    return (await caches.match("/offline.html")) ?? new Response("offline", { status: 503 });
  }
}

async function cacheFirst(request) {
  const cached = await caches.match(request, { ignoreSearch: false });
  if (cached) return cached;
  const cache = await caches.open(RUNTIME);
  try {
    const fresh = await fetch(request);
    if (fresh && fresh.status === 200) cache.put(request, fresh.clone()).catch(() => null);
    return fresh;
  } catch {
    return new Response("", { status: 504, statusText: "offline" });
  }
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // نطاق خارجي (الخطوط): نمرر للشبكة مع كاش
  if (url.origin !== self.location.origin) {
    if (url.hostname.includes("fonts.googleapis.com") || url.hostname.includes("fonts.gstatic.com")) {
      event.respondWith(cacheFirst(request));
    }
    return;
  }

  // الـ API يتجاوز الكاش
  if (url.pathname.startsWith("/api/")) return;

  if (request.mode === "navigate") {
    event.respondWith(networkFirst(request));
    return;
  }

  if (isStaticAsset(url)) {
    event.respondWith(cacheFirst(request));
    return;
  }

  event.respondWith(networkFirst(request));
});
